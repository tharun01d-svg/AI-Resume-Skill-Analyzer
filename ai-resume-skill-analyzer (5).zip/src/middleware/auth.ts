import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';
import { verifyAuthToken, TokenPayload } from '../../server/authUtils.ts';

export interface UserSessionPayload {
  uid: string;
  email: string;
  name?: string | null;
  picture?: string | null;
  [key: string]: any;
}

export interface AuthRequest extends Request {
  user?: UserSessionPayload;
}

async function resolveToken(token: string): Promise<UserSessionPayload | null> {
  // 1. Try server-signed JWT first (fast, reliable, no external network call)
  try {
    const verified = verifyAuthToken(token);
    if (verified && verified.uid) {
      return verified;
    }
  } catch {
    // Not a server JWT, proceed to Firebase token verification
  }

  // 2. Try Firebase ID Token
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    return {
      ...decodedToken,
      email: decodedToken.email || `${decodedToken.uid}@firebase.user`,
      name: decodedToken.name || null,
      picture: decodedToken.picture || null,
    };
  } catch (error) {
    return null;
  }
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing authentication token' });
  }

  const token = authHeader.split('Bearer ')[1].trim();
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized: Empty token provided' });
  }

  const user = await resolveToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized: Invalid or expired session token' });
  }

  req.user = user;
  next();
};

export const optionalAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.split('Bearer ')[1]?.trim();
  if (token) {
    const user = await resolveToken(token);
    if (user) {
      req.user = user;
    }
  }
  next();
};
