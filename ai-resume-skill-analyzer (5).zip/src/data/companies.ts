export interface CompanyOption {
  id: string;
  name: string;
  ticker?: string;
  industry: string;
  color: string;
  bgColor: string;
  logoType: 'svg' | 'initials';
  svgKey?: string;
}

export const TOP_COMPANIES: CompanyOption[] = [
  { id: 'google', name: 'Google', ticker: 'GOOGL', industry: 'Technology & Cloud', color: '#4285F4', bgColor: '#E8F0FE', logoType: 'svg', svgKey: 'google' },
  { id: 'microsoft', name: 'Microsoft', ticker: 'MSFT', industry: 'Software & Cloud', color: '#00A4EF', bgColor: '#E6F4FF', logoType: 'svg', svgKey: 'microsoft' },
  { id: 'amazon', name: 'Amazon', ticker: 'AMZN', industry: 'Cloud & E-Commerce', color: '#FF9900', bgColor: '#FFF4E5', logoType: 'svg', svgKey: 'amazon' },
  { id: 'apple', name: 'Apple', ticker: 'AAPL', industry: 'Hardware & Ecosystems', color: '#555555', bgColor: '#F5F5F7', logoType: 'svg', svgKey: 'apple' },
  { id: 'meta', name: 'Meta', ticker: 'META', industry: 'Social Technologies & AI', color: '#0081FB', bgColor: '#EBF4FF', logoType: 'svg', svgKey: 'meta' },
  { id: 'nvidia', name: 'NVIDIA', ticker: 'NVDA', industry: 'Accelerated Computing & AI', color: '#76B900', bgColor: '#F1F9E8', logoType: 'svg', svgKey: 'nvidia' },
  { id: 'oracle', name: 'Oracle', ticker: 'ORCL', industry: 'Enterprise Cloud & Data', color: '#C74634', bgColor: '#FDEDEC', logoType: 'svg', svgKey: 'oracle' },
  { id: 'ibm', name: 'IBM', ticker: 'IBM', industry: 'Enterprise Hybrid Cloud', color: '#0F62FE', bgColor: '#EDF5FF', logoType: 'svg', svgKey: 'ibm' },
  { id: 'adobe', name: 'Adobe', ticker: 'ADBE', industry: 'Creative Cloud & Software', color: '#FA0F00', bgColor: '#FEF0EF', logoType: 'svg', svgKey: 'adobe' },
  { id: 'salesforce', name: 'Salesforce', ticker: 'CRM', industry: 'Cloud CRM & SaaS', color: '#00A1E0', bgColor: '#E6F6FC', logoType: 'svg', svgKey: 'salesforce' },
  { id: 'accenture', name: 'Accenture', ticker: 'ACN', industry: 'Technology Consulting', color: '#A100FF', bgColor: '#F5EBFF', logoType: 'svg', svgKey: 'accenture' },
  { id: 'deloitte', name: 'Deloitte', ticker: 'Private', industry: 'Audit, Tax & Consulting', color: '#86BC25', bgColor: '#F3F9EA', logoType: 'svg', svgKey: 'deloitte' },
  { id: 'tcs', name: 'TCS', ticker: 'TCS', industry: 'IT Services & Consulting', color: '#0B2545', bgColor: '#EBF1F7', logoType: 'initials' },
  { id: 'infosys', name: 'Infosys', ticker: 'INFY', industry: 'Digital Services & Consulting', color: '#007CC3', bgColor: '#E6F3FA', logoType: 'initials' },
  { id: 'wipro', name: 'Wipro', ticker: 'WIT', industry: 'Technology Services', color: '#5C3C92', bgColor: '#F1ECF7', logoType: 'initials' },
  { id: 'cognizant', name: 'Cognizant', ticker: 'CTSH', industry: 'Digital & IT Services', color: '#123282', bgColor: '#EDF1F9', logoType: 'initials' },
  { id: 'capgemini', name: 'Capgemini', ticker: 'CAP', industry: 'Consulting & Technology', color: '#0070AD', bgColor: '#E6F3F9', logoType: 'initials' },
  { id: 'jpmorgan', name: 'JPMorgan Chase', ticker: 'JPM', industry: 'Financial Services & Tech', color: '#117ACA', bgColor: '#E9F3FA', logoType: 'svg', svgKey: 'jpmorgan' },
  { id: 'goldman', name: 'Goldman Sachs', ticker: 'GS', industry: 'Investment Banking & Tech', color: '#1B5E20', bgColor: '#E8F5E9', logoType: 'svg', svgKey: 'goldman' },
  { id: 'cisco', name: 'Cisco', ticker: 'CSCO', industry: 'Networking & Security', color: '#049FD9', bgColor: '#E6F7FC', logoType: 'svg', svgKey: 'cisco' },
];

export const OTHER_COMPANY: CompanyOption = {
  id: 'other',
  name: 'Other / Not Listed',
  industry: 'Custom Company',
  color: '#475569',
  bgColor: '#F1F5F9',
  logoType: 'initials',
};
