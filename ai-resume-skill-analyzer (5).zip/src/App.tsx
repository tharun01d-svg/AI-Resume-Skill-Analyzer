import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Navbar } from './components/Navbar';
import { LandingView } from './components/LandingView';
import { UploadSection } from './components/UploadSection';
import { ProcessingState } from './components/ProcessingState';
import { ResultsDashboard } from './components/ResultsDashboard';
import { ScoreFormulaModal } from './components/ScoreFormulaModal';
import { HistoryModal } from './components/HistoryModal';
import { FinalReportModal } from './components/FinalReportModal';
import { UserCredentialsModal } from './components/UserCredentialsModal';
import { ToastProvider, useToast } from './components/ToastNotification';
import { AuthProvider } from './context/AuthContext';
import { pageVariants, fadeUpVariants } from './utils/motion';
import { AnalysisReport } from './types/analyzer';
import { runClientSidePipeline } from './utils/clientPipeline';
import { SamplePair, SAMPLE_DATASETS } from '../server/sampleData';
import {
  getSavedReports,
  saveReportToHistory,
  deleteReportFromHistory,
  clearAllHistory,
} from './utils/storage';
import { AlertCircle } from 'lucide-react';

function AppContent() {
  const { showToast } = useToast();

  // Navigation & View State
  const [currentTab, setCurrentTab] = useState<'landing' | 'analyzer' | 'results'>('landing');

  // Input State
  const [resumeText, setResumeText] = useState<string>('');
  const [resumeFileName, setResumeFileName] = useState<string>('');
  const [resumeFileSize, setResumeFileSize] = useState<number | undefined>(undefined);
  const [resumePageCount, setResumePageCount] = useState<number | undefined>(undefined);
  const [resumeFileType, setResumeFileType] = useState<string>('PDF');

  const [jobDescription, setJobDescription] = useState<string>('');
  const [jobTitle, setJobTitle] = useState<string>('Software Engineer');
  const [company, setCompany] = useState<string>('Google');
  const [seniorityLevel, setSeniorityLevel] = useState<string>('2–4 Years');
  const [targetGoal, setTargetGoal] = useState<string>('');

  // Processing & Results
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [activeReport, setActiveReport] = useState<AnalysisReport | null>(null);

  // Modals
  const [isFormulaOpen, setIsFormulaOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isCredentialsOpen, setIsCredentialsOpen] = useState<boolean>(false);

  // Local Storage History
  const [historyReports, setHistoryReports] = useState<AnalysisReport[]>([]);

  useEffect(() => {
    const saved = getSavedReports();
    setHistoryReports(saved);
  }, []);

  // Pre-load a sample dataset
  const handleSelectSample = (sample: SamplePair) => {
    setResumeText(sample.resumeText);
    setResumeFileName(sample.resumeFileName);
    setResumeFileSize(sample.resumeText.length);
    setResumePageCount(2);
    setResumeFileType('PDF');
    setJobDescription(sample.jobDescription);
    setJobTitle(sample.jobTitle);
    setCompany(sample.company || 'Google');
    setTargetGoal(sample.targetGoal);
    setSeniorityLevel(sample.jobTitle.includes('Lead') ? '7–10 Years' : sample.jobTitle.includes('Senior') ? '4–7 Years' : '2–4 Years');
    setAnalysisError(null);
    setCurrentTab('analyzer');
    showToast(`Loaded preset profile: ${sample.jobTitle} (${sample.company || 'Tech'})`, 'info');
  };

  // Run the full AI Analysis Pipeline
  const handleRunAnalysis = async () => {
    if (!resumeText.trim()) {
      setAnalysisError('Please upload your resume before analyzing.');
      showToast('Please upload your resume before analyzing.', 'error');
      return;
    }
    if (!company.trim() || !jobTitle.trim()) {
      setAnalysisError('Please select both a target company and job role.');
      showToast('Please select target company and job role.', 'error');
      return;
    }

    setAnalysisError(null);
    setIsAnalyzing(true);

    try {
      let report: AnalysisReport;
      try {
        const response = await fetch('/api/run-pipeline', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            resumeText,
            jobDescription: jobDescription.trim() || undefined,
            resumeFileName: resumeFileName || 'Candidate_Resume.pdf',
            resumeFileType,
            resumeFileSize,
            resumePageCount,
            targetCompany: company.trim(),
            targetRole: jobTitle.trim(),
            experienceLevel: seniorityLevel || '2–4 Years',
            targetGoal: targetGoal.trim() || undefined,
            jobMeta: {
              title: jobTitle.trim(),
              company: company.trim(),
              level: seniorityLevel,
            },
          }),
        });

        const contentType = response.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const data = await response.json();
          if (response.ok && data?.scoreResult) {
            report = data;
          } else {
            console.warn('Backend pipeline returned non-ok or error, running client pipeline:', data?.error);
            report = runClientSidePipeline({
              resumeText,
              jobDescription: jobDescription.trim() || undefined,
              resumeFileName: resumeFileName || 'Candidate_Resume.pdf',
              resumeFileType,
              resumeFileSize,
              resumePageCount,
              targetCompany: company.trim(),
              targetRole: jobTitle.trim(),
              experienceLevel: seniorityLevel || '2–4 Years',
              targetGoal: targetGoal.trim() || undefined,
            });
          }
        } else {
          console.warn('Backend returned non-JSON, using in-browser analyzer pipeline');
          report = runClientSidePipeline({
            resumeText,
            jobDescription: jobDescription.trim() || undefined,
            resumeFileName: resumeFileName || 'Candidate_Resume.pdf',
            resumeFileType,
            resumeFileSize,
            resumePageCount,
            targetCompany: company.trim(),
            targetRole: jobTitle.trim(),
            experienceLevel: seniorityLevel || '2–4 Years',
            targetGoal: targetGoal.trim() || undefined,
          });
        }
      } catch (fetchErr) {
        console.warn('Network call failed, executing in-browser analyzer pipeline:', fetchErr);
        report = runClientSidePipeline({
          resumeText,
          jobDescription: jobDescription.trim() || undefined,
          resumeFileName: resumeFileName || 'Candidate_Resume.pdf',
          resumeFileType,
          resumeFileSize,
          resumePageCount,
          targetCompany: company.trim(),
          targetRole: jobTitle.trim(),
          experienceLevel: seniorityLevel || '2–4 Years',
          targetGoal: targetGoal.trim() || undefined,
        });
      }

      setActiveReport(report);
      saveReportToHistory(report);
      setHistoryReports(getSavedReports());
      setCurrentTab('results');
      showToast('Analysis complete! Alignment score & roadmap ready.', 'success');
    } catch (err: any) {
      console.error('Analysis error:', err);
      setAnalysisError(err.message || 'An unexpected error occurred during analysis.');
      showToast(err.message || 'Analysis error occurred.', 'error');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSelectHistoryReport = (report: AnalysisReport) => {
    setActiveReport(report);
    setCurrentTab('results');
    showToast('Loaded past report from history.', 'info');
  };

  const handleDeleteHistory = (id: string) => {
    const updated = deleteReportFromHistory(id);
    setHistoryReports(updated);
    if (activeReport?.id === id) {
      setActiveReport(null);
      if (currentTab === 'results') setCurrentTab('analyzer');
    }
    showToast('Report removed from history.', 'info');
  };

  const handleClearHistory = () => {
    clearAllHistory();
    setHistoryReports([]);
    showToast('History cleared.', 'info');
  };

  const handleReset = () => {
    setCurrentTab('analyzer');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white">
      {/* Top Bar Contract Navbar */}
      <Navbar
        currentTab={currentTab}
        onNavigate={(tab) => setCurrentTab(tab)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenFormula={() => setIsFormulaOpen(true)}
        onLoadSample={() => {
          handleSelectSample(SAMPLE_DATASETS[0]);
        }}
        onOpenCredentials={() => setIsCredentialsOpen(true)}
        hasActiveReport={!!activeReport}
        historyCount={historyReports.length}
      />

      {/* Main Content Viewport */}
      <main className="grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Error notification banner if any */}
        <AnimatePresence>
          {analysisError && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start justify-between gap-3 shadow-xs"
            >
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Analysis Failed:</strong> {analysisError}
                </div>
              </div>
              <button
                onClick={() => setAnalysisError(null)}
                className="text-2xs font-semibold text-rose-600 hover:text-rose-900 cursor-pointer"
              >
                Dismiss
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Seamless Page Transitions Across Tabs */}
        <AnimatePresence mode="wait">
          {/* 1. Landing View */}
          {currentTab === 'landing' && (
            <motion.div
              key="landing-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <LandingView
                onStartAnalysis={() => setCurrentTab('analyzer')}
                onSelectSample={handleSelectSample}
                onOpenFormula={() => setIsFormulaOpen(true)}
              />
            </motion.div>
          )}

          {/* 2. Analyzer Workspace */}
          {currentTab === 'analyzer' && (
            <motion.div
              key="analyzer-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <AnimatePresence mode="wait">
                {isAnalyzing ? (
                  <motion.div
                    key="analyzing-state"
                    variants={fadeUpVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                  >
                    <ProcessingState targetCompany={company} targetRole={jobTitle} />
                  </motion.div>
                ) : (
                  <motion.div
                    key="upload-section-state"
                    variants={fadeUpVariants}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                  >
                    <UploadSection
                      resumeText={resumeText}
                      resumeFileName={resumeFileName}
                      resumeFileSize={resumeFileSize}
                      resumePageCount={resumePageCount}
                      resumeFileType={resumeFileType}
                      jobDescription={jobDescription}
                      jobTitle={jobTitle}
                      company={company}
                      seniorityLevel={seniorityLevel}
                      targetGoal={targetGoal}
                      onResumeChange={(text, filename, size, pages, fileType) => {
                        setResumeText(text);
                        setResumeFileName(filename);
                        setResumeFileSize(size);
                        if (pages) setResumePageCount(pages);
                        if (fileType) setResumeFileType(fileType);
                      }}
                      onJobDescChange={setJobDescription}
                      onJobTitleChange={setJobTitle}
                      onCompanyChange={setCompany}
                      onSeniorityChange={setSeniorityLevel}
                      onTargetGoalChange={setTargetGoal}
                      onStartAnalysis={handleRunAnalysis}
                      isAnalyzing={isAnalyzing}
                      onSelectSample={handleSelectSample}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

          {/* 3. Results Dashboard */}
          {currentTab === 'results' && activeReport && (
            <motion.div
              key="results-page"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
            >
              <ResultsDashboard
                report={activeReport}
                onOpenReportModal={() => setIsReportModalOpen(true)}
                onOpenFormulaModal={() => setIsFormulaOpen(true)}
                onReset={handleReset}
                onOpenCredentials={() => setIsCredentialsOpen(true)}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Global Modals with Smooth AnimatePresence */}
      <ScoreFormulaModal
        isOpen={isFormulaOpen}
        onClose={() => setIsFormulaOpen(false)}
      />

      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        reports={historyReports}
        onSelectReport={handleSelectHistoryReport}
        onDeleteReport={handleDeleteHistory}
        onClearAll={handleClearHistory}
      />

      <UserCredentialsModal
        isOpen={isCredentialsOpen}
        onClose={() => setIsCredentialsOpen(false)}
        onLoadSavedReport={(report) => {
          setActiveReport(report);
          setCurrentTab('results');
          showToast(`Loaded analysis from Cloud SQL for ${report.targetRole}`, 'success');
        }}
        onApplyCredentialsToForm={(creds) => {
          if (creds.role) setJobTitle(creds.role);
          if (creds.company) setCompany(creds.company);
          if (creds.level) setSeniorityLevel(creds.level);
          showToast('Applied saved career credentials to target form!', 'success');
        }}
      />

      {activeReport && (
        <FinalReportModal
          report={activeReport}
          isOpen={isReportModalOpen}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}

      {/* Clean Global Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="font-semibold text-slate-700">
            AI Resume Skill Analyzer
          </span>
          <span className="text-2xs text-slate-400">
            Deterministic 100-Point Alignment · Strict Grounding · Viva-Ready Scoring
          </span>
          <div className="flex items-center gap-4 text-2xs text-slate-500">
            <button onClick={() => setIsFormulaOpen(true)} className="hover:text-slate-900 cursor-pointer">
              Mathematical Model
            </button>
            <button onClick={() => setIsHistoryOpen(true)} className="hover:text-slate-900 cursor-pointer">
              History
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

export function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ToastProvider>
  );
}

export default App;
