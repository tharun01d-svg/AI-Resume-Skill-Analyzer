import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  User,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import { AnalysisReport } from '../types/analyzer';

export interface AppUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

export interface UserCredentials {
  targetRole?: string;
  targetCompany?: string;
  experienceLevel?: string;
  portfolioUrl?: string;
  githubUrl?: string;
  linkedinUrl?: string;
  careerSummary?: string;
}

export interface SavedAnalysisRecord {
  id: number;
  candidateName: string;
  targetRole: string;
  targetCompany: string;
  totalScore: number;
  alignmentLevel: string;
  createdAt: string;
  report: AnalysisReport | null;
}

interface AuthContextType {
  currentUser: AppUser | User | null;
  loading: boolean;
  idToken: string | null;
  credentials: UserCredentials | null;
  savedAnalyses: SavedAnalysisRecord[];
  isSavingAnalysis: boolean;
  signInWithEmail: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUpWithEmail: (email: string, password: string, displayName?: string) => Promise<{ success: boolean; error?: string }>;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  saveCredentials: (creds: UserCredentials) => Promise<boolean>;
  saveAnalysisToCloud: (report: AnalysisReport) => Promise<boolean>;
  deleteAnalysisFromCloud: (id: number) => Promise<boolean>;
  refreshUserData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_STORAGE_KEY = 'resume_analyzer_auth_token';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<AppUser | User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [idToken, setIdToken] = useState<string | null>(null);
  const [credentials, setCredentials] = useState<UserCredentials | null>(null);
  const [savedAnalyses, setSavedAnalyses] = useState<SavedAnalysisRecord[]>([]);
  const [isSavingAnalysis, setIsSavingAnalysis] = useState<boolean>(false);

  // Sync token and Cloud SQL backend user record
  const syncWithBackend = useCallback(async (token: string, user: User | AppUser) => {
    try {
      const res = await fetch('/api/auth/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          displayName: user.displayName,
          photoUrl: user.photoURL,
          email: user.email,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.credentials) {
          setCredentials(data.credentials);
        }
      }
    } catch (err) {
      console.warn('Backend sync deferred:', err);
    }
  }, []);

  // Fetch credentials and saved analyses from Cloud SQL
  const refreshUserData = useCallback(async () => {
    const activeToken = idToken || localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!activeToken) return;
    try {
      const [credsRes, analysesRes] = await Promise.all([
        fetch('/api/credentials', {
          headers: { Authorization: `Bearer ${activeToken}` },
        }),
        fetch('/api/analyses', {
          headers: { Authorization: `Bearer ${activeToken}` },
        }),
      ]);

      if (credsRes.ok) {
        const creds = await credsRes.json();
        setCredentials(creds);
      }
      if (analysesRes.ok) {
        const analyses = await analysesRes.json();
        setSavedAnalyses(analyses);
      }
    } catch (err) {
      console.error('Failed to refresh user data:', err);
    }
  }, [idToken]);

  // Initial session restoration from stored JWT or Firebase onAuthStateChanged
  useEffect(() => {
    let isMounted = true;
    const storedToken = localStorage.getItem(TOKEN_STORAGE_KEY);

    if (storedToken) {
      // Validate existing session token against backend /api/auth/me
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${storedToken}` },
      })
        .then(async (res) => {
          if (!isMounted) return;
          if (res.ok) {
            const data = await res.json();
            setIdToken(storedToken);
            setCurrentUser({
              uid: data.user.uid,
              email: data.user.email,
              displayName: data.user.displayName,
              photoURL: data.user.photoUrl || data.user.photoURL || null,
            });
            if (data.credentials) {
              setCredentials(data.credentials);
            }

            // Fetch saved analyses
            try {
              const analysesRes = await fetch('/api/analyses', {
                headers: { Authorization: `Bearer ${storedToken}` },
              });
              if (analysesRes.ok && isMounted) {
                const list = await analysesRes.json();
                setSavedAnalyses(list);
              }
            } catch {
              // non-fatal
            }
          } else {
            // Invalid / expired token, clear storage
            localStorage.removeItem(TOKEN_STORAGE_KEY);
          }
        })
        .catch((err) => {
          console.warn('Session verification error:', err);
        })
        .finally(() => {
          if (isMounted) setLoading(false);
        });
    } else {
      setLoading(false);
    }

    // Keep Firebase Auth state listener as secondary observer
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (!isMounted) return;
      if (firebaseUser) {
        try {
          const token = await firebaseUser.getIdToken();
          localStorage.setItem(TOKEN_STORAGE_KEY, token);
          setIdToken(token);
          setCurrentUser(firebaseUser);
          await syncWithBackend(token, firebaseUser);

          // Fetch saved records
          try {
            const analysesRes = await fetch('/api/analyses', {
              headers: { Authorization: `Bearer ${token}` },
            });
            if (analysesRes.ok && isMounted) {
              const list = await analysesRes.json();
              setSavedAnalyses(list);
            }
          } catch {
            // non-fatal
          }
        } catch (err) {
          console.error('Error fetching Firebase token:', err);
        }
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [syncWithBackend]);

  const signInWithEmail = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: data.error || 'Authentication failed. Please check your credentials.',
        };
      }

      localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
      setIdToken(data.token);
      setCurrentUser({
        uid: data.user.uid,
        email: data.user.email,
        displayName: data.user.displayName,
        photoURL: data.user.photoUrl || data.user.photoURL || null,
      });

      if (data.credentials) {
        setCredentials(data.credentials);
      }

      // Fetch analyses
      try {
        const analysesRes = await fetch('/api/analyses', {
          headers: { Authorization: `Bearer ${data.token}` },
        });
        if (analysesRes.ok) {
          const list = await analysesRes.json();
          setSavedAnalyses(list);
        }
      } catch {
        // non-fatal
      }

      return { success: true };
    } catch (err: any) {
      console.error('Sign in error:', err);
      return {
        success: false,
        error: err.message || 'Network error connecting to authentication service.',
      };
    }
  };

  const signUpWithEmail = async (
    email: string,
    password: string,
    displayName?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, displayName }),
      });

      const data = await res.json();
      if (!res.ok) {
        return {
          success: false,
          error: data.error || 'Registration failed. Please check your inputs.',
        };
      }

      localStorage.setItem(TOKEN_STORAGE_KEY, data.token);
      setIdToken(data.token);
      setCurrentUser({
        uid: data.user.uid,
        email: data.user.email,
        displayName: data.user.displayName,
        photoURL: data.user.photoUrl || data.user.photoURL || null,
      });

      if (data.credentials) {
        setCredentials(data.credentials);
      }

      return { success: true };
    } catch (err: any) {
      console.error('Sign up error:', err);
      return {
        success: false,
        error: err.message || 'Network error during registration.',
      };
    }
  };

  const signInWithGoogle = async () => {
    try {
      const cred = await signInWithPopup(auth, googleAuthProvider);
      if (cred && cred.user) {
        const token = await cred.user.getIdToken();
        localStorage.setItem(TOKEN_STORAGE_KEY, token);
        setIdToken(token);
        setCurrentUser(cred.user);
        await syncWithBackend(token, cred.user);
      }
    } catch (err: any) {
      console.error('Google Sign-In failed:', err);
      throw err;
    }
  };

  const signOut = async () => {
    try {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
      await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
      try {
        await firebaseSignOut(auth);
      } catch {
        // Ignore if not signed in with Firebase
      }
      setIdToken(null);
      setCurrentUser(null);
      setCredentials(null);
      setSavedAnalyses([]);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const saveCredentials = async (creds: UserCredentials): Promise<boolean> => {
    const activeToken = idToken || localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!activeToken) return false;
    try {
      const res = await fetch('/api/credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${activeToken}`,
        },
        body: JSON.stringify(creds),
      });
      if (res.ok) {
        const data = await res.json();
        setCredentials(data);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to save credentials:', err);
      return false;
    }
  };

  const saveAnalysisToCloud = async (report: AnalysisReport): Promise<boolean> => {
    const activeToken = idToken || localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!activeToken) return false;
    setIsSavingAnalysis(true);
    try {
      const res = await fetch('/api/analyses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${activeToken}`,
        },
        body: JSON.stringify({
          candidateName: report.resumeData?.candidate?.name || 'Candidate',
          targetRole: report.targetRole,
          targetCompany: report.targetCompany,
          totalScore: report.scoreResult?.totalScore || 0,
          alignmentLevel: report.scoreResult?.alignmentLevel || 'Moderate Match',
          reportData: report,
        }),
      });

      if (res.ok) {
        await refreshUserData();
        setIsSavingAnalysis(false);
        return true;
      }
      setIsSavingAnalysis(false);
      return false;
    } catch (err) {
      console.error('Failed to save analysis to Cloud SQL:', err);
      setIsSavingAnalysis(false);
      return false;
    }
  };

  const deleteAnalysisFromCloud = async (id: number): Promise<boolean> => {
    const activeToken = idToken || localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!activeToken) return false;
    try {
      const res = await fetch(`/api/analyses/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${activeToken}` },
      });
      if (res.ok) {
        setSavedAnalyses((prev) => prev.filter((a) => a.id !== id));
        return true;
      }
      return false;
    } catch (err) {
      console.error('Failed to delete analysis:', err);
      return false;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loading,
        idToken,
        credentials,
        savedAnalyses,
        isSavingAnalysis,
        signInWithEmail,
        signUpWithEmail,
        signInWithGoogle,
        signOut,
        saveCredentials,
        saveAnalysisToCloud,
        deleteAnalysisFromCloud,
        refreshUserData,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
