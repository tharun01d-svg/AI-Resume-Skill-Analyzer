import {
  AnalysisReport,
  ApplicationReadiness,
  ReadinessLevel,
  ResumeData,
  JobData,
  ScoreResult,
} from '../types/analyzer';
import {
  buildHeuristicResumeData,
  buildHeuristicJobData,
  buildHeuristicRecommendations,
} from '../../server/fallbackParser';
import { runSkillMatching } from '../../server/matchingEngine';
import { calculateExplainableScore } from '../../server/scoringEngine';

export function computeApplicationReadiness(
  scoreResult: ScoreResult,
  resumeData: ResumeData,
  jobData: JobData
): ApplicationReadiness {
  const reqCat = scoreResult.categories.required_skills;
  const reqPct = reqCat.is_applicable && reqCat.max > 0 ? (reqCat.earned / reqCat.max) * 100 : 75;
  const skillsLevel: ReadinessLevel = reqPct >= 75 ? 'Strong' : reqPct >= 50 ? 'Moderate' : 'Needs Improvement';

  const candidateYears = resumeData.total_experience_years || 0;
  const reqYears = jobData.experience_requirements.min_years || 2;
  let expLevel: ReadinessLevel = 'Moderate';
  if (candidateYears >= reqYears) {
    expLevel = 'Strong';
  } else if (candidateYears < Math.max(0, reqYears - 1.5)) {
    expLevel = 'Needs Improvement';
  }

  const projCat = scoreResult.categories.projects;
  const projPct = projCat.is_applicable && projCat.max > 0 ? (projCat.earned / projCat.max) * 100 : 70;
  const projLevel: ReadinessLevel = projPct >= 70 ? 'Strong' : projPct >= 40 ? 'Moderate' : 'Needs Improvement';

  const rqCat = scoreResult.categories.resume_quality;
  const rqPct = rqCat.max > 0 ? (rqCat.earned / rqCat.max) * 100 : 75;
  const rqLevel: ReadinessLevel = rqPct >= 70 ? 'Strong' : rqPct >= 45 ? 'Moderate' : 'Needs Improvement';

  const roleLevel: ReadinessLevel =
    scoreResult.totalScore >= 75 ? 'Strong' : scoreResult.totalScore >= 55 ? 'Moderate' : 'Needs Improvement';

  return {
    skills: skillsLevel,
    experience: expLevel,
    projects: projLevel,
    resumeQuality: rqLevel,
    roleAlignment: roleLevel,
    summary: `Candidate profile indicates ${skillsLevel.toLowerCase()} technical skill alignment, ${expLevel.toLowerCase()} experience alignment, and ${roleLevel.toLowerCase()} overall readiness for ${jobData.job_title} at ${jobData.company_inferred}.`,
  };
}

export function runClientSidePipeline(params: {
  resumeText: string;
  jobDescription?: string;
  resumeFileName?: string;
  resumeFileType?: string;
  resumeFileSize?: number;
  resumePageCount?: number;
  targetCompany: string;
  targetRole: string;
  experienceLevel: string;
  targetGoal?: string;
}): AnalysisReport {
  const {
    resumeText,
    jobDescription,
    resumeFileName,
    resumeFileType,
    resumeFileSize,
    resumePageCount,
    targetCompany,
    targetRole,
    experienceLevel,
    targetGoal,
  } = params;

  const isJobDescriptionSupplied = Boolean(jobDescription && jobDescription.trim().length >= 20);

  let effectiveJobText = jobDescription?.trim() || '';
  if (!isJobDescriptionSupplied) {
    effectiveJobText = `Target Role: ${targetRole}
Target Company: ${targetCompany}
Seniority Level: ${experienceLevel}

Role Context:
This analysis evaluates competencies commonly associated with the role of ${targetRole} at leading organizations comparable to ${targetCompany} at the ${experienceLevel} experience tier. Key technical standards, engineering foundations, collaboration, and ownership capabilities commonly expected for this level are evaluated.`;
  }

  const effectiveMeta = {
    title: targetRole,
    company: targetCompany,
    level: experienceLevel,
    isJobDescriptionSupplied,
  };

  // Step 1: Parse resume data using structural heuristic engine
  const resumeData = buildHeuristicResumeData(resumeText);

  // Step 2: Parse job data using domain ontology engine
  const jobData = buildHeuristicJobData(effectiveJobText, effectiveMeta);

  // Step 3: Run exact & semantic skill matching
  const skillMatches = runSkillMatching(resumeData, jobData);

  // Step 4: Calculate explainable 100-point score
  const scoreResult = calculateExplainableScore(resumeData, jobData, skillMatches);

  // Step 5: Generate recommendations & roadmap
  const recommendations = buildHeuristicRecommendations(
    resumeData,
    jobData,
    skillMatches,
    scoreResult,
    targetGoal
  );

  // Step 6: Application readiness
  const applicationReadiness = computeApplicationReadiness(scoreResult, resumeData, jobData);

  return {
    id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    timestamp: new Date().toISOString(),
    resumeFileName: resumeFileName || 'Uploaded_Resume.pdf',
    resumeFileType: resumeFileType || (resumeFileName?.toLowerCase().endsWith('.docx') ? 'DOCX' : 'PDF'),
    resumeFileSize: resumeFileSize,
    resumePageCount: resumePageCount,
    targetCompany,
    targetRole,
    experienceLevel,
    isJobDescriptionSupplied,
    applicationReadiness,
    targetGoal,
    resumeData,
    jobData,
    skillMatches,
    scoreResult,
    recommendations,
  };
}

export function evaluateRoleForResume(params: {
  resumeData: ResumeData;
  targetRole: string;
  targetCompany: string;
  experienceLevel: string;
  jobDescription?: string;
  targetGoal?: string;
}) {
  const { resumeData, targetRole, targetCompany, experienceLevel, jobDescription, targetGoal } = params;
  const isJobDescriptionSupplied = Boolean(jobDescription && jobDescription.trim().length >= 20);

  let effectiveJobText = jobDescription?.trim() || '';
  if (!isJobDescriptionSupplied) {
    effectiveJobText = `Target Role: ${targetRole}
Target Company: ${targetCompany}
Seniority Level: ${experienceLevel}

Role Context:
This analysis evaluates competencies commonly associated with the role of ${targetRole} at leading organizations comparable to ${targetCompany} at the ${experienceLevel} experience tier. Key technical standards, engineering foundations, collaboration, and ownership capabilities commonly expected for this level are evaluated.`;
  }

  const effectiveMeta = {
    title: targetRole,
    company: targetCompany,
    level: experienceLevel,
    isJobDescriptionSupplied,
  };

  const jobData = buildHeuristicJobData(effectiveJobText, effectiveMeta);
  const skillMatches = runSkillMatching(resumeData, jobData);
  const scoreResult = calculateExplainableScore(resumeData, jobData, skillMatches);
  const recommendations = buildHeuristicRecommendations(
    resumeData,
    jobData,
    skillMatches,
    scoreResult,
    targetGoal
  );
  const applicationReadiness = computeApplicationReadiness(scoreResult, resumeData, jobData);

  return {
    targetRole,
    targetCompany,
    experienceLevel,
    jobData,
    skillMatches,
    scoreResult,
    recommendations,
    applicationReadiness,
  };
}
