import { useEffect, useState } from 'react';
import type { Transition, Variants } from 'motion/react';

// ==========================================
// 1. TIMING & EASING PRESETS
// ==========================================
export const EASINGS = {
  // Smooth cubic bezier easing for premium SaaS motion
  smoothOut: [0.22, 1, 0.36, 1] as [number, number, number, number],
  smoothInOut: [0.65, 0, 0.35, 1] as [number, number, number, number],
  bounceSoft: [0.34, 1.56, 0.64, 1] as [number, number, number, number],
};

export const TRANSITIONS = {
  fast: { duration: 0.18, ease: EASINGS.smoothOut } as Transition,
  normal: { duration: 0.3, ease: EASINGS.smoothOut } as Transition,
  medium: { duration: 0.45, ease: EASINGS.smoothOut } as Transition,
  slow: { duration: 0.7, ease: EASINGS.smoothOut } as Transition,
};

// ==========================================
// 2. REUSABLE ANIMATION VARIANTS
// ==========================================

// Page Transitions (A-to-Z Seamless Journey)
export const pageVariants: Variants = {
  initial: {
    opacity: 0,
    y: 12,
  },
  animate: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.32,
      ease: EASINGS.smoothOut,
      when: 'beforeChildren',
    },
  },
  exit: {
    opacity: 0,
    y: -8,
    transition: {
      duration: 0.2,
      ease: 'easeIn',
    },
  },
};

// Subtle Content Fade + Slide
export const fadeUpVariants: Variants = {
  initial: { opacity: 0, y: 14 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: EASINGS.smoothOut },
  },
  exit: {
    opacity: 0,
    y: -8,
    transition: { duration: 0.2 },
  },
};

// Simple Fade
export const fadeInVariants: Variants = {
  initial: { opacity: 0 },
  animate: { opacity: 1, transition: { duration: 0.25 } },
  exit: { opacity: 0, transition: { duration: 0.18 } },
};

// Staggered Container
export const createStaggerContainer = (staggerChildren = 0.05, delayChildren = 0): Variants => ({
  initial: {},
  animate: {
    transition: {
      staggerChildren,
      delayChildren,
    },
  },
});

export const staggerItemVariants: Variants = {
  initial: { opacity: 0, y: 12 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3, ease: EASINGS.smoothOut },
  },
};

export const listItemVariants = staggerItemVariants;

// Modal Backdrop & Content
export const modalOverlayVariants: Variants = {
  initial: { opacity: 0 },
  animate: { opacity: 1, transition: { duration: 0.24, ease: 'easeOut' } },
  exit: { opacity: 0, transition: { duration: 0.18, ease: 'easeIn' } },
};

export const modalDialogVariants: Variants = {
  initial: { opacity: 0, scale: 0.95, y: 10 },
  animate: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.28, ease: EASINGS.smoothOut },
  },
  exit: {
    opacity: 0,
    scale: 0.96,
    y: 8,
    transition: { duration: 0.18, ease: 'easeIn' },
  },
};

// Dropdown / Popover Variants
export const dropdownVariants: Variants = {
  initial: { opacity: 0, scale: 0.97, y: -6 },
  animate: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { duration: 0.18, ease: EASINGS.smoothOut },
  },
  exit: {
    opacity: 0,
    scale: 0.97,
    y: -4,
    transition: { duration: 0.12, ease: 'easeIn' },
  },
};

// Expand / Collapse Accordion
export const accordionVariants: Variants = {
  initial: { opacity: 0, height: 0, overflow: 'hidden' },
  animate: {
    opacity: 1,
    height: 'auto',
    overflow: 'visible',
    transition: {
      height: { duration: 0.28, ease: EASINGS.smoothOut },
      opacity: { duration: 0.24, delay: 0.05 },
    },
  },
  exit: {
    opacity: 0,
    height: 0,
    overflow: 'hidden',
    transition: {
      opacity: { duration: 0.15 },
      height: { duration: 0.22, ease: 'easeIn' },
    },
  },
};

// ==========================================
// 3. HOOKS: COUNT-UP FOR NUMERICAL SCORES
// ==========================================
/**
 * Smoothly animates an integer from 0 to endValue using requestAnimationFrame and easeOutCubic.
 * Strictly guarantees ending at the exact target value.
 */
export function useCountUp(endValue: number, durationMs = 1200, startImmediately = true): number {
  const [currentValue, setCurrentValue] = useState<number>(startImmediately ? 0 : endValue);

  useEffect(() => {
    if (!startImmediately) {
      setCurrentValue(endValue);
      return;
    }

    // Check prefers-reduced-motion
    if (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setCurrentValue(endValue);
      return;
    }

    let startTimestamp: number | null = null;
    let animationFrameId: number;

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / durationMs, 1);
      
      // easeOutCubic: 1 - pow(1 - progress, 3)
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const computedValue = Math.round(easeProgress * endValue);
      
      setCurrentValue(computedValue);

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(step);
      } else {
        setCurrentValue(endValue); // strictly ensure end value
      }
    };

    animationFrameId = requestAnimationFrame(step);

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
    };
  }, [endValue, durationMs, startImmediately]);

  return currentValue;
}

// ==========================================
// 4. ACCESSIBILITY: REDUCED MOTION DETECTION
// ==========================================
export function usePrefersReducedMotion(): boolean {
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);

    const listener = (event: MediaQueryListEvent) => {
      setPrefersReducedMotion(event.matches);
    };

    mediaQuery.addEventListener('change', listener);
    return () => mediaQuery.removeEventListener('change', listener);
  }, []);

  return prefersReducedMotion;
}
