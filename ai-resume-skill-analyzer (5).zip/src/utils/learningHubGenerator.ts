import {
  AnalysisReport,
  SkillMatch,
  PriorityLevel,
  EvidenceLevel,
} from '../types/analyzer';

export type LearningPriority = 'HIGH' | 'MEDIUM' | 'LONG_TERM';

export interface YouTubeResource {
  title: string;
  channel: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Beginner to Intermediate' | 'Intermediate to Advanced' | 'All Levels';
  duration: string;
  topics: string[];
  url: string;
  isSearchFallback?: boolean;
}

export interface FreeCourseResource {
  title: string;
  platform: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Beginner to Intermediate' | 'Intermediate to Advanced' | 'All Levels';
  duration: string;
  freeStatus: string;
  certificateAvailability: string;
  url: string;
}

export interface CertificateCourseResource {
  title: string;
  platform: string;
  skill: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Beginner to Intermediate' | 'Intermediate to Advanced' | 'Professional' | 'All Levels';
  duration: string;
  certificateAvailability: string;
  priceStatus: string;
  whyRelevant: string;
  url: string;
}

export interface OfficialDocResource {
  title: string;
  publisher: string;
  description: string;
  keySections: string[];
  url: string;
}

export interface PracticePlatformResource {
  name: string;
  focus: string;
  recommendedProblems: string[];
  url: string;
}

export interface ProjectLearningResource {
  title: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  techStack: string[];
  problemStatement: string;
  features: string[];
  evidenceGoal: string;
}

export interface PersonalizedSkillRecommendation {
  id: string;
  skill: string;
  priority: LearningPriority;
  currentEvidence: string;
  currentLevel: string;
  gap: string;
  whyItMatters: string;
  whatToLearn: string[];
  youtube: YouTubeResource[];
  freeCourses: FreeCourseResource[];
  certificateCourses: CertificateCourseResource[];
  officialDocs: OfficialDocResource[];
  practicePlatforms: PracticePlatformResource[];
  projects: ProjectLearningResource[];
  expectedOutcome: string;
}

export interface RoadmapStage {
  stage: '30_DAYS' | '60_DAYS' | '90_DAYS';
  title: string;
  timeframe: string;
  tagline: string;
  skills: string[];
  topics: string[];
  learningResources: Array<{ name: string; platform: string; type: string; url: string }>;
  practiceTasks: string[];
  milestoneProject: {
    title: string;
    description: string;
    deliverables: string[];
    portfolioEvidence: string;
  };
}

export interface PersonalizedLearningHubData {
  roleTitle: string;
  targetCompany: string;
  experienceLevel: string;
  totalGapsIdentified: number;
  recommendations: PersonalizedSkillRecommendation[];
  roadmap: {
    thirtyDays: RoadmapStage;
    sixtyDays: RoadmapStage;
    ninetyDays: RoadmapStage;
  };
  careerNavigation: {
    resumeAction: string;
    skillMatrixAction: string;
    projectAction: string;
    careerLevelAction: string;
  };
}

interface DomainSkillInfo {
  canonicalName: string;
  category: string;
  whyItMattersTemplate: (role: string, company: string) => string;
  gapTemplate: (evidence: string, role: string) => string;
  whatToLearn: string[];
  youtube: YouTubeResource[];
  freeCourses: FreeCourseResource[];
  certificateCourses: CertificateCourseResource[];
  officialDocs: OfficialDocResource[];
  practicePlatforms: PracticePlatformResource[];
  project: ProjectLearningResource;
  expectedOutcome: string;
}

// Curated verified knowledge base for high-frequency technical disciplines
const VERIFIED_SKILL_CATALOG: Record<string, DomainSkillInfo> = {
  react: {
    canonicalName: 'React.js',
    category: 'Frontend Framework',
    whyItMattersTemplate: (role, company) =>
      `Modern ${role} positions at organizations like ${company} require responsive component design, robust hooks lifecycle management, and scalable frontend state architecture.`,
    gapTemplate: (evidence, role) =>
      evidence.includes('No evidence')
        ? `The target ${role} role prioritizes practical React.js web development, but no direct evidence was identified in the resume.`
        : `Resume demonstrates partial frontend familiarity, but lacks evidence of modern React hooks, state management, and high-performance component rendering required for ${role}.`,
    whatToLearn: [
      'React fundamentals & JSX rendering tree mechanics',
      'Modular functional components, props contracts, and conditional rendering',
      'Advanced Hooks: useState, useEffect, useMemo, useCallback, useRef',
      'Custom reusable hooks and asynchronous API data fetching with error boundaries',
      'State management patterns (Context API, Redux Toolkit, or Zustand)',
      'Client-side routing with React Router v6+ & nested layouts',
      'Performance profiling, memoization, and Core Web Vitals optimization',
      'Production test suites with React Testing Library & Vitest',
    ],
    youtube: [
      {
        title: 'React JS Full Course 2024 / 2025 - Beginner to Pro',
        channel: 'freeCodeCamp.org',
        level: 'Beginner',
        duration: '11.5 hours',
        topics: ['Components', 'Props & State', 'Hooks', 'APIs', 'Full Application'],
        url: 'https://www.youtube.com/results?search_query=freeCodeCamp+React+JS+full+course',
      },
      {
        title: 'React 18 & 19 In-Depth Architecture Tutorial',
        channel: 'Traversy Media',
        level: 'Intermediate',
        duration: '4.5 hours',
        topics: ['Component Structure', 'Custom Hooks', 'Tailwind Integration', 'Deployment'],
        url: 'https://www.youtube.com/results?search_query=Traversy+Media+React+tutorial+crash+course',
      },
      {
        title: 'React Performance Optimization & Advanced Hooks',
        channel: 'Web Dev Simplified',
        level: 'Advanced',
        duration: '2.5 hours',
        topics: ['useMemo & useCallback', 'Re-rendering bottlenecks', 'Profiler API'],
        url: 'https://www.youtube.com/results?search_query=Web+Dev+Simplified+React+Hooks+In+Depth',
      },
    ],
    freeCourses: [
      {
        title: 'Frontend Development Libraries (React & Redux)',
        platform: 'freeCodeCamp',
        level: 'All Levels',
        duration: '300 hours (modular curriculum)',
        freeStatus: '100% Free',
        certificateAvailability: 'Free Verified Certification',
        url: 'https://www.freecodecamp.org/learn/front-end-development-libraries/',
      },
      {
        title: 'Full Stack Open - Deep Dive Into Modern Web Development (React Module)',
        platform: 'University of Helsinki',
        level: 'Intermediate',
        duration: '6 weeks',
        freeStatus: '100% Free',
        certificateAvailability: 'Free Certificate upon project completion',
        url: 'https://fullstackopen.com/en/',
      },
    ],
    certificateCourses: [
      {
        title: 'Meta Front-End Developer Professional Certificate (React Specialization)',
        platform: 'Coursera',
        skill: 'React.js & Frontend Architecture',
        level: 'Professional',
        duration: '4-7 months (flexible pace)',
        certificateAvailability: 'Shareable Professional Certificate',
        priceStatus: 'Free to Audit / Paid Certificate & Financial Aid Available',
        whyRelevant: 'Created by Meta (creators of React) covering industry UI patterns and best practices.',
        url: 'https://www.coursera.org/professional-certificates/meta-front-end-developer',
      },
      {
        title: 'Developing Front-End Apps with React',
        platform: 'edX / IBM',
        skill: 'React.js Component Architecture',
        level: 'Intermediate',
        duration: '4 weeks',
        certificateAvailability: 'Verified Certificate Available',
        priceStatus: 'Free Audit Available / Paid Certificate Option',
        whyRelevant: 'Comprehensive hands-on labs with stateful React apps and asynchronous service integration.',
        url: 'https://www.edx.org/search?q=IBM+Developing+Front-End+Apps+with+React',
      },
    ],
    officialDocs: [
      {
        title: 'React Official Documentation (Interactive Learn Guide)',
        publisher: 'React Core Team (Meta)',
        description: 'The official canonical guide to thinking in React, escape hatches, hooks, and modern suspense mechanics.',
        keySections: ['Describing the UI', 'Adding Interactivity', 'Managing State', 'Escape Hatches'],
        url: 'https://react.dev/learn',
      },
      {
        title: 'MDN Web Docs - React Framework Overview',
        publisher: 'Mozilla MDN',
        description: 'Comprehensive web standards reference on component lifecycle, bundling, and client accessibility.',
        keySections: ['Getting started with React', 'React components and state', 'Accessibility in React'],
        url: 'https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Client-side_JavaScript_frameworks/React_getting_started',
      },
    ],
    practicePlatforms: [
      {
        name: 'Frontend Mentor',
        focus: 'Real-world responsive React UI challenges from Figma designs',
        recommendedProblems: ['Interactive Comments Section', 'E-Commerce Product Page', 'REST Countries API App with Color Theme'],
        url: 'https://www.frontendmentor.io/challenges?languages=react',
      },
      {
        name: 'LeetCode',
        focus: 'Frontend coding questions and JavaScript/DOM challenges',
        recommendedProblems: ['30 Days of JavaScript', 'Event Emitter', 'Debounce & Throttle Implementation'],
        url: 'https://leetcode.com/problemset/javascript/',
      },
    ],
    project: {
      title: 'Full-Featured SaaS Collaborative Dashboard',
      difficulty: 'Intermediate',
      techStack: ['React 18', 'TypeScript', 'Tailwind CSS', 'TanStack Query', 'Chart.js'],
      problemStatement: 'Build a production-grade analytics dashboard that fetches streaming metrics, supports dark/light themes, provides client-side sorting/filtering, and includes responsive data tables.',
      features: [
        'Secure multi-page layout with custom authentication state wrapper',
        'Optimistic updates and caching with React Query',
        'Complex compound components (modals, dropdowns, data tables)',
        'Comprehensive unit tests with Vitest and React Testing Library',
      ],
      evidenceGoal: 'Deploy live on Vercel/Netlify with public GitHub repository including unit test coverage report.',
    },
    expectedOutcome:
      'Indisputable proof of modern React competence capable of architecting modular, accessible UI features for high-traffic web applications.',
  },

  typescript: {
    canonicalName: 'TypeScript',
    category: 'Programming Language',
    whyItMattersTemplate: (role, company) =>
      `Enterprise engineering at ${company} relies on TypeScript for type safety, self-documenting codebases, and catching runtime defects before deployment in ${role} workflows.`,
    gapTemplate: (evidence, role) =>
      `While JavaScript experience is evident, ${role} candidates need concrete evidence of strong typing, generics, utility types, and strict compiler configs.`,
    whatToLearn: [
      'Basic typing: primitives, unions, intersections, and literal types',
      'Interfaces vs type aliases & declaration merging',
      'Advanced generics with constraints (extends keyof, conditional types)',
      'Mapped types, template literal types, and built-in utility types (Pick, Omit, Partial, Record)',
      'Strict tsconfig configuration for enterprise safety',
      'Type narrowing, discriminated unions, and custom type guards',
      'TypeScript with Node.js / Express & React component prop contracts',
    ],
    youtube: [
      {
        title: 'TypeScript Full Course for Beginners',
        channel: 'freeCodeCamp.org',
        level: 'Beginner',
        duration: '5 hours',
        topics: ['Types', 'Functions', 'Interfaces', 'Generics', 'Modules'],
        url: 'https://www.youtube.com/results?search_query=freeCodeCamp+TypeScript+course',
      },
      {
        title: 'TypeScript in 100 Seconds & Deep Dive',
        channel: 'Fireship',
        level: 'Intermediate',
        duration: '1.5 hours',
        topics: ['Core syntax', 'Generics', 'Utility types', 'Best practices'],
        url: 'https://www.youtube.com/results?search_query=Fireship+TypeScript+tutorial',
      },
      {
        title: 'Advanced TypeScript: Type Gymnastics & Generics',
        channel: 'Matt Pocock (Total TypeScript)',
        level: 'Advanced',
        duration: '3 hours',
        topics: ['Inferred types', 'Conditional types', 'Generic constraints'],
        url: 'https://www.youtube.com/results?search_query=Matt+Pocock+Total+TypeScript+tutorials',
      },
    ],
    freeCourses: [
      {
        title: 'Total TypeScript - Beginner Essentials & Generics Tutorial',
        platform: 'Total TypeScript',
        level: 'All Levels',
        duration: 'Self-paced',
        freeStatus: '100% Free Tutorials',
        certificateAvailability: 'Skill Badges Available',
        url: 'https://www.totaltypescript.com/tutorials',
      },
      {
        title: 'TypeScript for JavaScript Programmers',
        platform: 'Microsoft Learn',
        level: 'Beginner to Intermediate',
        duration: '4 hours',
        freeStatus: '100% Free',
        certificateAvailability: 'Microsoft Achievement Badge',
        url: 'https://learn.microsoft.com/en-us/training/paths/build-javascript-applications-typescript/',
      },
    ],
    certificateCourses: [
      {
        title: 'TypeScript Essential Training',
        platform: 'LinkedIn Learning',
        skill: 'TypeScript Architecture',
        level: 'Intermediate',
        duration: '3 hours',
        certificateAvailability: 'Shareable LinkedIn Learning Certificate',
        priceStatus: 'Included with LinkedIn Learning / Free Month Trial',
        whyRelevant: 'Industry-standard curriculum covering modules, decorators, and modern tooling integration.',
        url: 'https://www.linkedin.com/learning/search?keywords=TypeScript+Essential+Training',
      },
      {
        title: 'Understanding TypeScript - 2025 Edition',
        platform: 'Udemy (Maximilian Schwarzmüller)',
        skill: 'End-to-End TypeScript Mastery',
        level: 'Intermediate',
        duration: '15 hours',
        certificateAvailability: 'Udemy Certificate of Completion',
        priceStatus: 'Paid Course / Frequent Discounts',
        whyRelevant: 'Deep dive from ground up to complex compiler configs, 3rd party libraries, and full-stack projects.',
        url: 'https://www.udemy.com/course/understanding-typescript/',
      },
    ],
    officialDocs: [
      {
        title: 'TypeScript Handbook (Official Language Documentation)',
        publisher: 'Microsoft TypeScript Team',
        description: 'The authoritative source on type system semantics, narrowing, generics, and compiler options.',
        keySections: ['The Basics', 'Everyday Types', 'Generics', 'Type Manipulation', 'Utility Types'],
        url: 'https://www.typescriptlang.org/docs/handbook/intro.html',
      },
    ],
    practicePlatforms: [
      {
        name: 'Type Challenges',
        focus: 'Interactive TypeScript type gymnastics exercises from easy to extreme',
        recommendedProblems: ['Pick', 'Readonly', 'Tuple to Object', 'First of Array', 'Awaited'],
        url: 'https://github.com/type-challenges/type-challenges',
      },
      {
        name: 'Exercism',
        focus: 'Mentored TypeScript track with automated test verification',
        recommendedProblems: ['Two Fer', 'Resistor Color', 'Space Age', 'Pancake Sort'],
        url: 'https://exercism.org/tracks/typescript',
      },
    ],
    project: {
      title: 'Type-Safe REST API & SDK Generator with Strict Validation',
      difficulty: 'Intermediate',
      techStack: ['TypeScript (strict: true)', 'Node.js', 'Zod', 'Express', 'Vitest'],
      problemStatement: 'Design a strongly typed backend service with runtime request validation (Zod) and automated client SDK type generation, ensuring zero "any" types throughout the repository.',
      features: [
        'Strict tsconfig with noImplicitAny, strictNullChecks, and exactOptionalPropertyTypes',
        'Shared polymorphic types between domain contracts and HTTP responses',
        'Generic repository pattern interfacing with database models',
      ],
      evidenceGoal: 'Publish library or API template to GitHub with zero compiler warnings and 100% test coverage.',
    },
    expectedOutcome:
      'Ability to write clean, self-documenting TypeScript code that prevents runtime errors and facilitates rapid team collaboration.',
  },

  python: {
    canonicalName: 'Python',
    category: 'Programming Language',
    whyItMattersTemplate: (role, company) =>
      `Python serves as a fundamental building block for backend APIs, data pipelines, and automation systems at ${company} for ${role} roles.`,
    gapTemplate: (evidence, role) =>
      `The target ${role} position requires practical Python development, but resume lacks demonstrable project evidence or framework usage.`,
    whatToLearn: [
      'Core syntax, list comprehensions, generators, and iterators',
      'Object-oriented programming, dataclasses, and inheritance patterns',
      'Type hinting with mypy and Pydantic validation models',
      'Asynchronous programming with asyncio and concurrent.futures',
      'Web frameworks (FastAPI or Django) and REST API development',
      'Database integration via SQLAlchemy ORM or asyncpg',
      'Automated testing with pytest and mock fixtures',
    ],
    youtube: [
      {
        title: 'Python for Beginners - Full Course (2024)',
        channel: 'Programming with Mosh',
        level: 'Beginner',
        duration: '6 hours',
        topics: ['Data structures', 'OOP', 'Packages', 'File handling'],
        url: 'https://www.youtube.com/results?search_query=Programming+with+Mosh+Python+tutorial',
      },
      {
        title: 'FastAPI - Modern Python Web APIs Course',
        channel: 'freeCodeCamp.org',
        level: 'Intermediate',
        duration: '4.5 hours',
        topics: ['Pydantic', 'Dependency Injection', 'Database ORM', 'JWT Authentication'],
        url: 'https://www.youtube.com/results?search_query=freeCodeCamp+FastAPI+tutorial+Python',
      },
      {
        title: 'Python OOP & Advanced Design Patterns',
        channel: 'Corey Schafer',
        level: 'Advanced',
        duration: '3 hours',
        topics: ['Dunder methods', 'Decorators', 'Generators', 'Context Managers'],
        url: 'https://www.youtube.com/results?search_query=Corey+Schafer+Python+OOP+tutorials',
      },
    ],
    freeCourses: [
      {
        title: 'Scientific Computing with Python',
        platform: 'freeCodeCamp',
        level: 'All Levels',
        duration: '300 hours (modular curriculum)',
        freeStatus: '100% Free',
        certificateAvailability: 'Free Verified Certification',
        url: 'https://www.freecodecamp.org/learn/scientific-computing-with-python/',
      },
      {
        title: 'CS50\'s Introduction to Programming with Python',
        platform: 'Harvard University / edX',
        level: 'Beginner to Intermediate',
        duration: '10 weeks',
        freeStatus: 'Free Course Audit',
        certificateAvailability: 'Verified Certificate Available',
        url: 'https://cs50.harvard.edu/python/',
      },
    ],
    certificateCourses: [
      {
        title: 'Google IT Automation with Python Professional Certificate',
        platform: 'Coursera',
        skill: 'Python Automation & System Administration',
        level: 'Professional',
        duration: '6 months',
        certificateAvailability: 'Google Professional Certificate',
        priceStatus: 'Free to Audit / Paid Certificate & Financial Aid Available',
        whyRelevant: 'Taught by Google engineers covering Git, system automation, and cloud deployments.',
        url: 'https://www.coursera.org/professional-certificates/google-it-automation',
      },
    ],
    officialDocs: [
      {
        title: 'The Python Tutorial (Official 3.12+ Documentation)',
        publisher: 'Python Software Foundation',
        description: 'The standard reference for Python language syntax, standard library modules, and packaging.',
        keySections: ['Data Structures', 'Modules', 'Classes', 'Standard Library Tour'],
        url: 'https://docs.python.org/3/tutorial/',
      },
    ],
    practicePlatforms: [
      {
        name: 'LeetCode',
        focus: 'Data structures & algorithm interview preparation in Python',
        recommendedProblems: ['Two Sum', 'Valid Anagram', 'Group Anagrams', 'Top K Frequent Elements'],
        url: 'https://leetcode.com/problemset/all/?difficulty=EASY&page=1',
      },
      {
        name: 'Exercism',
        focus: 'Hands-on idiomatic Python exercises with automated tests',
        recommendedProblems: ['Raindrops', 'Matrix', 'High Scores', 'Grade School'],
        url: 'https://exercism.org/tracks/python',
      },
    ],
    project: {
      title: 'High-Performance Asynchronous REST API with FastAPI & PostgreSQL',
      difficulty: 'Intermediate',
      techStack: ['Python 3.12', 'FastAPI', 'SQLAlchemy (async)', 'PostgreSQL', 'Docker', 'pytest'],
      problemStatement: 'Architect a backend web service with asynchronous database connection pools, JWT bearer token auth, rate limiting, and automated API documentation.',
      features: [
        'Pydantic v2 data serialization and strict schema validation',
        'Database migrations managed with Alembic',
        'Comprehensive test suite with pytest and HTTP client fixtures',
      ],
      evidenceGoal: 'Deploy containerized service to cloud with Swagger UI docs and GitHub Actions CI workflow.',
    },
    expectedOutcome:
      'Ability to build scalable Python web services and asynchronous background workers adhering to PEP 8 and modern type hints.',
  },

  docker: {
    canonicalName: 'Docker & Containerization',
    category: 'DevOps & Infrastructure',
    whyItMattersTemplate: (role, company) =>
      `Modern engineering at ${company} depends on Docker containers to guarantee reproducible build environments and seamless deployment in ${role} positions.`,
    gapTemplate: (evidence, role) =>
      `While development capability is established, the candidate profile lacks direct evidence of multi-stage Dockerfiles, image optimization, or container orchestration required for ${role}.`,
    whatToLearn: [
      'Container architecture vs virtual machines & Linux cgroups/namespaces',
      'Writing efficient multi-stage Dockerfiles to minimize image footprint',
      'Docker Compose for multi-container local development (App + DB + Redis)',
      'Volume mounting, data persistence, and bridge network configuration',
      'Container security: running as non-root, minimal alpine/distroless base images',
      'Pushing to registries (Docker Hub / AWS ECR) and tagging strategies',
      'Container healthchecks and graceful shutdown signal handling',
    ],
    youtube: [
      {
        title: 'Docker Tutorial for Beginners (Full Course)',
        channel: 'TechWorld with Nana',
        level: 'Beginner',
        duration: '3 hours',
        topics: ['Images & Containers', 'Dockerfile', 'Docker Compose', 'Volumes & Networks'],
        url: 'https://www.youtube.com/results?search_query=TechWorld+with+Nana+Docker+tutorial+beginners',
      },
      {
        title: 'Docker Crash Course for Web Developers',
        channel: 'Traversy Media',
        level: 'Intermediate',
        duration: '1.5 hours',
        topics: ['Multi-stage builds', 'Node & Python containers', 'Production tips'],
        url: 'https://www.youtube.com/results?search_query=Traversy+Media+Docker+crash+course',
      },
      {
        title: 'Docker Image Optimization & Security Hardening',
        channel: 'Fireship',
        level: 'Advanced',
        duration: '1 hour',
        topics: ['Distroless images', 'Layer caching', 'Vulnerability scanning with Trivy'],
        url: 'https://www.youtube.com/results?search_query=Fireship+Docker+tips+tricks',
      },
    ],
    freeCourses: [
      {
        title: 'Docker for Developers Learning Path',
        platform: 'Docker Official / Microsoft Learn',
        level: 'Beginner to Intermediate',
        duration: '5 hours',
        freeStatus: '100% Free',
        certificateAvailability: 'Microsoft Achievement Badges',
        url: 'https://learn.microsoft.com/en-us/training/paths/intro-to-docker-containers/',
      },
    ],
    certificateCourses: [
      {
        title: 'Docker Certified Associate (DCA) Exam Preparation',
        platform: 'Udemy / Coursera',
        skill: 'Enterprise Container Management',
        level: 'Professional',
        duration: '12 hours',
        certificateAvailability: 'Industry Certification Prep & Course Certificate',
        priceStatus: 'Paid Course / Subscription Available',
        whyRelevant: 'Direct alignment with professional DevOps standards and container lifecycle management.',
        url: 'https://www.udemy.com/course/docker-certified-associate-exam-preparation/',
      },
    ],
    officialDocs: [
      {
        title: 'Docker Documentation & Getting Started Guide',
        publisher: 'Docker Inc.',
        description: 'Official guides for building images, container networking, and compose specifications.',
        keySections: ['Get Started', 'Dockerfile Reference', 'Compose File Specification', 'Best Practices'],
        url: 'https://docs.docker.com/get-started/',
      },
    ],
    practicePlatforms: [
      {
        name: 'Killercoda Interactive Scenarios',
        focus: 'Interactive Linux container terminals in the browser',
        recommendedProblems: ['Build your first Docker image', 'Multi-stage builds', 'Networking deep dive'],
        url: 'https://killercoda.com/playgrounds/scenario/docker',
      },
    ],
    project: {
      title: 'Multi-Service Containerized Microservices Stack with Docker Compose',
      difficulty: 'Intermediate',
      techStack: ['Docker', 'Docker Compose', 'Node.js/FastAPI', 'PostgreSQL', 'Redis', 'Nginx'],
      problemStatement: 'Build a decoupled 3-tier architecture with an Nginx reverse proxy, application server, managed database, and Redis cache running securely in dedicated isolated bridge networks.',
      features: [
        'Multi-stage Dockerfile minimizing production image size below 100MB',
        'Non-root container user and read-only root filesystems',
        'Database volume persistence with automated seed script',
      ],
      evidenceGoal: 'Commit docker-compose.yml and Dockerfile to GitHub with automated Docker Hub build workflow.',
    },
    expectedOutcome:
      'Confidence containerizing any production application stack with optimized caching and minimal image size.',
  },

  aws: {
    canonicalName: 'Amazon Web Services (AWS)',
    category: 'Cloud Infrastructure',
    whyItMattersTemplate: (role, company) =>
      `Deploying high-availability infrastructure at ${company} requires practical knowledge of AWS core services like IAM, ECS/EC2, S3, RDS, and Lambda for ${role} team members.`,
    gapTemplate: (evidence, role) =>
      `Resume shows general application development, but lacks demonstrable cloud architecture and managed AWS service deployment credentials needed for ${role}.`,
    whatToLearn: [
      'Core Cloud Computing: Regions, Availability Zones, and VPC networking',
      'Security: IAM roles, policies, Least Privilege principle, and Secrets Manager',
      'Compute: EC2 vs ECS/Fargate (containerized) vs AWS Lambda (serverless)',
      'Storage & Databases: S3 bucket policies/lifecycle rules, RDS PostgreSQL, DynamoDB',
      'Networking & Distribution: Route 53, CloudFront CDN, and Application Load Balancer',
      'Monitoring & Ops: CloudWatch logs, metric alarms, and AWS X-Ray tracing',
      'Infrastructure as Code basics: AWS CDK or Terraform on AWS',
    ],
    youtube: [
      {
        title: 'AWS Certified Cloud Practitioner & Solutions Architect Full Course',
        channel: 'freeCodeCamp.org',
        level: 'Beginner to Intermediate',
        duration: '14 hours',
        topics: ['IAM', 'VPC', 'EC2 & ECS', 'RDS', 'S3', 'Security'],
        url: 'https://www.youtube.com/results?search_query=freeCodeCamp+AWS+certified+solutions+architect+associate',
      },
      {
        title: 'Deploy Full-Stack App to AWS (ECS Fargate, RDS, S3)',
        channel: 'Traversy Media',
        level: 'Intermediate',
        duration: '2.5 hours',
        topics: ['Docker deployment', 'RDS database setup', 'Domain & SSL'],
        url: 'https://www.youtube.com/results?search_query=Traversy+Media+Deploy+AWS+full+stack',
      },
    ],
    freeCourses: [
      {
        title: 'AWS Cloud Practitioner Essentials',
        platform: 'AWS Skill Builder',
        level: 'Beginner',
        duration: '6 hours',
        freeStatus: '100% Free on AWS Official Platform',
        certificateAvailability: 'Digital Badge upon course completion',
        url: 'https://explore.skillbuilder.aws/learn/course/external/view/elearning/134/aws-cloud-practitioner-essentials',
      },
    ],
    certificateCourses: [
      {
        title: 'AWS Certified Solutions Architect - Associate (SAA-C03)',
        platform: 'AWS / Coursera / Udemy',
        skill: 'Cloud Architecture & Reliability',
        level: 'Professional',
        duration: '20-30 hours',
        certificateAvailability: 'Industry Standard AWS Certification',
        priceStatus: 'Paid Official Exam ($150) / Free preparation modules on AWS Skill Builder',
        whyRelevant: 'The most widely recognized cloud credential across technology employers worldwide.',
        url: 'https://aws.amazon.com/certification/certified-solutions-architect-associate/',
      },
    ],
    officialDocs: [
      {
        title: 'AWS Documentation & Architecture Center',
        publisher: 'Amazon Web Services',
        description: 'Well-Architected Framework covering security, reliability, cost optimization, and performance.',
        keySections: ['AWS Well-Architected Framework', 'IAM User Guide', 'ECS Documentation'],
        url: 'https://docs.aws.amazon.com/',
      },
    ],
    practicePlatforms: [
      {
        name: 'AWS Free Tier Hands-on Labs',
        focus: '12 months free access to EC2, S3, RDS, and Lambda for prototype testing',
        recommendedProblems: ['Deploy a static website on S3 with CloudFront', 'Create a serverless REST API with Lambda and DynamoDB'],
        url: 'https://aws.amazon.com/free/',
      },
    ],
    project: {
      title: 'Serverless Event-Driven Image Processing Pipeline on AWS',
      difficulty: 'Intermediate',
      techStack: ['AWS S3', 'AWS Lambda', 'Amazon EventBridge', 'Amazon DynamoDB', 'Terraform'],
      problemStatement: 'Build a resilient cloud pipeline: when a user uploads an image to an S3 bucket, an event triggers an asynchronous Lambda function that resizes the image, extracts metadata, and records the entry in DynamoDB.',
      features: [
        'Secure IAM roles with strict least-privilege permissions',
        'Dead-letter queue (DLQ) for failed message error handling',
        'Infrastructure provisioned via Terraform script',
      ],
      evidenceGoal: 'Publish architecture diagram and Terraform repository with live demo video to GitHub.',
    },
    expectedOutcome:
      'Verified ability to design, deploy, and maintain secure cloud services on AWS avoiding common architectural anti-patterns.',
  },

  postgresql: {
    canonicalName: 'PostgreSQL & SQL Databases',
    category: 'Database & Data Storage',
    whyItMattersTemplate: (role, company) =>
      `Relational data integrity, schema migrations, and sub-millisecond query optimization are mission-critical for ${role} positions at ${company}.`,
    gapTemplate: (evidence, role) =>
      `The candidate demonstrates general programming knowledge, but lacks explicit proof of relational database design, indexing strategies, or query analysis required for ${role}.`,
    whatToLearn: [
      'Relational schema design, foreign keys, constraints, and 3NF normalization',
      'Complex queries: JOINs (INNER, LEFT, FULL), subqueries, and Common Table Expressions (CTEs)',
      'Window functions: ROW_NUMBER(), RANK(), DENSE_RANK(), and LAG()/LEAD()',
      'Indexing internals: B-tree vs GIN/GiST, composite indices, and index selectivity',
      'Query optimization: Reading EXPLAIN (ANALYZE, BUFFERS) execution plans',
      'Transactions, ACID compliance, and isolation levels (Read Committed vs Serializable)',
      'Connection pooling (PgBouncer) and migration tooling (Flyway, Prisma, or Alembic)',
    ],
    youtube: [
      {
        title: 'PostgreSQL Tutorial for Beginners (Full Course)',
        channel: 'freeCodeCamp.org',
        level: 'Beginner',
        duration: '4.5 hours',
        topics: ['Tables & Constraints', 'Queries', 'JOINs', 'Aggregations', 'Indexes'],
        url: 'https://www.youtube.com/results?search_query=freeCodeCamp+PostgreSQL+tutorial+full+course',
      },
      {
        title: 'Database Design & SQL Indexing Masterclass',
        channel: 'Hussein Nasser',
        level: 'Intermediate to Advanced',
        duration: '3 hours',
        topics: ['B-Tree index internals', 'Table scans vs Index scans', 'Locking and Deadlocks'],
        url: 'https://www.youtube.com/results?search_query=Hussein+Nasser+database+indexing+PostgreSQL',
      },
    ],
    freeCourses: [
      {
        title: 'Relational Database Certification (PostgreSQL & Bash)',
        platform: 'freeCodeCamp',
        level: 'All Levels',
        duration: '300 hours (interactive curriculum)',
        freeStatus: '100% Free',
        certificateAvailability: 'Free Verified Certification',
        url: 'https://www.freecodecamp.org/learn/relational-database/',
      },
    ],
    certificateCourses: [
      {
        title: 'PostgreSQL for Everybody Specialization',
        platform: 'Coursera (University of Michigan)',
        skill: 'Relational Database Architecture',
        level: 'Intermediate',
        duration: '4 months',
        certificateAvailability: 'University Certificate Available',
        priceStatus: 'Free to Audit / Paid Certificate Option',
        whyRelevant: 'Taught by Dr. Charles Severance covering JSON in Postgres, natural language indexing, and scaling.',
        url: 'https://www.coursera.org/specializations/postgresql-for-everybody',
      },
    ],
    officialDocs: [
      {
        title: 'PostgreSQL Official Documentation',
        publisher: 'PostgreSQL Global Development Group',
        description: 'The definitive technical manual for SQL commands, data types, indexes, and performance tuning.',
        keySections: ['The SQL Language', 'Indices', 'Concurrency Control', 'Server Administration'],
        url: 'https://www.postgresql.org/docs/current/',
      },
    ],
    practicePlatforms: [
      {
        name: 'SQLZoo',
        focus: 'Interactive SQL quizzes and live browser query execution',
        recommendedProblems: ['SELECT from Nobel', 'JOIN operations', 'Window functions', 'Self JOIN'],
        url: 'https://sqlzoo.net/',
      },
      {
        name: 'LeetCode Database 50',
        focus: 'Real interview SQL problem set across easy, medium, and hard tiers',
        recommendedProblems: ['Combine Two Tables', 'Second Highest Salary', 'Department Top Three Salaries', 'Consecutive Numbers'],
        url: 'https://leetcode.com/studyplan/top-sql-50/',
      },
    ],
    project: {
      title: 'High-Volume Relational Schema with Benchmark Query Optimization',
      difficulty: 'Intermediate',
      techStack: ['PostgreSQL 16', 'Docker', 'Python/Node.js Scripting', 'PgBouncer'],
      problemStatement: 'Seed a database with 1,000,000 simulated e-commerce orders. Analyze slow unindexed aggregation queries with EXPLAIN ANALYZE, engineer appropriate composite B-tree indices, and document p95 latency reduction from 850ms to 4ms.',
      features: [
        'Declarative migration scripts tracking versioned schema evolution',
        'Complex window function queries calculating 30-day rolling customer lifetime value',
        'Comprehensive markdown report containing before-and-after query execution plans',
      ],
      evidenceGoal: 'Publish the benchmark repository to GitHub with reproducible Docker Compose seed environment.',
    },
    expectedOutcome:
      'Ability to design relational databases that handle high concurrency without table lock contention or slow sequential scans.',
  },

  kubernetes: {
    canonicalName: 'Kubernetes (K8s)',
    category: 'DevOps & Orchestration',
    whyItMattersTemplate: (role, company) =>
      `Senior and infrastructure ${role} positions at ${company} require understanding container orchestration, service meshes, and automated rollouts using Kubernetes.`,
    gapTemplate: (evidence, role) =>
      `While Docker or backend development is evident, the resume shows no direct experience managing Pods, Deployments, Services, or ingress controllers in Kubernetes.`,
    whatToLearn: [
      'Kubernetes Architecture: Control Plane (API server, etcd, scheduler) vs Worker Nodes (kubelet, kube-proxy)',
      'Core Workloads: Pods, Deployments, ReplicaSets, StatefulSets, and DaemonSets',
      'Networking: ClusterIP, NodePort, LoadBalancer Services, and Ingress controllers',
      'Configuration: ConfigMaps, Secrets, and downward API environment injection',
      'Storage: PersistentVolumes, PersistentVolumeClaims, and StorageClasses',
      'Resilience: Liveness, Readiness, and Startup probes with Horizontal Pod Autoscaler (HPA)',
      'Helm package manager: creating, templating, and deploying custom charts',
    ],
    youtube: [
      {
        title: 'Kubernetes Course for Beginners (Full Course)',
        channel: 'TechWorld with Nana',
        level: 'Beginner',
        duration: '4 hours',
        topics: ['Pods & Services', 'Deployments', 'ConfigMap & Secret', 'Ingress', 'Helm'],
        url: 'https://www.youtube.com/results?search_query=TechWorld+with+Nana+Kubernetes+course+beginners',
      },
      {
        title: 'Kubernetes in 100 Seconds & Practical Architecture',
        channel: 'Fireship',
        level: 'Intermediate',
        duration: '1 hour',
        topics: ['Microservice orchestration', 'Declarative YAML', 'Production tips'],
        url: 'https://www.youtube.com/results?search_query=Fireship+Kubernetes+tutorial',
      },
    ],
    freeCourses: [
      {
        title: 'Introduction to Kubernetes (LFS158x)',
        platform: 'The Linux Foundation / edX',
        level: 'Beginner',
        duration: '14 weeks',
        freeStatus: 'Free Course Audit',
        certificateAvailability: 'Verified Certificate Available',
        url: 'https://www.edx.org/learn/kubernetes/the-linux-foundation-introduction-to-kubernetes',
      },
    ],
    certificateCourses: [
      {
        title: 'Certified Kubernetes Application Developer (CKAD)',
        platform: 'The Linux Foundation / Cloud Native Computing Foundation (CNCF)',
        skill: 'Kubernetes Application Deployment',
        level: 'Professional',
        duration: 'Self-paced preparation',
        certificateAvailability: 'Official CNCF Performance-Based Certification',
        priceStatus: 'Paid Official Hands-on Exam',
        whyRelevant: 'The premier industry certification validating that an engineer can build, monitor, and troubleshoot production apps on K8s.',
        url: 'https://www.cncf.io/certification/ckad/',
      },
    ],
    officialDocs: [
      {
        title: 'Kubernetes Documentation',
        publisher: 'The Kubernetes Authors / CNCF',
        description: 'Complete reference for manifests, API versions, kubectl cheat sheet, and cluster architecture.',
        keySections: ['Concepts', 'Tasks', 'Reference (kubectl)', 'Tutorials'],
        url: 'https://kubernetes.io/docs/home/',
      },
    ],
    practicePlatforms: [
      {
        name: 'Killercoda Kubernetes Playground',
        focus: 'Free in-browser multi-node Kubernetes clusters with real kubectl access',
        recommendedProblems: ['Deploy an Nginx Pod', 'Create a Deployment with Rolling Update', 'Configure Ingress and ConfigMaps'],
        url: 'https://killercoda.com/playgrounds/scenario/kubernetes',
      },
    ],
    project: {
      title: 'Zero-Downtime Microservices Deployment with Helm & Canary Rollouts on Minikube/Kind',
      difficulty: 'Advanced',
      techStack: ['Kubernetes (Kind)', 'Helm 3', 'Docker', 'Prometheus', 'Grafana'],
      problemStatement: 'Package a multi-tier web application into custom Helm charts. Implement automated health probes, Horizontal Pod Autoscaling based on CPU/memory, and blue-green or rolling update deployment.',
      features: [
        'Declarative Helm chart templates with configurable values.yaml for dev/prod',
        'Configured resource requests and limits preventing node starvation',
        'Automated ingress routing with TLS termination mock',
      ],
      evidenceGoal: 'Publish the Helm chart repository and architecture diagram to GitHub with clear reproduction steps.',
    },
    expectedOutcome:
      'Demonstrable understanding of modern cloud-native container orchestration and production deployment workflows.',
  },

  system_design: {
    canonicalName: 'System Design & Scalability',
    category: 'Architecture & Senior Engineering',
    whyItMattersTemplate: (role, company) =>
      `Evaluating architectural trade-offs, concurrency, caching, and horizontal scaling is central to senior technical interviews for ${role} roles at ${company}.`,
    gapTemplate: (evidence, role) =>
      `The resume shows functional coding experience, but lacks evidence of designing large-scale distributed architectures, load balancing, or failure mitigation required for ${role}.`,
    whatToLearn: [
      'Core Principles: Scalability, Latency vs Throughput, Availability (CAP Theorem, PACELC)',
      'Load Balancing algorithms (Round-robin, Least connections, Consistent Hashing)',
      'Caching layers (Redis/Memcached): Cache-aside, Read-through, Write-through, Write-back, and eviction policies',
      'Database Scaling: Read replicas, Sharding, Partitioning, and Federation',
      'Asynchronous workflows: Message queues (RabbitMQ, Kafka) and Pub/Sub architectures',
      'API Gateways, Rate Limiting, and Circuit Breaker design patterns',
      'Observability: Metrics (Prometheus), Distributed Tracing (OpenTelemetry), and Alerting',
    ],
    youtube: [
      {
        title: 'System Design Interview - An Insider\'s Guide Course',
        channel: 'NeetCode',
        level: 'Intermediate to Advanced',
        duration: '6 hours',
        topics: ['Scalability', 'Load Balancers', 'Databases', 'Caching', 'Rate Limiting', 'Design Twitter/URL Shortener'],
        url: 'https://www.youtube.com/results?search_query=NeetCode+System+Design+for+Beginners',
      },
      {
        title: 'Software Architecture & System Design Primer',
        channel: 'Fireship',
        level: 'Intermediate',
        duration: '1.5 hours',
        topics: ['Microservices vs Monoliths', 'Event-driven design', 'Distributed systems'],
        url: 'https://www.youtube.com/results?search_query=Fireship+Software+Architecture+Patterns',
      },
    ],
    freeCourses: [
      {
        title: 'The System Design Primer (Open Source Masterclass)',
        platform: 'GitHub (Donne Martin)',
        level: 'All Levels',
        duration: 'Self-paced',
        freeStatus: '100% Free Open Source',
        certificateAvailability: 'Open Community Resource',
        url: 'https://github.com/donnemartin/system-design-primer',
      },
    ],
    certificateCourses: [
      {
        title: 'Grokking Modern System Design for Software Engineers',
        platform: 'Educative.io',
        skill: 'Distributed Systems & Architecture',
        level: 'Professional',
        duration: '20 hours',
        certificateAvailability: 'Certificate of Completion Available',
        priceStatus: 'Paid Subscription / Free Preview Available',
        whyRelevant: 'Deep architectural breakdowns of real-world scale systems (Uber, YouTube, WhatsApp).',
        url: 'https://www.educative.io/courses/grokking-modern-system-design-interview-for-engineers-managers',
      },
    ],
    officialDocs: [
      {
        title: 'AWS Well-Architected Framework Whitepapers',
        publisher: 'Amazon Web Services',
        description: 'Industry-standard guidelines on reliability, performance efficiency, cost optimization, and resilience.',
        keySections: ['Reliability Pillar', 'Performance Efficiency Pillar', 'Security Pillar'],
        url: 'https://aws.amazon.com/architecture/well-architected/',
      },
    ],
    practicePlatforms: [
      {
        name: 'LeetCode System Design Exploration',
        focus: 'Architectural case studies and distributed design questions',
        recommendedProblems: ['Design a URL Shortener (TinyURL)', 'Design a Rate Limiter', 'Design a Notification Service'],
        url: 'https://leetcode.com/explore/interview/card/system-design/',
      },
    ],
    project: {
      title: 'High-Throughput Distributed Rate Limiter & Token Bucket Service',
      difficulty: 'Advanced',
      techStack: ['Go / Node.js', 'Redis', 'Docker Compose', 'k6 Load Testing'],
      problemStatement: 'Build a distributed API rate limiter implementing the sliding window counter or token bucket algorithm backed by Redis. Run k6 load tests with 10,000 concurrent simulated requests demonstrating sub-5ms evaluation under heavy load.',
      features: [
        'Atomic Redis Lua scripts eliminating race conditions during high concurrency',
        'Configurable rate limits per API key and endpoint route',
        'Benchmarking scripts graphing throughput and latency histograms',
      ],
      evidenceGoal: 'Publish the architecture diagram, benchmark analysis, and k6 script in the project README on GitHub.',
    },
    expectedOutcome:
      'Ability to reason rigorously about scalability bottlenecks and defend architectural trade-offs during technical interviews.',
  },
};

// Generic fallback generator for skills not in the verified catalog
function buildGenericSkillInfo(skillName: string, roleTitle: string, company: string): DomainSkillInfo {
  const cleanName = skillName.trim();
  const query = encodeURIComponent(`${cleanName} tutorial course`);
  const ytQuery = encodeURIComponent(`${cleanName} complete course`);

  return {
    canonicalName: cleanName,
    category: 'Core Technical Skill',
    whyItMattersTemplate: (role, comp) =>
      `Proficiency in ${cleanName} is directly aligned with the responsibilities expected for a ${role} at ${comp}.`,
    gapTemplate: (evidence, role) =>
      evidence.includes('No evidence')
        ? `The target ${role} position values competency in ${cleanName}, but no explicit evidence was identified in the resume text.`
        : `Resume demonstrates initial or partial exposure to ${cleanName}, but lacks deep production evidence for this role.`,
    whatToLearn: [
      `Foundations & core principles of ${cleanName}`,
      `Idiomatic patterns and standard project structuring with ${cleanName}`,
      `Integration with web services, databases, and build systems`,
      `Performance optimization, error boundaries, and debugging strategies`,
      `Testing and production deployment workflows for ${cleanName}`,
    ],
    youtube: [
      {
        title: `${cleanName} Full Course - Beginner to Advanced`,
        channel: 'freeCodeCamp.org / Reputable Educational Creators',
        level: 'All Levels',
        duration: '4-8 hours',
        topics: ['Syntax & Foundations', 'Practical Implementation', 'Best Practices'],
        url: `https://www.youtube.com/results?search_query=${ytQuery}`,
        isSearchFallback: true,
      },
      {
        title: `${cleanName} Crash Course for Developers`,
        channel: 'Traversy Media / Web Dev Simplified',
        level: 'Intermediate',
        duration: '2-3 hours',
        topics: ['Architecture', 'Real-world Integration', 'Common Pitfalls'],
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(cleanName + ' crash course tutorial')}`,
        isSearchFallback: true,
      },
    ],
    freeCourses: [
      {
        title: `Learn ${cleanName} Fundamentals`,
        platform: 'freeCodeCamp / Open Educational Resources',
        level: 'Beginner',
        duration: 'Self-paced',
        freeStatus: '100% Free',
        certificateAvailability: 'Free Curriculum Available',
        url: `https://www.freecodecamp.org/news/search/?query=${encodeURIComponent(cleanName)}`,
      },
      {
        title: `${cleanName} Learning Path & Documentation`,
        platform: 'Official Community Documentation',
        level: 'All Levels',
        duration: 'Comprehensive Modules',
        freeStatus: '100% Free',
        certificateAvailability: 'Open Access',
        url: `https://www.google.com/search?q=${encodeURIComponent(cleanName + ' official documentation tutorial')}`,
      },
    ],
    certificateCourses: [
      {
        title: `${cleanName} Professional Certificate & Specialization Courses`,
        platform: 'Coursera',
        skill: cleanName,
        level: 'Intermediate',
        duration: '1-3 months',
        certificateAvailability: 'Shareable Certificate Available',
        priceStatus: 'Free to Audit / Paid Certificate with Financial Aid',
        whyRelevant: `Structured curriculum covering practical industry workflows in ${cleanName}.`,
        url: `https://www.coursera.org/search?query=${encodeURIComponent(cleanName)}`,
      },
      {
        title: `${cleanName} Essential Training & Masterclass`,
        platform: 'edX / Udemy',
        skill: cleanName,
        level: 'Professional',
        duration: '10-20 hours',
        certificateAvailability: 'Verified Certificate of Completion',
        priceStatus: 'Free Audit on edX / Discounted on Udemy',
        whyRelevant: `Comprehensive hands-on exercises validating practical ${cleanName} competence.`,
        url: `https://www.edx.org/search?q=${encodeURIComponent(cleanName)}`,
      },
    ],
    officialDocs: [
      {
        title: `${cleanName} Official Documentation & Reference Guide`,
        publisher: 'Official Maintainers & Core Development Team',
        description: `Authoritative guide covering language specifications, APIs, and community best practices.`,
        keySections: ['Getting Started Guide', 'API Reference', 'Best Practices'],
        url: `https://www.google.com/search?q=${encodeURIComponent(cleanName + ' official docs documentation')}`,
      },
    ],
    practicePlatforms: [
      {
        name: 'LeetCode & Practice Challenges',
        focus: `Practical coding and problem solving focusing on ${cleanName}`,
        recommendedProblems: [`${cleanName} Fundamental Implementations`, 'Integration Challenges'],
        url: `https://leetcode.com/problemset/all/?search=${encodeURIComponent(cleanName)}`,
      },
      {
        name: 'Exercism / HackerRank',
        focus: `Automated test-driven exercises for ${cleanName}`,
        recommendedProblems: ['Core Track Exercises', 'Algorithmic Puzzles'],
        url: `https://exercism.org/tracks`,
      },
    ],
    project: {
      title: `Production-Grade ${cleanName} Implementation Project`,
      difficulty: 'Intermediate',
      techStack: [cleanName, 'Git', 'Automated Testing', 'Docker'],
      problemStatement: `Develop an end-to-end service or library utilizing ${cleanName} to solve a specific bottleneck, including automated tests and clean documentation.`,
      features: [
        `Modular architecture following modern ${cleanName} conventions`,
        'Automated unit and integration test suite',
        'Clean GitHub README documentation with architecture overview',
      ],
      evidenceGoal: 'Publish the repository to GitHub with clean commit history and live demo link.',
    },
    expectedOutcome: `Demonstrated capability applying ${cleanName} to real-world challenges with measurable engineering ownership.`,
  };
}

/**
 * Finds or synthesizes verified learning domain info for any skill
 */
function resolveSkillInfo(skillName: string, roleTitle: string, company: string): DomainSkillInfo {
  const lower = skillName.toLowerCase().trim();

  // Check direct matches & canonical aliases
  if (lower.includes('react')) return VERIFIED_SKILL_CATALOG.react;
  if (lower.includes('typescript') || lower === 'ts') return VERIFIED_SKILL_CATALOG.typescript;
  if (lower.includes('python')) return VERIFIED_SKILL_CATALOG.python;
  if (lower.includes('docker') || lower.includes('container')) return VERIFIED_SKILL_CATALOG.docker;
  if (lower.includes('aws') || lower.includes('amazon web services') || lower.includes('cloud')) return VERIFIED_SKILL_CATALOG.aws;
  if (lower.includes('postgres') || lower.includes('sql') || lower.includes('database')) return VERIFIED_SKILL_CATALOG.postgresql;
  if (lower.includes('kubernetes') || lower.includes('k8s')) return VERIFIED_SKILL_CATALOG.kubernetes;
  if (lower.includes('system design') || lower.includes('architecture') || lower.includes('scalability') || lower.includes('microservice'))
    return VERIFIED_SKILL_CATALOG.system_design;

  // Otherwise generate dynamic verified information
  return buildGenericSkillInfo(skillName, roleTitle, company);
}

/**
 * Main Generator for Personalized Learning & Career Hub
 */
export function generatePersonalizedLearningHubData(report: AnalysisReport): PersonalizedLearningHubData {
  const {
    targetCompany: rawCompany,
    targetRole: rawRole,
    experienceLevel: rawLevel,
    skillMatches,
    resumeData,
    jobData,
  } = report;

  const targetCompany = rawCompany || jobData.company_inferred || 'Target Company';
  const roleTitle = rawRole || jobData.job_title || 'Software Engineer';
  const experienceLevel = rawLevel || jobData.seniority_level || 'Mid Level';

  // 1. Partition Skill Matches by status
  const missingMatches = skillMatches.filter((m) => m.status === 'MISSING');
  const partialMatches = skillMatches.filter((m) => m.status === 'PARTIAL');
  const matchedMatches = skillMatches.filter((m) => m.status === 'MATCHED');

  // Candidate existing skills list for cross-checking evidence
  const candidateKnownSkills = new Set(
    (resumeData.technical_skills || [])
      .concat(resumeData.programming_languages || [])
      .concat(resumeData.frameworks || [])
      .concat(resumeData.databases || [])
      .concat(resumeData.cloud_platforms || [])
      .map((s) => s.toLowerCase().trim())
  );

  // 2. Build prioritized skill recommendations
  // Top gaps = Missing required skills (HIGH), Missing preferred (HIGH/MEDIUM), Partial required (MEDIUM), Long-term (LONG_TERM)
  const prioritizedCandidates: Array<{
    match: SkillMatch;
    priority: LearningPriority;
  }> = [];

  // High priority: Required skills that are missing
  missingMatches
    .filter((m) => m.isRequired || m.priority === 'HIGH')
    .forEach((m) => {
      prioritizedCandidates.push({ match: m, priority: 'HIGH' });
    });

  // High/Medium priority: Other missing skills
  missingMatches
    .filter((m) => !m.isRequired && m.priority !== 'HIGH')
    .forEach((m) => {
      prioritizedCandidates.push({ match: m, priority: 'MEDIUM' });
    });

  // Medium priority: Partial matches (skills mentioned or related, but lacking production proof)
  partialMatches.forEach((m) => {
    prioritizedCandidates.push({
      match: m,
      priority: m.isRequired ? 'HIGH' : 'MEDIUM',
    });
  });

  // Add long-term forward-looking capability (e.g. System Design / Architecture / Cloud) if not already present
  const hasSystemDesign = prioritizedCandidates.some((c) =>
    c.match.skill.toLowerCase().includes('system design') || c.match.skill.toLowerCase().includes('architecture')
  );
  if (!hasSystemDesign) {
    prioritizedCandidates.push({
      match: {
        skill: 'System Design & Scalability',
        jobRequirement: 'Architecture trade-offs, distributed caching, and microservices scaling for senior progression',
        isRequired: false,
        status: 'MISSING',
        priority: 'MEDIUM',
        resumeEvidence: 'No explicit high-scale system design architecture benchmarks documented in resume.',
        explanation: 'Essential for next-level career advancement and senior technical interviews.',
      },
      priority: 'LONG_TERM',
    });
  }

  // De-duplicate by skill name
  const seenSkillNames = new Set<string>();
  const uniquePrioritized: Array<{ match: SkillMatch; priority: LearningPriority }> = [];
  for (const item of prioritizedCandidates) {
    const key = item.match.skill.toLowerCase().trim();
    if (!seenSkillNames.has(key)) {
      seenSkillNames.add(key);
      uniquePrioritized.push(item);
    }
  }

  // Ensure we have at least 3-6 rich recommendations
  const finalRecommendationList: PersonalizedSkillRecommendation[] = uniquePrioritized.slice(0, 6).map((item, idx) => {
    const skillName = item.match.skill;
    const domainInfo = resolveSkillInfo(skillName, roleTitle, targetCompany);

    // Compute current evidence
    const currentEvidence =
      item.match.resumeEvidence && item.match.resumeEvidence.trim().length > 0 && !item.match.resumeEvidence.toLowerCase().includes('no explicit evidence')
        ? item.match.resumeEvidence
        : 'No direct evidence identified in uploaded resume text.';

    // Compute current level
    let currentLevel = 'None Detected / Unproven';
    if (candidateKnownSkills.has(skillName.toLowerCase().trim())) {
      currentLevel = 'Foundational / Mentioned in Skills';
    } else if (item.match.status === 'PARTIAL') {
      currentLevel = 'Partial Exposure / Related Competency';
    }

    const gap = domainInfo.gapTemplate(currentEvidence, roleTitle);
    const whyItMatters = domainInfo.whyItMattersTemplate(roleTitle, targetCompany);

    return {
      id: `rec-skill-${idx}-${skillName.toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      skill: domainInfo.canonicalName || skillName,
      priority: item.priority,
      currentEvidence,
      currentLevel,
      gap,
      whyItMatters,
      whatToLearn: domainInfo.whatToLearn,
      youtube: domainInfo.youtube,
      freeCourses: domainInfo.freeCourses,
      certificateCourses: domainInfo.certificateCourses,
      officialDocs: domainInfo.officialDocs,
      practicePlatforms: domainInfo.practicePlatforms,
      projects: [domainInfo.project],
      expectedOutcome: domainInfo.expectedOutcome,
    };
  });

  // 3. Build 30 - 60 - 90 DAYS PERSONALIZED ROADMAP
  const primaryHighSkills = finalRecommendationList
    .filter((r) => r.priority === 'HIGH')
    .map((r) => r.skill);
  const secondarySkills = finalRecommendationList
    .filter((r) => r.priority === 'MEDIUM')
    .map((r) => r.skill);
  const longTermSkills = finalRecommendationList
    .filter((r) => r.priority === 'LONG_TERM')
    .map((r) => r.skill);

  const stage1Skill1 = primaryHighSkills[0] || 'Core Technical Foundation';
  const stage1Skill2 = primaryHighSkills[1] || secondarySkills[0] || 'Modern Tooling & Language Standards';

  const stage2Skill1 = primaryHighSkills[2] || secondarySkills[1] || 'API & Data Integration';
  const stage2Skill2 = secondarySkills[2] || 'Automated Testing & Containerization';

  const stage3Skill1 = longTermSkills[0] || 'System Design & Scalability';
  const stage3Skill2 = 'Portfolio Deployment & ATS Interview Synthesis';

  const thirtyDaysStage: RoadmapStage = {
    stage: '30_DAYS',
    title: '30 DAYS: Foundation & High-Priority Gap Closure',
    timeframe: 'Days 1 – 30',
    tagline: 'Target the mandatory missing skills to eliminate automatic candidate disqualification.',
    skills: [stage1Skill1, stage1Skill2],
    topics: [
      `Foundational syntax, architecture, and core patterns for ${stage1Skill1}`,
      `Essential tooling, configuration, and environment setup for ${stage1Skill2}`,
      'Hands-on interactive tutorial exercises and documentation deep-dive',
      'Initial isolated proof-of-concept module committed to GitHub',
    ],
    learningResources: [
      {
        name: `${stage1Skill1} Interactive Documentation & Tutorial`,
        platform: 'Official Docs & freeCodeCamp',
        type: 'Free Course & Docs',
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(stage1Skill1 + ' full course')}`,
      },
      {
        name: `${stage1Skill2} Fundamentals Workshop`,
        platform: 'Microsoft Learn / Platform Academy',
        type: 'Curriculum',
        url: `https://www.coursera.org/search?query=${encodeURIComponent(stage1Skill2)}`,
      },
    ],
    practiceTasks: [
      `Complete 5-10 targeted practice problems or exercises in ${stage1Skill1}`,
      `Configure a local development environment with linter, type-checker, and build scripts`,
      `Implement an isolated module demonstrating mastery of ${stage1Skill1} core features`,
    ],
    milestoneProject: {
      title: `${stage1Skill1} Foundation Proof-of-Concept Module`,
      description: `Build an isolated, fully functional service or web module that demonstrates core competency in ${stage1Skill1} without unnecessary boilerplate.`,
      deliverables: [
        'Clean repository with descriptive README documentation',
        'Functional unit tests verifying happy and edge cases',
        'Passing GitHub Actions CI workflow',
      ],
      portfolioEvidence: `Add repository link and key technical decisions to your GitHub profile and resume project section.`,
    },
  };

  const sixtyDaysStage: RoadmapStage = {
    stage: '60_DAYS',
    title: '60 DAYS: Practical Development & Full-Stack Integration',
    timeframe: 'Days 31 – 60',
    tagline: 'Connect individual skills into an integrated, production-grade application workflow.',
    skills: [stage2Skill1, stage2Skill2],
    topics: [
      `End-to-end integration between ${stage1Skill1} and ${stage2Skill1}`,
      'Automated testing suites (unit, integration, contract testing)',
      'Database connection pooling, migrations, and query tuning',
      'Containerizing the full stack with Docker & Docker Compose',
    ],
    learningResources: [
      {
        name: `Building Integrated Production Web Services with ${stage2Skill1}`,
        platform: 'Traversy Media & Hussein Nasser',
        type: 'Video Course & Labs',
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(stage2Skill1 + ' production tutorial')}`,
      },
      {
        name: `${stage2Skill2} Hands-on Implementation`,
        platform: 'Docker Docs & Killercoda',
        type: 'Interactive Sandbox',
        url: `https://docs.docker.com/get-started/`,
      },
    ],
    practiceTasks: [
      `Write a Docker multi-stage build reducing image size below 100MB`,
      `Implement automated database indexing and measure latency improvements under 100k test records`,
      `Set up end-to-end continuous integration pipeline with automated test gating`,
    ],
    milestoneProject: {
      title: `Integrated Full-Stack Production Service for ${roleTitle}`,
      description: `Architect a complete, secure multi-tier web application integrating ${stage1Skill1}, ${stage2Skill1}, and ${stage2Skill2} with database persistence and caching.`,
      deliverables: [
        'Secure authentication layer and structured API endpoints',
        'Docker Compose file running app, database, and cache services in bridge network',
        'Performance metrics documenting sub-50ms API response latency',
      ],
      portfolioEvidence: `Deploy live on cloud provider (Vercel, AWS, or Railway) with live demo URL in resume header.`,
    },
  };

  const ninetyDaysStage: RoadmapStage = {
    stage: '90_DAYS',
    title: '90 DAYS: Advanced Scalability, Portfolio & Career Synthesis',
    timeframe: 'Days 61 – 90',
    tagline: 'Polish senior engineering ownership, system design reasoning, and ATS-optimized resume presentation.',
    skills: [stage3Skill1, stage3Skill2],
    topics: [
      'High-throughput distributed systems patterns, caching, and rate limiting',
      'Observability: structured JSON logging, distributed tracing, and uptime alerts',
      'Translating project deliverables into measurable Google X-Y-Z bullet points',
      `Targeted behavioral framing and technical interview practice for ${targetCompany}`,
    ],
    learningResources: [
      {
        name: 'The System Design Primer & NeetCode Architecture Masterclass',
        platform: 'GitHub & NeetCode',
        type: 'System Design Curriculum',
        url: 'https://github.com/donnemartin/system-design-primer',
      },
      {
        name: `Technical Interview & Architecture Preparation for ${targetCompany}`,
        platform: 'LeetCode & System Design Exploration',
        type: 'Interview Practice',
        url: 'https://leetcode.com/explore/',
      },
    ],
    practiceTasks: [
      'Conduct load testing with k6 or Locust to uncover concurrency bottlenecks',
      'Rewrite resume bullet points incorporating quantifiable impact metrics from your capstone project',
      'Practice mock system design interviews walking through trade-offs out loud',
    ],
    milestoneProject: {
      title: `Production Portfolio Capstone: Resilient Architecture Showcase`,
      description: `A production-ready capstone project showcasing your end-to-end competency for ${roleTitle} at ${targetCompany}, featuring architecture diagrams, load test benchmarks, and automated CI/CD.`,
      deliverables: [
        'High-resolution architecture diagram detailing data flow and failure modes',
        'Reproducible load test script with latency histogram graphs',
        'ATS-optimized resume section highlighting this project using the Google X-Y-Z formula',
      ],
      portfolioEvidence: `Top featured repository on your GitHub profile and prominent showcase item in your interview portfolio.`,
    },
  };

  return {
    roleTitle,
    targetCompany,
    experienceLevel,
    totalGapsIdentified: missingMatches.length + partialMatches.length,
    recommendations: finalRecommendationList,
    roadmap: {
      thirtyDays: thirtyDaysStage,
      sixtyDays: sixtyDaysStage,
      ninetyDays: ninetyDaysStage,
    },
    careerNavigation: {
      resumeAction: 'Transform weak bullets into Google X-Y-Z accomplishments without fake metrics',
      skillMatrixAction: 'Verify requirement-by-requirement match status and evidence breakdown',
      projectAction: 'Review engineering deliverables tailored to close your biggest skill gaps',
      careerLevelAction: 'Assess seniority alignment, scope of ownership, and promotion criteria',
    },
  };
}
