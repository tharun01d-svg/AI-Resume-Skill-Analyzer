import * as pdfjsLib from 'pdfjs-dist';
import mammoth from 'mammoth';

export type ExtractionErrorCode =
  | 'INVALID_FILE'
  | 'EMPTY_TEXT'
  | 'PASSWORD_PROTECTED'
  | 'WORKER_ERROR'
  | 'PARSER_ERROR'
  | 'NETWORK_ERROR'
  | 'FILE_TOO_LARGE'
  | 'UNKNOWN_ERROR';

export class DocumentExtractionError extends Error {
  code: ExtractionErrorCode;

  constructor(code: ExtractionErrorCode, message: string) {
    super(message);
    this.name = 'DocumentExtractionError';
    this.code = code;
  }
}

export interface ExtractionProgress {
  stage: 'READING' | 'EXTRACTING' | 'VALIDATING';
  currentPage?: number;
  totalPages?: number;
}

export interface ExtractedDocument {
  text: string;
  pages: number;
  fileType: 'PDF' | 'DOCX' | 'TXT' | 'MD';
  charCount: number;
  wordCount: number;
}

/**
 * Safe development logging (only logs when in development mode)
 */
function logDevDiagnostic(event: string, details?: Record<string, any>) {
  if (typeof window !== 'undefined' && (import.meta as any).env?.DEV) {
    console.log(`[PDF/Doc Extractor] [${event}]`, details || '');
  }
}

/**
 * Configure and verify PDF.js worker
 */
function setupPdfJsWorker(preferCdn = false) {
  if (typeof window === 'undefined') return;

  const version = pdfjsLib.version || '4.10.38';
  const cdnWorker = `https://cdn.jsdelivr.net/npm/pdfjs-dist@${version}/build/pdf.worker.min.mjs`;
  const localWorker = `${window.location.origin}/pdf.worker.min.mjs`;

  if (preferCdn) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = cdnWorker;
    logDevDiagnostic('Configured worker with CDN fallback', { workerSrc: cdnWorker });
  } else if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
    // Default to local public worker; if it fails, the caller will retry with preferCdn = true
    pdfjsLib.GlobalWorkerOptions.workerSrc = localWorker;
    logDevDiagnostic('Configured worker with local worker', { workerSrc: localWorker });
  }
}

/**
 * Validate PDF magic bytes: A genuine PDF file must begin with "%PDF-"
 */
function validatePdfSignature(bytes: Uint8Array): boolean {
  const maxSearch = Math.min(bytes.length, 1024);
  const pdfMagic = [0x25, 0x50, 0x44, 0x46, 0x2d]; // '%PDF-' in ASCII

  for (let i = 0; i <= maxSearch - 5; i++) {
    if (
      bytes[i] === pdfMagic[0] &&
      bytes[i + 1] === pdfMagic[1] &&
      bytes[i + 2] === pdfMagic[2] &&
      bytes[i + 3] === pdfMagic[3] &&
      bytes[i + 4] === pdfMagic[4]
    ) {
      return true;
    }
  }
  return false;
}

/**
 * Extract structured text from a single PDF page
 * Groups items into lines and preserves paragraph / bullet / table formatting
 */
async function extractStructuredPageText(page: any): Promise<string> {
  const textContent = await page.getTextContent({
    includeMarkedContent: false,
  });

  if (!textContent || !textContent.items || textContent.items.length === 0) {
    return '';
  }

  interface RawItem {
    str: string;
    x: number;
    y: number;
    width: number;
    height: number;
    hasEOL: boolean;
  }

  const items: RawItem[] = [];

  for (const item of textContent.items) {
    if ('str' in item && typeof item.str === 'string') {
      const tx = Array.isArray(item.transform) ? item.transform[4] : 0;
      const ty = Array.isArray(item.transform) ? item.transform[5] : 0;
      items.push({
        str: item.str,
        x: tx,
        y: ty,
        width: item.width || 0,
        height: item.height || 0,
        hasEOL: Boolean(item.hasEOL),
      });
    }
  }

  if (items.length === 0) return '';

  // Sort: higher Y is higher on page (PDF coordinates start from bottom)
  // If Y is within 3.5 points, consider it the same line and sort by X ascending (left to right)
  items.sort((a, b) => {
    const yDiff = b.y - a.y;
    if (Math.abs(yDiff) > 3.5) {
      return yDiff;
    }
    return a.x - b.x;
  });

  // Group into lines
  interface LineGroup {
    items: RawItem[];
    y: number;
    hasEOL: boolean;
  }

  const lines: LineGroup[] = [];
  let curLine: LineGroup | null = null;

  for (const item of items) {
    if (!curLine) {
      curLine = { items: [item], y: item.y, hasEOL: item.hasEOL };
      lines.push(curLine);
    } else {
      const yDiff = Math.abs(curLine.y - item.y);
      if (yDiff <= 3.5) {
        curLine.items.push(item);
        if (item.hasEOL) curLine.hasEOL = true;
      } else {
        curLine = { items: [item], y: item.y, hasEOL: item.hasEOL };
        lines.push(curLine);
      }
    }
  }

  // Format line strings and preserve structure
  const formattedLines: string[] = [];
  let prevLineY: number | null = null;

  for (const line of lines) {
    let lineText = '';
    let prevItemEnd = -1;

    for (const it of line.items) {
      const trimmedStr = it.str;
      if (!trimmedStr) continue;

      if (prevItemEnd >= 0) {
        const gap = it.x - prevItemEnd;
        // If there is horizontal gap between words or table columns
        if (gap > 2.5 && !lineText.endsWith(' ') && !trimmedStr.startsWith(' ')) {
          lineText += ' ';
        }
      }
      lineText += trimmedStr;
      prevItemEnd = it.x + (it.width || trimmedStr.length * 5);
    }

    const trimmed = lineText.trim();
    if (!trimmed) continue;

    // Detect section spacing: if vertical gap > 18pt, add empty line for paragraph separation
    if (prevLineY !== null) {
      const vGap = prevLineY - line.y;
      if (vGap > 18) {
        formattedLines.push('');
      }
    }

    // Preserve bullet formatting
    const bulletMatch = trimmed.match(/^([•\*\-▪▫–—✦○●✓\d+\.])\s*(.*)$/);
    if (bulletMatch && ['•', '*', '-', '▪', '▫', '–', '—', '✦', '○', '●', '✓'].includes(bulletMatch[1])) {
      formattedLines.push(`${bulletMatch[1]} ${bulletMatch[2]}`);
    } else {
      formattedLines.push(trimmed);
    }

    prevLineY = line.y;
  }

  return formattedLines.join('\n');
}

/**
 * Extract text from PDF File in the browser
 */
export async function extractPdfText(
  file: File,
  onProgress?: (p: ExtractionProgress) => void,
  retryWithCdn = false
): Promise<ExtractedDocument> {
  // 1. Initial File Validation
  if (!file) {
    throw new DocumentExtractionError('INVALID_FILE', 'No file was provided.');
  }

  if (file.size === 0) {
    throw new DocumentExtractionError('INVALID_FILE', 'This file appears to be empty (0 bytes).');
  }

  if (file.size > 10 * 1024 * 1024) {
    throw new DocumentExtractionError(
      'FILE_TOO_LARGE',
      'File exceeds the 10 MB limit. Please upload a smaller file.'
    );
  }

  logDevDiagnostic('File validation start', {
    name: file.name,
    type: file.type,
    size: file.size,
  });

  onProgress?.({ stage: 'READING' });

  // 2. Read ArrayBuffer and validate magic bytes
  let arrayBuffer: ArrayBuffer;
  try {
    arrayBuffer = await file.arrayBuffer();
  } catch (readErr: any) {
    logDevDiagnostic('ArrayBuffer read error', { error: readErr?.message });
    throw new DocumentExtractionError(
      'PARSER_ERROR',
      'Could not read the file from your browser. Please try re-selecting it.'
    );
  }

  logDevDiagnostic('ArrayBuffer read successfully', { byteLength: arrayBuffer.byteLength });

  const signatureBytes = new Uint8Array(arrayBuffer.slice(0, 1024));
  const isSignatureValid = validatePdfSignature(signatureBytes);

  logDevDiagnostic('PDF signature check', {
    isValid: isSignatureValid,
    firstBytes: Array.from(signatureBytes.slice(0, 8)),
  });

  if (!isSignatureValid) {
    throw new DocumentExtractionError('INVALID_FILE', 'This file does not appear to be a valid PDF.');
  }

  // 3. Setup Worker
  setupPdfJsWorker(retryWithCdn);

  const version = pdfjsLib.version || '4.10.38';

  // 4. Open PDF Document Task
  let pdf: any;
  try {
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(arrayBuffer),
      cMapUrl: `https://cdn.jsdelivr.net/npm/pdfjs-dist@${version}/cmaps/`,
      cMapPacked: true,
      standardFontDataUrl: `https://cdn.jsdelivr.net/npm/pdfjs-dist@${version}/standard_fonts/`,
    });

    pdf = await loadingTask.promise;
  } catch (err: any) {
    const msg = String(err?.message || err);
    const errName = err?.name || '';
    logDevDiagnostic('PDF open error', { message: msg, name: errName });

    // Detect password / encryption
    if (
      errName === 'PasswordException' ||
      msg.toLowerCase().includes('password') ||
      msg.toLowerCase().includes('encrypted') ||
      (pdfjsLib.PasswordResponses && err?.code === pdfjsLib.PasswordResponses.NEED_PASSWORD)
    ) {
      throw new DocumentExtractionError(
        'PASSWORD_PROTECTED',
        'This PDF is password-protected and cannot be read.'
      );
    }

    // Detect worker failure and attempt automatic CDN fallback
    if (!retryWithCdn && (msg.toLowerCase().includes('worker') || msg.toLowerCase().includes('fake worker') || msg.toLowerCase().includes('failed to fetch'))) {
      logDevDiagnostic('Retrying PDF extraction with CDN worker fallback');
      return extractPdfText(file, onProgress, true);
    }

    if (msg.toLowerCase().includes('worker')) {
      throw new DocumentExtractionError('WORKER_ERROR', 'PDF processing could not start. Please try again.');
    }

    if (msg.toLowerCase().includes('network') || msg.toLowerCase().includes('fetch')) {
      throw new DocumentExtractionError(
        'NETWORK_ERROR',
        'The PDF processing resource could not be loaded. Please check your connection and try again.'
      );
    }

    throw new DocumentExtractionError(
      'PARSER_ERROR',
      "We couldn't read this PDF. Please try another PDF or DOCX file."
    );
  }

  const numPages = pdf.numPages || 1;
  logDevDiagnostic('PDF opened successfully', { numPages });

  // 5. Extract all pages
  const pageTexts: string[] = [];

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    onProgress?.({ stage: 'EXTRACTING', currentPage: pageNum, totalPages: numPages });
    try {
      const page = await pdf.getPage(pageNum);
      const pageText = await extractStructuredPageText(page);
      pageTexts.push(pageText);
      logDevDiagnostic(`Page ${pageNum}/${numPages} extracted`, { charLength: pageText.length });
    } catch (pageErr: any) {
      logDevDiagnostic(`Page ${pageNum} extraction error`, { error: pageErr?.message });
      // Continue to next page if possible
    }
  }

  onProgress?.({ stage: 'VALIDATING' });

  // 6. Combine & Validate Extracted Text
  const combined = pageTexts.join('\n\n').trim();
  // Normalize whitespace: collapse 3+ newlines to double newline
  const cleanText = combined.replace(/\n{3,}/g, '\n\n').trim();

  logDevDiagnostic('Final extracted text stats', {
    totalChars: cleanText.length,
    wordCount: cleanText ? cleanText.split(/\s+/).length : 0,
    numPages,
  });

  // Distinguish text PDF vs Scanned / Image PDF
  // If total characters across all pages is less than 50 or no words extracted:
  if (!cleanText || cleanText.length < 50) {
    throw new DocumentExtractionError(
      'EMPTY_TEXT',
      'This PDF appears to be image-based or scanned. Please upload a text-based PDF or DOCX.'
    );
  }

  return {
    text: cleanText,
    pages: numPages,
    fileType: 'PDF',
    charCount: cleanText.length,
    wordCount: cleanText.split(/\s+/).length,
  };
}

/**
 * Extract text from DOCX File in the browser using Mammoth
 */
export async function extractDocxText(
  file: File,
  onProgress?: (p: ExtractionProgress) => void
): Promise<ExtractedDocument> {
  if (!file) {
    throw new DocumentExtractionError('INVALID_FILE', 'No file was provided.');
  }

  if (file.size > 10 * 1024 * 1024) {
    throw new DocumentExtractionError(
      'FILE_TOO_LARGE',
      'File exceeds the 10 MB limit. Please upload a smaller file.'
    );
  }

  onProgress?.({ stage: 'READING' });

  let arrayBuffer: ArrayBuffer;
  try {
    arrayBuffer = await file.arrayBuffer();
  } catch (err: any) {
    throw new DocumentExtractionError('PARSER_ERROR', 'Could not read DOCX file data.');
  }

  onProgress?.({ stage: 'EXTRACTING' });

  try {
    const result = await mammoth.extractRawText({ arrayBuffer });
    const raw = (result.value || '').trim();

    onProgress?.({ stage: 'VALIDATING' });

    if (!raw || raw.length < 30) {
      throw new DocumentExtractionError(
        'EMPTY_TEXT',
        'We could not find readable text in this DOCX file. Please upload a valid document or paste text directly.'
      );
    }

    const clean = raw.replace(/\n{3,}/g, '\n\n').trim();
    const estimatedPages = Math.max(1, Math.ceil(clean.length / 2800));

    return {
      text: clean,
      pages: estimatedPages,
      fileType: 'DOCX',
      charCount: clean.length,
      wordCount: clean.split(/\s+/).length,
    };
  } catch (err: any) {
    if (err instanceof DocumentExtractionError) throw err;
    throw new DocumentExtractionError(
      'PARSER_ERROR',
      "We couldn't read this DOCX file. Please try another file or paste your resume text directly."
    );
  }
}

/**
 * Extract text from plain text or markdown
 */
export async function extractPlainText(
  file: File,
  onProgress?: (p: ExtractionProgress) => void
): Promise<ExtractedDocument> {
  onProgress?.({ stage: 'READING' });

  const raw = await file.text();
  onProgress?.({ stage: 'VALIDATING' });

  const clean = (raw || '').replace(/\r\n/g, '\n').trim();
  if (!clean || clean.length < 20) {
    throw new DocumentExtractionError(
      'EMPTY_TEXT',
      'The uploaded text file is empty or contains too little text.'
    );
  }

  const isMd = file.name.toLowerCase().endsWith('.md');
  const estimatedPages = Math.max(1, Math.ceil(clean.length / 2800));

  return {
    text: clean,
    pages: estimatedPages,
    fileType: isMd ? 'MD' : 'TXT',
    charCount: clean.length,
    wordCount: clean.split(/\s+/).length,
  };
}

/**
 * Main dispatcher: Extracts any supported document (PDF, DOCX, TXT, MD) client-side
 */
export async function extractDocumentClientSide(
  file: File,
  onProgress?: (p: ExtractionProgress) => void
): Promise<ExtractedDocument> {
  const lowerName = file.name.toLowerCase();

  if (lowerName.endsWith('.pdf')) {
    return extractPdfText(file, onProgress);
  }

  if (lowerName.endsWith('.docx')) {
    return extractDocxText(file, onProgress);
  }

  if (lowerName.endsWith('.txt') || lowerName.endsWith('.md')) {
    return extractPlainText(file, onProgress);
  }

  throw new DocumentExtractionError(
    'INVALID_FILE',
    'Unsupported file format. Please upload a PDF (.pdf), Word document (.docx), or plain text (.txt) file.'
  );
}
