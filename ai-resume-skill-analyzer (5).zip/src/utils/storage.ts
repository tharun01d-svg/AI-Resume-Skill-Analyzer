import { AnalysisReport } from '../types/analyzer';

const STORAGE_KEY = 'ai_resume_analyzer_history_v1';

export function getSavedReports(): AnalysisReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to load history from localStorage:', err);
    return [];
  }
}

export function saveReportToHistory(report: AnalysisReport): void {
  try {
    const existing = getSavedReports();
    // Prepend new report, limit to 10
    const filtered = existing.filter((r) => r.id !== report.id);
    const updated = [report, ...filtered].slice(0, 10);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save report to localStorage:', err);
  }
}

export function deleteReportFromHistory(id: string): AnalysisReport[] {
  try {
    const existing = getSavedReports();
    const updated = existing.filter((r) => r.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error('Failed to delete report:', err);
    return [];
  }
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error('Failed to clear history:', err);
  }
}
