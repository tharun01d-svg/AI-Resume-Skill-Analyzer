import { useState, useEffect, useCallback, useMemo } from 'react';

export type ResourceProgressStatus = 'not started' | 'in progress' | 'completed';

export interface ResourceProgressStats {
  total: number;
  completed: number;
  inProgress: number;
  notStarted: number;
  percentCompleted: number;
}

export interface UseLearningProgressReturn {
  /** Record of resource ID to current status */
  progress: Record<string, ResourceProgressStatus>;
  
  /** Retrieve status for a resource ('not started' by default) */
  getStatus: (resourceId: string) => ResourceProgressStatus;
  
  /** Explicitly set status for a resource */
  setStatus: (resourceId: string, status: ResourceProgressStatus) => void;
  
  /** Rotate status: 'not started' -> 'in progress' -> 'completed' -> 'not started' */
  cycleStatus: (resourceId: string) => ResourceProgressStatus;
  
  /** Convenience setter for 'not started' */
  markNotStarted: (resourceId: string) => void;
  
  /** Convenience setter for 'in progress' */
  markInProgress: (resourceId: string) => void;
  
  /** Convenience setter for 'completed' */
  markCompleted: (resourceId: string) => void;
  
  /** Quick toggle between completed and not started/in progress */
  toggleCompleted: (resourceId: string) => void;
  
  /** Helper check if resource is completed */
  isCompleted: (resourceId: string) => boolean;
  
  /** Helper check if resource is in progress */
  isInProgress: (resourceId: string) => boolean;
  
  /** Helper check if resource is not started */
  isNotStarted: (resourceId: string) => boolean;
  
  /** Reset all resource progress */
  resetAll: () => void;
  
  /** Compute progress statistics for a specified subset of resource IDs, or all tracked IDs */
  getStats: (resourceIds?: string[]) => ResourceProgressStats;
  
  /** Deterministic resource ID generator helper */
  buildResourceId: (type: string, skill: string, identifierOrTitle: string) => string;
}

const STORAGE_KEY = 'career_hub_resource_progress_v1';
const STORAGE_EVENT = 'career_hub_resource_progress_change';

/**
 * Safely read stored progress from localStorage
 */
function readStoredProgress(): Record<string, ResourceProgressStatus> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, ResourceProgressStatus>;
    }
  } catch (err) {
    console.warn('Failed to load learning progress from localStorage:', err);
  }
  return {};
}

/**
 * Safely persist progress to localStorage and broadcast change event
 */
function writeStoredProgress(data: Record<string, ResourceProgressStatus>): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    // Dispatch local custom event for same-window component synchronization
    window.dispatchEvent(new CustomEvent(STORAGE_EVENT, { detail: data }));
  } catch (err) {
    console.warn('Failed to save learning progress to localStorage:', err);
  }
}

/**
 * Helper to build consistent resource IDs across components
 */
export function buildResourceId(type: string, skill: string, identifierOrTitle: string): string {
  const sanitize = (str: string) =>
    (str || '')
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-');
  return `res-${sanitize(type)}-${sanitize(skill)}-${sanitize(identifierOrTitle)}`;
}

/**
 * Hook 'useLearningProgress'
 * 
 * Uses localStorage to persist the 'not started', 'in progress', and 'completed'
 * statuses of individual learning resources within the Career Learning Hub,
 * ensuring user progress is saved across sessions.
 */
export function useLearningProgress(): UseLearningProgressReturn {
  const [progress, setProgress] = useState<Record<string, ResourceProgressStatus>>(() => {
    return readStoredProgress();
  });

  // Listen for storage events (cross-tab sync) and custom events (same-window inter-component sync)
  useEffect(() => {
    const handleCustomEvent = (e: Event) => {
      const customEvent = e as CustomEvent<Record<string, ResourceProgressStatus>>;
      if (customEvent.detail) {
        setProgress(customEvent.detail);
      } else {
        setProgress(readStoredProgress());
      }
    };

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) {
        try {
          if (e.newValue) {
            setProgress(JSON.parse(e.newValue));
          } else {
            setProgress({});
          }
        } catch {
          setProgress(readStoredProgress());
        }
      }
    };

    window.addEventListener(STORAGE_EVENT, handleCustomEvent);
    window.addEventListener('storage', handleStorageEvent);

    return () => {
      window.removeEventListener(STORAGE_EVENT, handleCustomEvent);
      window.removeEventListener('storage', handleStorageEvent);
    };
  }, []);

  const getStatus = useCallback(
    (resourceId: string): ResourceProgressStatus => {
      return progress[resourceId] || 'not started';
    },
    [progress]
  );

  const setStatus = useCallback((resourceId: string, status: ResourceProgressStatus) => {
    setProgress((prev) => {
      const next = { ...prev, [resourceId]: status };
      writeStoredProgress(next);
      return next;
    });
  }, []);

  const cycleStatus = useCallback((resourceId: string): ResourceProgressStatus => {
    let nextStatus: ResourceProgressStatus = 'not started';
    setProgress((prev) => {
      const current = prev[resourceId] || 'not started';
      if (current === 'not started') {
        nextStatus = 'in progress';
      } else if (current === 'in progress') {
        nextStatus = 'completed';
      } else {
        nextStatus = 'not started';
      }
      const next = { ...prev, [resourceId]: nextStatus };
      writeStoredProgress(next);
      return next;
    });
    return nextStatus;
  }, []);

  const markNotStarted = useCallback(
    (resourceId: string) => {
      setStatus(resourceId, 'not started');
    },
    [setStatus]
  );

  const markInProgress = useCallback(
    (resourceId: string) => {
      setStatus(resourceId, 'in progress');
    },
    [setStatus]
  );

  const markCompleted = useCallback(
    (resourceId: string) => {
      setStatus(resourceId, 'completed');
    },
    [setStatus]
  );

  const toggleCompleted = useCallback(
    (resourceId: string) => {
      setProgress((prev) => {
        const current = prev[resourceId] || 'not started';
        const nextStatus: ResourceProgressStatus = current === 'completed' ? 'not started' : 'completed';
        const next = { ...prev, [resourceId]: nextStatus };
        writeStoredProgress(next);
        return next;
      });
    },
    []
  );

  const isCompleted = useCallback(
    (resourceId: string): boolean => {
      return (progress[resourceId] || 'not started') === 'completed';
    },
    [progress]
  );

  const isInProgress = useCallback(
    (resourceId: string): boolean => {
      return (progress[resourceId] || 'not started') === 'in progress';
    },
    [progress]
  );

  const isNotStarted = useCallback(
    (resourceId: string): boolean => {
      return (progress[resourceId] || 'not started') === 'not started';
    },
    [progress]
  );

  const resetAll = useCallback(() => {
    setProgress({});
    writeStoredProgress({});
  }, []);

  const getStats = useCallback(
    (resourceIds?: string[]): ResourceProgressStats => {
      const ids = resourceIds || Object.keys(progress);
      const total = ids.length;
      if (total === 0) {
        return {
          total: 0,
          completed: 0,
          inProgress: 0,
          notStarted: 0,
          percentCompleted: 0,
        };
      }

      let completed = 0;
      let inProgress = 0;
      let notStarted = 0;

      for (const id of ids) {
        const status = progress[id] || 'not started';
        if (status === 'completed') {
          completed++;
        } else if (status === 'in progress') {
          inProgress++;
        } else {
          notStarted++;
        }
      }

      const percentCompleted = Math.round((completed / total) * 100);

      return {
        total,
        completed,
        inProgress,
        notStarted,
        percentCompleted,
      };
    },
    [progress]
  );

  return useMemo(
    () => ({
      progress,
      getStatus,
      setStatus,
      cycleStatus,
      markNotStarted,
      markInProgress,
      markCompleted,
      toggleCompleted,
      isCompleted,
      isInProgress,
      isNotStarted,
      resetAll,
      getStats,
      buildResourceId,
    }),
    [
      progress,
      getStatus,
      setStatus,
      cycleStatus,
      markNotStarted,
      markInProgress,
      markCompleted,
      toggleCompleted,
      isCompleted,
      isInProgress,
      isNotStarted,
      resetAll,
      getStats,
    ]
  );
}
