export type MatchStatus = 'MATCHED' | 'PARTIAL' | 'MISSING' | 'UNCLEAR';
export type PriorityLevel = 'HIGH' | 'MEDIUM' | 'LOW';
export type EvidenceLevel =
  | 'Explicit'
  | 'Strongly demonstrated'
  | 'Demonstrated'
  | 'Mentioned only'
  | 'Weak evidence'
  | 'No evidence';

export interface CandidateInfo {
  name: string;
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  github: string;
  portfolio: string;
  professional_title?: string;
  career_level?: string;
  years_of_experience?: number;
  career_direction?: string;
  identity_clarity?: string;
  identity_evaluation?: string;
}

export interface EducationItem {
  degree: string;
  field: string;
  institution: string;
  graduation_year?: string | number;
  gpa?: string;
  relevant_coursework?: string[];
  academic_achievements?: string[];
  relevance_to_role?: string;
}

export interface WorkExperienceItem {
  role: string;
  company: string;
  duration: string;
  years: number;
  location?: string;
  responsibilities: string[];
  quantified_achievements: string[];
  technologies_used: string[];
  leadership_evidence?: string;
  title_clarity?: string;
  progression_note?: string;
  technical_depth?: string;
  business_impact?: string;
  role_relevance?: string;
}

export interface BulletDeepAnalysis {
  current: string;
  problem: string;
  why_it_matters: string;
  improved_version: string;
  rule_applied?: string;
  metrics_guidance?: string;
}

export interface WorkRoleDeepAnalysis {
  role: string;
  company: string;
  duration: string;
  title_clarity: string;
  career_progression: string;
  technical_depth: string;
  business_impact: string;
  role_relevance: string;
  seniority_alignment: string;
  bullets: BulletDeepAnalysis[];
}

export interface ProjectItem {
  name: string;
  description: string;
  technologies: string[];
  problem_solved?: string;
  responsibilities?: string[];
  quantified_impact?: string;
  evidence_strength: EvidenceLevel;
  candidate_contribution?: string;
  complexity?: string;
  relevance_to_role?: string;
  technical_depth?: string;
  outcome?: string;
  clarity?: string;
  recommendations_to_strengthen?: string[];
}

export interface SkillWithEvidence {
  name: string;
  category:
    | 'programming_language'
    | 'framework'
    | 'library'
    | 'database'
    | 'cloud'
    | 'devops'
    | 'ai_ml'
    | 'data'
    | 'design'
    | 'business'
    | 'soft'
    | 'domain';
  evidence_level: EvidenceLevel;
  context_evidence: string;
}

export interface ResumeQuality {
  overall_score: number; // 1 to 5
  structure_score: number;
  formatting_score: number;
  bullet_quality_score: number;
  action_verbs_score: number;
  quantified_impact_score: number;
  ats_readability: string;
  strengths: string[];
  weaknesses: string[];
}

export interface SummaryDeepAnalysis {
  current_summary: string;
  clarity_score: number; // 1 to 10
  relevance_score: number;
  specificity_score: number;
  career_positioning: string;
  keywords_present: string[];
  generic_language_detected: string[];
  evidence_evaluation: string;
  length_evaluation: string;
  impact_evaluation: string;
  problems: string[];
  improved_summary: string;
}

export interface CategorizedSkillsBreakdown {
  programming_languages: string[];
  frameworks: string[];
  libraries: string[];
  databases: string[];
  cloud: string[];
  devops: string[];
  ai_ml: string[];
  data: string[];
  testing: string[];
  tools: string[];
  design: string[];
  business_tools: string[];
  methodologies: string[];
  domain_skills: string[];
  soft_skills: string[];
  leadership_skills: string[];
  management_skills: string[];
  // Intelligence tiers
  strong_skills: string[];
  relevant_skills: string[];
  weakly_supported_skills: string[];
  skills_with_strong_evidence: string[];
  skills_mentioned_without_evidence: string[];
  potential_skill_gaps: string[];
}

export interface AchievementDeepAnalysis {
  overall_evaluation: string;
  impact_score: number; // 1 to 10
  scale_score: number;
  ownership_score: number;
  results_score: number;
  leadership_score: number;
  technical_contribution_score: number;
  business_value_score: number;
  weak_achievements: Array<{
    original: string;
    critique: string;
    recommendation_to_strengthen: string;
  }>;
}

export interface EducationDeepAnalysis {
  degree_evaluation: string;
  institution_evaluation: string;
  coursework_evaluation: string;
  relevance_to_role: string;
  penalty_note?: string; // e.g. "Candidate not unfairly penalized for non-traditional education"
  key_highlights: string[];
}

export interface CertificationDeepAnalysis {
  relevance_evaluation: string;
  clarity_evaluation: string;
  duplication_detected: boolean;
  duplication_notes?: string;
  recommendations: string[];
}

export interface AtsCheckItem {
  name: string;
  status: 'PASS' | 'WARNING' | 'FAIL';
  detail: string;
}

export interface AtsDeepAnalysis {
  overall_rating: 'High' | 'Medium' | 'Needs Attention';
  score_percentage: number;
  disclaimer: string; // e.g. "ATS scanners vary by employer. These recommendations follow universal parsing best practices."
  section_headings: AtsCheckItem;
  formatting_simplicity: AtsCheckItem;
  text_extractability: AtsCheckItem;
  contact_info_placement: AtsCheckItem;
  date_consistency: AtsCheckItem;
  job_title_clarity: AtsCheckItem;
  keyword_placement: AtsCheckItem;
  skills_readability: AtsCheckItem;
  tables_columns_graphics: AtsCheckItem;
  bullet_structure: AtsCheckItem;
  actionable_recommendations: string[];
}

export interface LanguageWritingDeepAnalysis {
  overall_score: number; // 1 to 10
  grammar_spelling: {
    status: 'Clean' | 'Minor Issues' | 'Needs Review';
    examples: string[];
    notes: string;
  };
  professional_tone: {
    evaluation: string;
    style: string;
  };
  sentence_structure: {
    evaluation: string;
    variety: string;
  };
  verb_strength: {
    strong_verbs_used: string[];
    weak_verbs_detected: string[];
    advice: string;
  };
  redundancy_and_wordiness: {
    detected_phrases: string[];
    recommended_cuts: string[];
  };
  passive_voice: {
    count: number;
    examples: string[];
  };
  buzzwords_and_cliches: {
    detected: string[];
    replacement_advice: string;
  };
}

export interface CareerLevelDeepAnalysis {
  target_level: string;
  detected_level: string;
  match_assessment: 'Strong Fit' | 'Borderline / Stretch' | 'Under-Leveled' | 'Over-Qualified';
  years_gap_analysis: string;
  scope_and_ownership_evaluation: string;
  expectations_met: string[];
  areas_to_elevate: string[];
}

export interface ImprovedResumeModel {
  header: {
    name: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    linkedin: string;
    github: string;
    portfolio: string;
  };
  professional_summary: string;
  skills_categorized: Record<string, string[]>;
  experience: Array<{
    role: string;
    company: string;
    duration: string;
    location?: string;
    bullets: string[];
  }>;
  projects: Array<{
    name: string;
    technologies: string[];
    problem_solved?: string;
    bullets: string[];
  }>;
  education: Array<{
    degree: string;
    institution: string;
    year?: string | number;
    details?: string;
  }>;
  certifications: string[];
}

export interface ResumeData {
  candidate: CandidateInfo;
  professional_summary: string;
  career_level: string;
  total_experience_years: number;
  education: EducationItem[];
  technical_skills: string[];
  programming_languages: string[];
  frameworks: string[];
  libraries: string[];
  databases: string[];
  cloud_platforms: string[];
  devops_tools: string[];
  ai_ml_tools: string[];
  data_tools: string[];
  design_tools: string[];
  business_tools: string[];
  soft_skills: string[];
  domain_skills: string[];
  certifications: string[];
  work_experience: WorkExperienceItem[];
  projects: ProjectItem[];
  achievements: string[];
  responsibilities: string[];
  quantified_impact: string[];
  keywords: string[];
  skills_with_evidence: SkillWithEvidence[];
  resume_quality: ResumeQuality;

  // Deep Analysis Modules
  summary_analysis?: SummaryDeepAnalysis;
  detailed_work_analysis?: WorkRoleDeepAnalysis[];
  detailed_project_analysis?: ProjectItem[];
  categorized_skills?: CategorizedSkillsBreakdown;
  achievement_analysis?: AchievementDeepAnalysis;
  education_analysis?: EducationDeepAnalysis;
  certification_analysis?: CertificationDeepAnalysis;
  ats_analysis?: AtsDeepAnalysis;
  language_writing_analysis?: LanguageWritingDeepAnalysis;
  career_level_analysis?: CareerLevelDeepAnalysis;
  improved_resume?: ImprovedResumeModel;
}

export interface JobData {
  job_title: string;
  company_inferred?: string;
  seniority_level:
    | 'Intern'
    | 'Entry Level'
    | 'Junior'
    | 'Mid Level'
    | 'Senior'
    | 'Lead'
    | 'Manager'
    | 'Senior Manager'
    | 'Director'
    | 'Executive';
  department: string;
  industry: string;
  required_skills: string[];
  preferred_skills: string[];
  nice_to_have: string[];
  technical_skills: string[];
  programming_languages: string[];
  frameworks: string[];
  libraries: string[];
  databases: string[];
  cloud_platforms: string[];
  tools: string[];
  methodologies: string[];
  soft_skills: string[];
  domain_knowledge: string[];
  certifications: string[];
  education_requirements: string[];
  experience_requirements: {
    min_years: number;
    preferred_years?: number;
    description: string;
  };
  responsibilities: string[];
  role_expectations: string[];
  leadership_requirements: string[];
  communication_requirements: string[];
  management_requirements: string[];
  keywords: string[];
}

export interface SkillMatch {
  skill: string;
  jobRequirement: string;
  isRequired: boolean;
  status: MatchStatus;
  priority: PriorityLevel;
  resumeEvidence: string;
  explanation: string;
  missingComponent?: string;
  candidateEquivalentSkill?: string;
}

export interface CategoryScore {
  name: string;
  earned: number;
  max: number;
  weight_percent: number;
  normalized_earned: number;
  score_percentage: number;
  explanation: string;
  details: string;
  is_applicable: boolean;
  deep_analysis_key?: string;
}

export interface ScoreResult {
  totalScore: number; // 0 - 100
  alignmentLevel: 'Strong Alignment' | 'Moderate Alignment' | 'Needs Improvement';
  summary: string;
  categories: {
    required_skills: CategoryScore;
    preferred_skills: CategoryScore;
    experience: CategoryScore;
    projects: CategoryScore;
    education: CategoryScore;
    certifications: CategoryScore;
    resume_quality: CategoryScore;
    ats_readiness: CategoryScore;
    content_clarity: CategoryScore;
    achievement_strength: CategoryScore;
    [key: string]: CategoryScore | undefined;
  };
  matched_count: number;
  partial_count: number;
  missing_count: number;
  total_requirements_count: number;
  formula_explanation: string;
}

export interface TopPriorityItem {
  skill: string;
  priority: PriorityLevel;
  reason: string;
  learning_topics: string[];
  practice_project: string;
  evidence_goal: string;
}

export interface ResumeImprovement {
  section: string;
  original_bullet: string;
  improved_bullet: string;
  reason: string;
  rule_applied: string;
  metrics_guidance?: string;
}

export interface RoadmapWeek {
  week: number;
  focus: string;
  topics: string[];
  practice: string;
  milestone: string;
}

export interface ProjectRecommendation {
  project: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  skills: string[];
  reason: string;
  features: string[];
  target_requirement: string;
}

export interface RecommendationData {
  top_priorities: TopPriorityItem[];
  resume_improvements: ResumeImprovement[];
  learning_roadmap: RoadmapWeek[];
  project_recommendations: ProjectRecommendation[];
  career_stage_advice: string;
  final_action_plan: string[];
}

export type ReadinessLevel = 'Strong' | 'Moderate' | 'Needs Improvement';

export interface ApplicationReadiness {
  skills: ReadinessLevel;
  experience: ReadinessLevel;
  projects: ReadinessLevel;
  resumeQuality: ReadinessLevel;
  roleAlignment: ReadinessLevel;
  summary: string;
}

export interface AnalysisReport {
  id: string;
  timestamp: string;
  resumeFileName: string;
  resumeFileType?: string;
  resumeFileSize?: number;
  resumePageCount?: number;
  targetCompany?: string;
  targetRole?: string;
  experienceLevel?: string;
  isJobDescriptionSupplied?: boolean;
  applicationReadiness?: ApplicationReadiness;
  targetGoal?: string;
  resumeData: ResumeData;
  jobData: JobData;
  skillMatches: SkillMatch[];
  scoreResult: ScoreResult;
  recommendations: RecommendationData;
}
