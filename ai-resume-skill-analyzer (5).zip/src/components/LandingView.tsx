
import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Calculator,
  Compass,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileText,
  Check,
  Layers,
  Award,
  Zap,
  TrendingUp,
  Cpu,
  BookOpen,
  FileCheck,
  Briefcase,
  ChevronRight,
  GraduationCap,
} from 'lucide-react';
import { SAMPLE_DATASETS, SamplePair } from '../../server/sampleData';

interface LandingViewProps {
  onStartAnalysis: () => void;
  onSelectSample: (sample: SamplePair) => void;
  onOpenFormula: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onStartAnalysis,
  onSelectSample,
  onOpenFormula,
}) => {
  // Interactive preview state for the Hero workflow
  const [activeWorkflowStep, setActiveWorkflowStep] = useState<number>(3); // 3 = "Score & Gaps"

  const workflowSteps = [
    { id: 0, label: 'Resume Upload', short: 'Upload' },
    { id: 1, label: 'AI Analysis', short: 'Analysis' },
    { id: 2, label: 'Skill Matching', short: 'Matching' },
    { id: 3, label: 'Score & Gaps', short: 'Score' },
    { id: 4, label: 'Roadmap & Rewrite', short: 'Roadmap' },
  ];

  const keyCapabilities = [
    { title: 'Deep Resume Analysis', desc: 'Section-by-section breakdown' },
    { title: 'AI Skill Matching', desc: 'Ontology & alias normalization' },
    { title: 'Skill Gap Detection', desc: 'Exact missing & preferred skills' },
    { title: 'Personalized Learning Roadmap', desc: '30-60-90 day milestone guides' },
    { title: 'AI Resume Improvement', desc: 'Google X-Y-Z metric rewrites' },
    { title: 'PDF Resume Generation', desc: 'Production-ready export format' },
  ];

  return (
    <div className="space-y-16 py-4 sm:py-8">
      {/* 1. HERO SECTION (1st Semester IDT Engineering Project - BMSIT&M) */}
      <section className="relative max-w-6xl mx-auto px-4 sm:px-6">
        {/* Subtle Ambient Background Glow */}
        <div 
          aria-hidden="true" 
          className="absolute -top-12 left-1/2 -translate-x-1/2 w-full max-w-4xl h-72 bg-gradient-to-b from-indigo-100/40 via-slate-100/20 to-transparent blur-3xl pointer-events-none -z-10" 
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          {/* Left Column: Academic Identity, Main Value Prop, Capabilities & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-left">
            {/* Academic Badge & Institutional Identifier */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 text-white text-xs font-medium shadow-xs tracking-wide">
                <span className="text-sm leading-none" role="img" aria-label="Graduation Cap">🎓</span>
                <span className="font-semibold text-slate-100">1st Semester IDT Project</span>
                <span className="text-slate-400">·</span>
                <span className="text-indigo-300 font-mono text-2xs uppercase tracking-wider">Engineering 2026</span>
              </div>

              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 pl-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 inline-block"></span>
                <span>BMS Institute of Technology and Management, Bengaluru</span>
              </div>
            </div>

            {/* Main Product Heading & Supporting Headline */}
            <div className="space-y-2">
              <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                AI Resume Skill Analyzer
              </h1>
              <p className="text-lg sm:text-xl font-bold bg-gradient-to-r from-indigo-700 via-indigo-600 to-slate-800 bg-clip-text text-transparent">
                Analyze. Improve. Learn. Build a Better Career.
              </p>
            </div>

            {/* Academic Project Context Row */}
            <div className="inline-flex flex-wrap items-center gap-x-3 gap-y-1 py-1.5 px-3 rounded-lg bg-slate-100/90 border border-slate-200/80 text-2xs sm:text-xs text-slate-600 font-medium">
              <span className="text-slate-800 font-semibold flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                Academic Project
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-700">IDT – Innovation & Design Thinking</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-700">1st Semester Engineering</span>
            </div>

            {/* Concise Description */}
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
              An AI-powered resume analysis and career improvement platform that analyzes your resume, identifies skill gaps, matches your profile with target roles, recommends what to learn, and helps you create an improved resume.
            </p>

            {/* Key Capabilities: Compact Row/Grid of Interactive Pills/Cards */}
            <div className="space-y-2 pt-1">
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block">
                Key System Capabilities
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {keyCapabilities.map((cap) => (
                  <div
                    key={cap.title}
                    className="p-2 sm:py-2 sm:px-2.5 rounded-lg bg-white border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/20 transition-all text-left shadow-2xs group cursor-default"
                  >
                    <div className="flex items-start gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 group-hover:text-indigo-950 truncate">
                          {cap.title}
                        </div>
                        <div className="text-2xs text-slate-500 hidden sm:block truncate">
                          {cap.desc}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Main CTAs */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={onStartAnalysis}
                className="px-6 py-3 text-sm font-bold text-white bg-slate-900 hover:bg-indigo-600 rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 group"
              >
                <span>Analyze My Resume</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
              </button>

              <button
                onClick={onOpenFormula}
                className="px-5 py-3 text-sm font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 hover:border-slate-300 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Calculator className="w-4 h-4 text-indigo-600" />
                <span>Explore How It Works</span>
              </button>
            </div>

            {/* Quick 1-Click Preset Selector */}
            <div className="pt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span className="font-semibold text-slate-700">Or test with 1-click preset:</span>
              {SAMPLE_DATASETS.map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => onSelectSample(sample)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-md border border-slate-200 cursor-pointer font-medium text-xs transition-colors hover:border-slate-300 shadow-2xs"
                >
                  {sample.name}
                </button>
              ))}
            </div>

            {/* Subtle Project Label near the bottom of hero content */}
            <div className="pt-3 border-t border-slate-100 flex items-center gap-2 text-2xs text-slate-500">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
              <span>
                <strong className="text-slate-700 font-semibold">Built as an IDT Engineering Project</strong>
                {' '}&bull;{' '}
                <span>BMS Institute of Technology and Management &bull; Bengaluru</span>
              </span>
            </div>
          </div>

          {/* Right Column: Hero Visual / Interactive Product Preview */}
          <div className="lg:col-span-5 relative">
            {/* Visual Container */}
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-lg relative overflow-hidden">
              {/* Card Header & Simulated Live Status */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-tight">
                      AI Resume Analysis
                    </h3>
                    <p className="text-2xs text-slate-500">Target: Senior Full Stack Engineer &bull; Google</p>
                  </div>
                </div>

                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-2xs font-semibold text-emerald-700 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>PREVIEW</span>
                </div>
              </div>

              {/* Match Score Display */}
              <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/80 mb-4">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold text-slate-700">Deterministic Match Score</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-extrabold text-slate-900 font-mono tracking-tight">87</span>
                    <span className="text-xs font-bold text-slate-400 font-mono">/100</span>
                  </div>
                </div>

                {/* Score Progress Bar */}
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mb-2">
                  <div 
                    className="bg-indigo-600 h-full rounded-full transition-all duration-700" 
                    style={{ width: '87%' }} 
                  />
                </div>

                <div className="flex items-center justify-between text-2xs text-slate-500">
                  <span className="text-emerald-600 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Strong Candidate Match
                  </span>
                  <span className="font-mono text-slate-600 font-medium">Top 8% Profile</span>
                </div>
              </div>

              {/* Skill Matching Preview Section */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-2xs font-bold text-slate-500 uppercase tracking-wider">
                  <span>Skill Alignment Audit</span>
                  <span className="text-slate-400">4 of 5 Required</span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-xs">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600" /> Python (FastAPI &amp; AsyncIO)
                    </span>
                    <span className="text-2xs font-mono font-bold text-emerald-700 bg-white px-1.5 py-0.5 rounded border border-emerald-200">
                      Match
                    </span>
                  </div>

                  <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-emerald-50/60 border border-emerald-100 text-xs">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600" /> SQL (PostgreSQL &amp; Optimization)
                    </span>
                    <span className="text-2xs font-mono font-bold text-emerald-700 bg-white px-1.5 py-0.5 rounded border border-emerald-200">
                      Match
                    </span>
                  </div>

                  <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-amber-50/60 border border-amber-100 text-xs">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> React (Found in Projects)
                    </span>
                    <span className="text-2xs font-mono font-bold text-amber-700 bg-white px-1.5 py-0.5 rounded border border-amber-200">
                      Partial
                    </span>
                  </div>

                  <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-rose-50/60 border border-rose-100 text-xs">
                    <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                      <XCircle className="w-3.5 h-3.5 text-rose-600" /> Docker &amp; Kubernetes
                    </span>
                    <span className="text-2xs font-mono font-bold text-rose-700 bg-white px-1.5 py-0.5 rounded border border-rose-200">
                      Gap
                    </span>
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 flex items-center justify-between text-2xs text-slate-600">
                  <span className="font-semibold text-rose-600 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                    Skill gaps identified
                  </span>
                  <span className="text-indigo-600 font-bold hover:underline cursor-pointer" onClick={onStartAnalysis}>
                    View 30-Day Plan &rarr;
                  </span>
                </div>
              </div>

              {/* End-to-End Workflow Stepper Indicator */}
              <div className="pt-2 border-t border-slate-100">
                <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Integrated Career Workflow
                </span>
                <div className="flex items-center justify-between gap-1 text-2xs font-semibold">
                  {workflowSteps.map((step, idx) => (
                    <button
                      key={step.id}
                      onClick={() => setActiveWorkflowStep(step.id)}
                      className={`px-1.5 py-1 rounded transition-colors text-center cursor-pointer flex-1 ${
                        activeWorkflowStep === step.id
                          ? 'bg-indigo-600 text-white shadow-2xs font-bold'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                      title={step.label}
                    >
                      {step.short}
                    </button>
                  ))}
                </div>
              </div>

              {/* Floating Highlight Badge */}
              <div className="mt-3 p-2 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-100 text-2xs text-indigo-900 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="font-medium">
                    Google X-Y-Z Bullet Rewrite: <strong>+14% impact score</strong>
                  </span>
                </div>
                <span className="text-2xs font-bold text-indigo-600 underline cursor-pointer" onClick={onStartAnalysis}>
                  Try It
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Visual Architecture Pipeline */}
      <section id="pipeline-architecture" className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-10 shadow-xs max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-2xs font-bold uppercase tracking-widest text-indigo-600 block mb-1">
            End-to-End System Pipeline
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
            From Raw Documents to Strategic Career Action
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Built on a multi-tier pipeline combining deep semantic parsing with deterministic mathematical evaluation.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            {
              step: '01',
              title: 'Ingestion & Parsing',
              desc: 'Extracts full text from PDF / Word documents into structured metadata and verified skills.',
            },
            {
              step: '02',
              title: 'Ontology Normalizer',
              desc: 'Canonicalizes aliases (React.js → React) while strictly preventing invalid cross-matches.',
            },
            {
              step: '03',
              title: 'Deterministic Score',
              desc: 'Calculates explainable 100-pt rubric across 7 categories with dynamic weight redistribution.',
            },
            {
              step: '04',
              title: 'Roadmap & Rewrites',
              desc: 'Drafts Google X-Y-Z resume bullet rewrites and week-by-week learning milestones.',
            },
          ].map((item) => (
            <div key={item.step} className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl relative">
              <span className="text-2xs font-mono font-bold text-indigo-600 bg-white border border-indigo-100 px-2 py-0.5 rounded shadow-2xs inline-block mb-2">
                {item.step}
              </span>
              <h3 className="font-bold text-sm text-slate-900 mb-1">{item.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Core Pillars Grid */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <Calculator className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Mathematical 100-Point Model
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              No black-box AI guessing. The application code deterministically sums points across Required Skills (40), Preferred Skills (15), Experience (15), Projects (10), Education (10), Certifications (5), and Resume Quality (5).
            </p>
          </div>

          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Strict Hallucination Controls
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Never invents fake companies, fake skills, fake project dates, or imaginary achievements. Every single match and rewrite is grounded strictly in evidence found in the supplied documents.
            </p>
          </div>

          <div className="p-6 bg-white border border-slate-200 rounded-xl shadow-xs space-y-3">
            <div className="w-10 h-10 rounded-lg bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Any Seniority & Any Domain
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Adapts dynamically to Intern, Entry-level, Mid-level, Senior, or Director tiers. Works flawlessly for Software, Data Science, Product Management, Marketing, Design, Healthcare, Finance, and Operations.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Bottom CTA */}
      <section className="bg-slate-900 rounded-2xl p-8 sm:p-12 text-center text-white max-w-5xl mx-auto shadow-xl">
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Ready to Audit Your Job Alignment?
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-xl mx-auto">
          Start by dropping in your resume file or exploring with our built-in sample career profiles.
        </p>
        <button
          onClick={onStartAnalysis}
          className="mt-6 px-6 py-3 text-sm font-bold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-md transition-all cursor-pointer inline-flex items-center gap-2"
        >
          <span>Open Analyzer Workspace</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </section>
    </div>
  );
};
