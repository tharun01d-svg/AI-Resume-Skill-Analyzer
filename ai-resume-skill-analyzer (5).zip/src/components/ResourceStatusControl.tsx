import React, { useState, useRef, useEffect } from 'react';
import {
  useLearningProgress,
  ResourceProgressStatus,
} from '../hooks/useLearningProgress';
import { CheckCircle2, Clock, Circle, ChevronDown, Check } from 'lucide-react';

interface ResourceStatusControlProps {
  resourceId: string;
  compact?: boolean;
  className?: string;
  onStatusChange?: (newStatus: ResourceProgressStatus) => void;
}

export const ResourceStatusControl: React.FC<ResourceStatusControlProps> = ({
  resourceId,
  compact = false,
  className = '',
  onStatusChange,
}) => {
  const { getStatus, setStatus, cycleStatus } = useLearningProgress();
  const currentStatus: ResourceProgressStatus = getStatus(resourceId);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    if (dropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownOpen]);

  const handleCycle = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const nextStatus = cycleStatus(resourceId);
    if (onStatusChange) {
      onStatusChange(nextStatus);
    }
  };

  const handleSelectStatus = (e: React.MouseEvent, status: ResourceProgressStatus) => {
    e.stopPropagation();
    e.preventDefault();
    setStatus(resourceId, status);
    setDropdownOpen(false);
    if (onStatusChange) {
      onStatusChange(status);
    }
  };

  const toggleDropdown = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setDropdownOpen((prev) => !prev);
  };

  // Status configuration
  const config = {
    'not started': {
      label: 'Not Started',
      badgeClass: 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200/80',
      activeIndicator: 'bg-slate-300',
      icon: Circle,
      iconClass: 'text-slate-400',
    },
    'in progress': {
      label: 'In Progress',
      badgeClass: 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100',
      activeIndicator: 'bg-amber-500 animate-pulse',
      icon: Clock,
      iconClass: 'text-amber-600',
    },
    'completed': {
      label: 'Completed',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100',
      activeIndicator: 'bg-emerald-500',
      icon: CheckCircle2,
      iconClass: 'text-emerald-600',
    },
  }[currentStatus];

  const Icon = config.icon;

  if (compact) {
    return (
      <div className={`relative inline-flex items-center ${className}`} ref={dropdownRef}>
        <button
          type="button"
          onClick={handleCycle}
          title={`Status: ${config.label}. Click to cycle status.`}
          className={`px-2 py-0.5 rounded text-3xs font-bold uppercase tracking-wider border transition-all flex items-center gap-1 cursor-pointer select-none ${config.badgeClass}`}
        >
          <Icon className={`w-3 h-3 ${config.iconClass}`} />
          <span>{config.label}</span>
        </button>
      </div>
    );
  }

  return (
    <div className={`relative inline-flex items-center ${className}`} ref={dropdownRef}>
      <div className="inline-flex rounded-lg border border-slate-200/90 bg-white shadow-2xs overflow-hidden text-2xs">
        {/* Main Click Button (Cycles status) */}
        <button
          type="button"
          onClick={handleCycle}
          title={`Status: ${config.label}. Click to cycle: Not Started ➔ In Progress ➔ Completed`}
          className={`px-2.5 py-1 font-semibold flex items-center gap-1.5 transition-colors cursor-pointer select-none border-r border-slate-200/80 ${config.badgeClass}`}
        >
          <Icon className={`w-3.5 h-3.5 ${config.iconClass}`} />
          <span>{config.label}</span>
        </button>

        {/* Dropdown Chevron for explicit selection */}
        <button
          type="button"
          onClick={toggleDropdown}
          aria-label="Select resource status"
          className="px-1.5 py-1 text-slate-400 hover:text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-center"
        >
          <ChevronDown className="w-3 h-3" />
        </button>
      </div>

      {/* Dropdown Menu */}
      {dropdownOpen && (
        <div className="absolute right-0 top-full mt-1 w-36 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-30 text-2xs animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="px-2.5 py-1 text-3xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
            Resource Status
          </div>
          {(['not started', 'in progress', 'completed'] as ResourceProgressStatus[]).map((st) => {
            const isSelected = currentStatus === st;
            const ItemIcon =
              st === 'completed'
                ? CheckCircle2
                : st === 'in progress'
                ? Clock
                : Circle;
            const itemColor =
              st === 'completed'
                ? 'text-emerald-600'
                : st === 'in progress'
                ? 'text-amber-600'
                : 'text-slate-400';

            return (
              <button
                key={st}
                type="button"
                onClick={(e) => handleSelectStatus(e, st)}
                className={`w-full px-2.5 py-1.5 flex items-center justify-between text-left transition-colors cursor-pointer ${
                  isSelected ? 'bg-indigo-50 font-bold text-indigo-900' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ItemIcon className={`w-3.5 h-3.5 ${itemColor}`} />
                  <span className="capitalize">{st}</span>
                </div>
                {isSelected && <Check className="w-3 h-3 text-indigo-600" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
