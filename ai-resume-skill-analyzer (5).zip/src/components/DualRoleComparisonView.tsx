import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AnalysisReport,
  ResumeData,
  SkillMatch,
  MatchStatus,
  ApplicationReadiness,
  ReadinessLevel,
} from '../types/analyzer';
import { evaluateRoleForResume } from '../utils/clientPipeline';
import { POPULAR_ROLES, JOB_CATEGORIES, SENIORITY_LEVELS } from '../data/jobRoles';
import { TOP_COMPANIES } from '../data/companies';
import { CompanyLogo } from './CompanyLogo';
import {
  ArrowLeftRight,
  CheckCircle2,
  AlertCircle,
  XCircle,
  Search,
  Filter,
  Sparkles,
  Target,
  Briefcase,
  Layers,
  ArrowRight,
  TrendingUp,
  BarChart2,
  ChevronDown,
  Scale,
  Award,
  BookOpen,
} from 'lucide-react';
import { fadeUpVariants } from '../utils/motion';

interface DualRoleComparisonViewProps {
  report: AnalysisReport;
  onNavigateToRoadmap?: () => void;
}

interface RoleConfig {
  role: string;
  company: string;
  seniority: string;
  jobDescription?: string;
}

const PRESET_COMPARISONS: { label: string; roleA: string; roleB: string; description: string }[] = [
  {
    label: 'Frontend vs Full Stack',
    roleA: 'Frontend Developer',
    roleB: 'Full Stack Developer',
    description: 'Compare UI-heavy specialization vs full-lifecycle architecture.',
  },
  {
    label: 'Software Engineer vs DevOps',
    roleA: 'Software Engineer',
    roleB: 'DevOps Engineer',
    description: 'Compare application feature development vs cloud infrastructure.',
  },
  {
    label: 'Backend vs Cloud Architect',
    roleA: 'Backend Engineer',
    roleB: 'Cloud Engineer',
    description: 'Compare service APIs & databases vs distributed cloud systems.',
  },
  {
    label: 'Data Analyst vs Data Scientist',
    roleA: 'Data Analyst',
    roleB: 'Data Scientist',
    description: 'Compare BI & SQL reporting vs machine learning algorithms.',
  },
  {
    label: 'Software Engineer vs AI Engineer',
    roleA: 'Software Engineer',
    roleB: 'AI Engineer',
    description: 'Compare traditional software engineering vs LLM/AI model workflows.',
  },
];

export const DualRoleComparisonView: React.FC<DualRoleComparisonViewProps> = ({
  report,
  onNavigateToRoadmap,
}) => {
  const { resumeData, targetRole: initialRole, targetCompany: initialCompany, experienceLevel: initialLevel } = report;

  // Determine intelligent default for Role B based on Role A
  const defaultRoleB = useMemo(() => {
    const current = (initialRole || '').toLowerCase();
    if (current.includes('data')) return 'Machine Learning Engineer';
    if (current.includes('frontend')) return 'Full Stack Developer';
    if (current.includes('devops') || current.includes('cloud')) return 'Site Reliability Engineer';
    if (current.includes('product')) return 'Technical Program Manager';
    return 'DevOps Engineer';
  }, [initialRole]);

  // Role Configurations
  const [roleAConfig, setRoleAConfig] = useState<RoleConfig>({
    role: initialRole || 'Software Engineer',
    company: initialCompany || 'Google',
    seniority: initialLevel || '2–4 Years',
  });

  const [roleBConfig, setRoleBConfig] = useState<RoleConfig>({
    role: defaultRoleB,
    company: initialCompany || 'Amazon',
    seniority: initialLevel || '2–4 Years',
  });

  // UI Filters for the skill comparison table
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'both_matched' | 'gap_either' | 'shared_only'>('all');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [expandedSkill, setExpandedSkill] = useState<string | null>(null);

  // Compute evaluations for both roles using the existing data structure & pipeline
  const evalA = useMemo(() => {
    // If Role A matches the primary report and hasn't changed, reuse primary report data
    if (
      roleAConfig.role === report.targetRole &&
      roleAConfig.company === report.targetCompany &&
      roleAConfig.seniority === report.experienceLevel
    ) {
      return {
        targetRole: report.targetRole,
        targetCompany: report.targetCompany || 'Target Organization',
        experienceLevel: report.experienceLevel || '2–4 Years',
        jobData: report.jobData,
        skillMatches: report.skillMatches,
        scoreResult: report.scoreResult,
        recommendations: report.recommendations,
        applicationReadiness: report.applicationReadiness,
      };
    }
    return evaluateRoleForResume({
      resumeData,
      targetRole: roleAConfig.role,
      targetCompany: roleAConfig.company,
      experienceLevel: roleAConfig.seniority,
    });
  }, [resumeData, roleAConfig, report]);

  const evalB = useMemo(() => {
    return evaluateRoleForResume({
      resumeData,
      targetRole: roleBConfig.role,
      targetCompany: roleBConfig.company,
      experienceLevel: roleBConfig.seniority,
    });
  }, [resumeData, roleBConfig]);

  // Swap Roles handler
  const handleSwapRoles = () => {
    const temp = { ...roleAConfig };
    setRoleAConfig({ ...roleBConfig });
    setRoleBConfig(temp);
  };

  // Preset selector
  const handleApplyPreset = (preset: (typeof PRESET_COMPARISONS)[0]) => {
    setRoleAConfig((prev) => ({ ...prev, role: preset.roleA }));
    setRoleBConfig((prev) => ({ ...prev, role: preset.roleB }));
  };

  // High-level statistics
  const scoreA = Math.round(evalA.scoreResult.totalScore);
  const scoreB = Math.round(evalB.scoreResult.totalScore);
  const scoreDelta = scoreA - scoreB;

  const matchedCountA = evalA.skillMatches.filter((m) => m.status === 'MATCHED').length;
  const partialCountA = evalA.skillMatches.filter((m) => m.status === 'PARTIAL').length;
  const missingCountA = evalA.skillMatches.filter((m) => m.status === 'MISSING').length;

  const matchedCountB = evalB.skillMatches.filter((m) => m.status === 'MATCHED').length;
  const partialCountB = evalB.skillMatches.filter((m) => m.status === 'PARTIAL').length;
  const missingCountB = evalB.skillMatches.filter((m) => m.status === 'MISSING').length;

  // Unified skill comparison map
  interface UnifiedSkillRow {
    skill: string;
    category: string;
    inRoleA: boolean;
    inRoleB: boolean;
    matchA?: SkillMatch;
    matchB?: SkillMatch;
    resumeEvidence?: string;
  }

  const unifiedSkills = useMemo(() => {
    const skillMap = new Map<string, UnifiedSkillRow>();

    // Process Role A
    evalA.skillMatches.forEach((m) => {
      const key = m.skill.toLowerCase().trim();
      const existing = skillMap.get(key);
      if (!existing) {
        skillMap.set(key, {
          skill: m.skill,
          category: 'Technical',
          inRoleA: true,
          inRoleB: false,
          matchA: m,
          resumeEvidence: m.resumeEvidence || undefined,
        });
      } else {
        existing.inRoleA = true;
        existing.matchA = m;
        if (!existing.resumeEvidence && m.resumeEvidence) {
          existing.resumeEvidence = m.resumeEvidence;
        }
      }
    });

    // Process Role B
    evalB.skillMatches.forEach((m) => {
      const key = m.skill.toLowerCase().trim();
      const existing = skillMap.get(key);
      if (!existing) {
        skillMap.set(key, {
          skill: m.skill,
          category: 'Technical',
          inRoleA: false,
          inRoleB: true,
          matchB: m,
          resumeEvidence: m.resumeEvidence || undefined,
        });
      } else {
        existing.inRoleB = true;
        existing.matchB = m;
        if (!existing.resumeEvidence && m.resumeEvidence) {
          existing.resumeEvidence = m.resumeEvidence;
        }
      }
    });

    return Array.from(skillMap.values());
  }, [evalA.skillMatches, evalB.skillMatches]);

  // Categorize skills into Shared, Only Role A, Only Role B
  const sharedSkills = useMemo(
    () => unifiedSkills.filter((s) => s.inRoleA && s.inRoleB),
    [unifiedSkills]
  );
  const onlySkillsA = useMemo(
    () => unifiedSkills.filter((s) => s.inRoleA && !s.inRoleB),
    [unifiedSkills]
  );
  const onlySkillsB = useMemo(
    () => unifiedSkills.filter((s) => !s.inRoleA && s.inRoleB),
    [unifiedSkills]
  );

  // Filtered skills for display
  const filteredSkills = useMemo(() => {
    return unifiedSkills.filter((item) => {
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesSkill = item.skill.toLowerCase().includes(query);
        const matchesEvidence = item.resumeEvidence?.toLowerCase().includes(query);
        if (!matchesSkill && !matchesEvidence) return false;
      }

      // Status filter
      if (statusFilter === 'both_matched') {
        const isMatchedA = item.matchA?.status === 'MATCHED';
        const isMatchedB = item.matchB?.status === 'MATCHED';
        return isMatchedA && isMatchedB;
      }
      if (statusFilter === 'gap_either') {
        const isGapA = item.matchA?.status === 'MISSING';
        const isGapB = item.matchB?.status === 'MISSING';
        return isGapA || isGapB;
      }
      if (statusFilter === 'shared_only') {
        return item.inRoleA && item.inRoleB;
      }

      return true;
    });
  }, [unifiedSkills, searchQuery, statusFilter]);

  // Standard category list for side-by-side bar comparison
  const categoryKeys = [
    { key: 'required_skills', label: 'Required Skills' },
    { key: 'preferred_skills', label: 'Preferred Skills' },
    { key: 'experience', label: 'Experience Alignment' },
    { key: 'projects', label: 'Projects & Portfolio' },
    { key: 'education', label: 'Education Match' },
    { key: 'certifications', label: 'Certifications' },
    { key: 'resume_quality', label: 'Resume Quality' },
    { key: 'ats_readiness', label: 'ATS Parsability' },
  ];

  // Helper for status badge
  const renderStatusBadge = (match?: SkillMatch) => {
    if (!match) {
      return (
        <span className="text-2xs text-slate-400 font-medium italic">
          Not Required
        </span>
      );
    }
    if (match.status === 'MATCHED') {
      return (
        <span className="inline-flex items-center gap-1 text-2xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
          <span>Strong Match</span>
        </span>
      );
    }
    if (match.status === 'PARTIAL') {
      return (
        <span className="inline-flex items-center gap-1 text-2xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
          <AlertCircle className="w-3 h-3 text-amber-600" />
          <span>Partial Match</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-2xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
        <XCircle className="w-3 h-3 text-rose-600" />
        <span>Skill Gap</span>
      </span>
    );
  };

  const renderReadinessPill = (level?: ReadinessLevel) => {
    if (!level) return null;
    const styles: Record<ReadinessLevel, { text: string; bg: string }> = {
      Strong: { text: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
      Moderate: { text: 'text-indigo-700', bg: 'bg-indigo-50 border-indigo-200' },
      'Needs Improvement': { text: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
    };
    const s = styles[level] || styles.Moderate;
    return (
      <span className={`text-2xs font-bold px-2 py-0.5 rounded border ${s.text} ${s.bg}`}>
        {level}
      </span>
    );
  };

  return (
    <div className="space-y-8">
      {/* 1. Header & Context Intro */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
              <Scale className="w-3.5 h-3.5" />
              <span>Comparative Career Calibration</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Dual-Role Skill Alignment & Side-by-Side Comparison
            </h2>
            <p className="text-xs text-slate-500 max-w-3xl leading-relaxed">
              Benchmark your current verified resume qualifications against two distinct target roles simultaneously.
              Evaluate shared core strengths, role-specific qualification gaps, and calculate your fastest pathway to interview readiness.
            </p>
          </div>

          {/* Quick preset comparisons dropdown/selector */}
          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={handleSwapRoles}
              className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-200 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-2xs"
              title="Swap Role A and Role B"
            >
              <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-600" />
              <span>Swap Roles</span>
            </button>
          </div>
        </div>

        {/* Quick Pivot Scenario Presets */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 mr-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-500" /> Quick Pivots:
          </span>
          {PRESET_COMPARISONS.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handleApplyPreset(preset)}
              className="text-2xs px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 font-medium transition-colors cursor-pointer border border-transparent hover:border-indigo-200"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Interactive Role Selection Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Role A Configuration Card */}
        <div className="bg-white border-2 border-indigo-200/80 rounded-2xl p-5 shadow-xs relative overflow-hidden space-y-4">
          <div className="absolute top-0 left-0 right-0 h-1 bg-indigo-600" />
          <div className="flex items-center justify-between">
            <span className="text-2xs font-black tracking-wider uppercase text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
              Target Role A
            </span>
            <span className="text-2xs text-slate-400">Baseline Evaluation</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Target Role
              </label>
              <select
                value={roleAConfig.role}
                onChange={(e) => setRoleAConfig({ ...roleAConfig, role: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
              >
                {POPULAR_ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Company
              </label>
              <select
                value={roleAConfig.company}
                onChange={(e) => setRoleAConfig({ ...roleAConfig, company: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
              >
                {TOP_COMPANIES.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Seniority Tier
              </label>
              <select
                value={roleAConfig.seniority}
                onChange={(e) => setRoleAConfig({ ...roleAConfig, seniority: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
              >
                {SENIORITY_LEVELS.slice(1, 9).map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Role B Configuration Card */}
        <div className="bg-white border-2 border-emerald-200/80 rounded-2xl p-5 shadow-xs relative overflow-hidden space-y-4">
          <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500" />
          <div className="flex items-center justify-between">
            <span className="text-2xs font-black tracking-wider uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              Target Role B
            </span>
            <span className="text-2xs text-slate-400">Comparison Evaluation</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Target Role
              </label>
              <select
                value={roleBConfig.role}
                onChange={(e) => setRoleBConfig({ ...roleBConfig, role: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
              >
                {POPULAR_ROLES.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Company
              </label>
              <select
                value={roleBConfig.company}
                onChange={(e) => setRoleBConfig({ ...roleBConfig, company: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
              >
                {TOP_COMPANIES.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-1 space-y-1">
              <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                Seniority Tier
              </label>
              <select
                value={roleBConfig.seniority}
                onChange={(e) => setRoleBConfig({ ...roleBConfig, seniority: e.target.value })}
                className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none cursor-pointer"
              >
                {SENIORITY_LEVELS.slice(1, 9).map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Executive Score & Alignment Comparison Cards */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch">
        {/* Role A Summary Card */}
        <div className="md:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <CompanyLogo name={roleAConfig.company} size="md" />
                <div>
                  <h3 className="text-lg font-black text-slate-900 leading-tight">
                    {roleAConfig.role}
                  </h3>
                  <div className="text-xs text-slate-500">
                    <span>{roleAConfig.company}</span>
                    <span className="mx-1.5">·</span>
                    <span>{roleAConfig.seniority}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-3xl font-black text-indigo-600 tracking-tight font-mono">
                  {scoreA}
                  <span className="text-xs text-slate-400 font-sans font-normal ml-0.5">/100</span>
                </div>
                <span className="text-2xs font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                  {evalA.scoreResult.alignmentLevel}
                </span>
              </div>
            </div>

            {/* Score progress bar */}
            <div className="mt-4 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${scoreA}%` }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="h-full bg-indigo-600 rounded-full"
              />
            </div>

            {/* Skill Match Breakdown */}
            <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-100 text-center">
              <div className="p-2 bg-emerald-50/60 rounded-xl border border-emerald-100">
                <span className="text-xs font-black text-emerald-700 font-mono">{matchedCountA}</span>
                <span className="block text-2xs font-medium text-emerald-600">Strong</span>
              </div>
              <div className="p-2 bg-amber-50/60 rounded-xl border border-amber-100">
                <span className="text-xs font-black text-amber-700 font-mono">{partialCountA}</span>
                <span className="block text-2xs font-medium text-amber-600">Partial</span>
              </div>
              <div className="p-2 bg-rose-50/60 rounded-xl border border-rose-100">
                <span className="text-xs font-black text-rose-700 font-mono">{missingCountA}</span>
                <span className="block text-2xs font-medium text-rose-600">Gaps</span>
              </div>
            </div>
          </div>

          {/* Application Readiness Pillars */}
          {evalA.applicationReadiness && (
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                Readiness Calibration
              </span>
              <div className="grid grid-cols-2 gap-2 text-2xs">
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Skills:</span>
                  {renderReadinessPill(evalA.applicationReadiness.skills)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Experience:</span>
                  {renderReadinessPill(evalA.applicationReadiness.experience)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Projects:</span>
                  {renderReadinessPill(evalA.applicationReadiness.projects)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Overall:</span>
                  {renderReadinessPill(evalA.applicationReadiness.roleAlignment)}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Center Comparison Verdict & Delta Card */}
        <div className="md:col-span-2 bg-gradient-to-b from-slate-900 to-indigo-950 text-white rounded-2xl p-5 shadow-xs flex flex-col justify-between text-center relative overflow-hidden">
          <div className="space-y-2">
            <span className="text-2xs font-bold tracking-wider uppercase text-indigo-300">
              Score Delta
            </span>

            <div className="py-2">
              <div className="text-3xl font-black font-mono tracking-tight text-white">
                {scoreDelta === 0 ? '0' : scoreDelta > 0 ? `+${scoreDelta}` : `${scoreDelta}`}
              </div>
              <span className="text-2xs text-slate-300">
                {scoreDelta > 0 ? (
                  <>Favors <strong>{roleAConfig.role}</strong></>
                ) : scoreDelta < 0 ? (
                  <>Favors <strong>{roleBConfig.role}</strong></>
                ) : (
                  <>Equal Alignment</>
                )}
              </span>
            </div>
          </div>

          <div className="py-3 px-2.5 bg-white/10 rounded-xl border border-white/10 text-2xs text-slate-200 leading-snug">
            {scoreDelta > 5 ? (
              <p>
                Your resume exhibits higher immediate coverage for <strong>{roleAConfig.role}</strong>. It requires fewer new competencies to qualify.
              </p>
            ) : scoreDelta < -5 ? (
              <p>
                Your profile demonstrates stronger native readiness for <strong>{roleBConfig.role}</strong>. Consider this role for higher interview callback odds.
              </p>
            ) : (
              <p>
                Your skill set is equally competitive across both positions. Selection hinges on your personal career preference.
              </p>
            )}
          </div>

          <div className="text-2xs text-indigo-300/80 font-mono">
            {sharedSkills.length} Shared Skills
          </div>
        </div>

        {/* Role B Summary Card */}
        <div className="md:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <CompanyLogo name={roleBConfig.company} size="md" />
                <div>
                  <h3 className="text-lg font-black text-slate-900 leading-tight">
                    {roleBConfig.role}
                  </h3>
                  <div className="text-xs text-slate-500">
                    <span>{roleBConfig.company}</span>
                    <span className="mx-1.5">·</span>
                    <span>{roleBConfig.seniority}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="text-3xl font-black text-emerald-600 tracking-tight font-mono">
                  {scoreB}
                  <span className="text-xs text-slate-400 font-sans font-normal ml-0.5">/100</span>
                </div>
                <span className="text-2xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  {evalB.scoreResult.alignmentLevel}
                </span>
              </div>
            </div>

            {/* Score progress bar */}
            <div className="mt-4 w-full bg-slate-100 rounded-full h-2 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${scoreB}%` }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
                className="h-full bg-emerald-500 rounded-full"
              />
            </div>

            {/* Skill Match Breakdown */}
            <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-100 text-center">
              <div className="p-2 bg-emerald-50/60 rounded-xl border border-emerald-100">
                <span className="text-xs font-black text-emerald-700 font-mono">{matchedCountB}</span>
                <span className="block text-2xs font-medium text-emerald-600">Strong</span>
              </div>
              <div className="p-2 bg-amber-50/60 rounded-xl border border-amber-100">
                <span className="text-xs font-black text-amber-700 font-mono">{partialCountB}</span>
                <span className="block text-2xs font-medium text-amber-600">Partial</span>
              </div>
              <div className="p-2 bg-rose-50/60 rounded-xl border border-rose-100">
                <span className="text-xs font-black text-rose-700 font-mono">{missingCountB}</span>
                <span className="block text-2xs font-medium text-rose-600">Gaps</span>
              </div>
            </div>
          </div>

          {/* Application Readiness Pillars */}
          {evalB.applicationReadiness && (
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                Readiness Calibration
              </span>
              <div className="grid grid-cols-2 gap-2 text-2xs">
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Skills:</span>
                  {renderReadinessPill(evalB.applicationReadiness.skills)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Experience:</span>
                  {renderReadinessPill(evalB.applicationReadiness.experience)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Projects:</span>
                  {renderReadinessPill(evalB.applicationReadiness.projects)}
                </div>
                <div className="flex items-center justify-between p-1.5 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Overall:</span>
                  {renderReadinessPill(evalB.applicationReadiness.roleAlignment)}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 4. Skill Venn / Overlap Cards (Shared vs Exclusive Skills) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Skill Requirement Venn & Overlap Analysis</span>
            </h3>
            <p className="text-xs text-slate-500">
              Identify core transferable foundation skills that support both roles vs specialized niche requirements.
            </p>
          </div>

          <div className="flex items-center gap-3 text-2xs text-slate-500 font-mono">
            <span>{sharedSkills.length} Shared</span>
            <span>·</span>
            <span>{onlySkillsA.length} Exclusive to A</span>
            <span>·</span>
            <span>{onlySkillsB.length} Exclusive to B</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Column 1: Exclusive to Role A */}
          <div className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-100 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-900">
                Exclusive to {roleAConfig.role}
              </span>
              <span className="text-2xs font-mono font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
                {onlySkillsA.length} Skills
              </span>
            </div>
            <p className="text-2xs text-slate-500">
              Skills uniquely demanded by {roleAConfig.role} at {roleAConfig.company}.
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {onlySkillsA.length > 0 ? (
                onlySkillsA.map((s) => (
                  <span
                    key={s.skill}
                    className={`text-2xs px-2 py-1 rounded-md font-medium border flex items-center gap-1 ${
                      s.matchA?.status === 'MATCHED'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : s.matchA?.status === 'PARTIAL'
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-rose-50 text-rose-800 border-rose-200'
                    }`}
                  >
                    <span>{s.skill}</span>
                  </span>
                ))
              ) : (
                <span className="text-2xs text-slate-400 italic">No exclusive skills detected</span>
              )}
            </div>
          </div>

          {/* Column 2: Shared Skills (Core Bridge) */}
          <div className="p-4 bg-slate-900 text-white rounded-xl shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Shared Core Transferable Skills</span>
              </span>
              <span className="text-2xs font-mono font-bold text-indigo-300 bg-slate-800 px-2 py-0.5 rounded">
                {sharedSkills.length} Skills
              </span>
            </div>
            <p className="text-2xs text-slate-300">
              Universal foundation requirements shared between both target roles.
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {sharedSkills.map((s) => {
                const bothMatched = s.matchA?.status === 'MATCHED' && s.matchB?.status === 'MATCHED';
                return (
                  <span
                    key={s.skill}
                    className={`text-2xs px-2 py-1 rounded-md font-medium border flex items-center gap-1 ${
                      bothMatched
                        ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
                        : 'bg-slate-800 text-slate-200 border-slate-700'
                    }`}
                  >
                    {bothMatched && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400 shrink-0" />}
                    <span>{s.skill}</span>
                  </span>
                );
              })}
            </div>
          </div>

          {/* Column 3: Exclusive to Role B */}
          <div className="p-4 bg-emerald-50/40 rounded-xl border border-emerald-100 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-900">
                Exclusive to {roleBConfig.role}
              </span>
              <span className="text-2xs font-mono font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                {onlySkillsB.length} Skills
              </span>
            </div>
            <p className="text-2xs text-slate-500">
              Skills uniquely demanded by {roleBConfig.role} at {roleBConfig.company}.
            </p>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {onlySkillsB.length > 0 ? (
                onlySkillsB.map((s) => (
                  <span
                    key={s.skill}
                    className={`text-2xs px-2 py-1 rounded-md font-medium border flex items-center gap-1 ${
                      s.matchB?.status === 'MATCHED'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : s.matchB?.status === 'PARTIAL'
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-rose-50 text-rose-800 border-rose-200'
                    }`}
                  >
                    <span>{s.skill}</span>
                  </span>
                ))
              ) : (
                <span className="text-2xs text-slate-400 italic">No exclusive skills detected</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 5. 10-Dimension Side-by-Side Category Breakdown */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
        <div>
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-indigo-600" />
            <span>Category-by-Category Calibration (Side-by-Side)</span>
          </h3>
          <p className="text-xs text-slate-500">
            Compare earned percentage scores across evaluation categories to see where your resume is more competitive.
          </p>
        </div>

        <div className="space-y-3">
          {categoryKeys.map((cat) => {
            const catA = evalA.scoreResult.categories[cat.key];
            const catB = evalB.scoreResult.categories[cat.key];

            const pctA = catA?.is_applicable && catA.max > 0 ? Math.round((catA.earned / catA.max) * 100) : 0;
            const pctB = catB?.is_applicable && catB.max > 0 ? Math.round((catB.earned / catB.max) * 100) : 0;

            const isAWinner = pctA > pctB;
            const isBWinner = pctB > pctA;

            return (
              <div
                key={cat.key}
                className="p-3 bg-slate-50/70 hover:bg-slate-50 rounded-xl border border-slate-100 transition-colors"
              >
                <div className="flex items-center justify-between text-xs font-semibold text-slate-800 mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-indigo-700 font-bold">{pctA}%</span>
                    {isAWinner && (
                      <span className="text-3xs font-bold uppercase text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                        Winner
                      </span>
                    )}
                  </div>

                  <span className="text-slate-900 font-bold text-center">{cat.label}</span>

                  <div className="flex items-center gap-1.5">
                    {isBWinner && (
                      <span className="text-3xs font-bold uppercase text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                        Winner
                      </span>
                    )}
                    <span className="font-mono text-emerald-700 font-bold">{pctB}%</span>
                  </div>
                </div>

                {/* Dual directional bar comparison */}
                <div className="grid grid-cols-2 gap-2 h-2">
                  <div className="w-full bg-slate-200 rounded-full h-full overflow-hidden flex justify-end">
                    <div
                      className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pctA}%` }}
                    />
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pctB}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 6. Side-by-Side Skill Comparison Matrix Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        {/* Table Header & Controls */}
        <div className="p-6 border-b border-slate-200 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-600" />
                <span>Skill Matrix: Side-by-Side Requirement Comparison</span>
              </h3>
              <p className="text-xs text-slate-500">
                Detailed side-by-side view showing verified resume evidence and match statuses for each role.
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({unifiedSkills.length})
              </button>
              <button
                onClick={() => setStatusFilter('both_matched')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'both_matched'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Both Matched
              </button>
              <button
                onClick={() => setStatusFilter('gap_either')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'gap_either'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Gaps in Either
              </button>
              <button
                onClick={() => setStatusFilter('shared_only')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  statusFilter === 'shared_only'
                    ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Shared Only
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter skills by keyword (e.g., Python, Docker, AWS, React, Agile)..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Table Column Headers */}
        <div className="grid grid-cols-12 bg-slate-50 px-6 py-3 border-b border-slate-200 text-2xs font-bold uppercase tracking-wider text-slate-500">
          <div className="col-span-3 text-indigo-700 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-indigo-600" />
            <span>{roleAConfig.role} Status</span>
          </div>
          <div className="col-span-6 text-slate-700 text-center">
            <span>Competency & Resume Evidence</span>
          </div>
          <div className="col-span-3 text-emerald-700 text-right flex items-center justify-end gap-1.5">
            <span>{roleBConfig.role} Status</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
        </div>

        {/* Table Rows */}
        <div className="divide-y divide-slate-100">
          {filteredSkills.map((item, idx) => {
            const isExpanded = expandedSkill === item.skill;
            return (
              <div
                key={`${item.skill}-${idx}`}
                className="px-6 py-3.5 hover:bg-slate-50/80 transition-colors"
              >
                <div className="grid grid-cols-12 items-center gap-3">
                  {/* Left Column: Role A Status */}
                  <div className="col-span-3">
                    {renderStatusBadge(item.matchA)}
                    {item.matchA && (
                      <span className="block text-3xs text-slate-400 mt-0.5">
                        {item.matchA.isRequired ? 'Required' : 'Preferred'}
                      </span>
                    )}
                  </div>

                  {/* Middle Column: Skill Name & Evidence Toggle */}
                  <div className="col-span-6 text-center">
                    <button
                      onClick={() => setExpandedSkill(isExpanded ? null : item.skill)}
                      className="font-bold text-xs text-slate-900 hover:text-indigo-600 transition-colors cursor-pointer inline-flex items-center gap-1"
                    >
                      <span>{item.skill}</span>
                      <ChevronDown
                        className={`w-3 h-3 text-slate-400 transition-transform ${
                          isExpanded ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    {item.resumeEvidence && (
                      <p className="text-2xs text-slate-500 truncate max-w-md mx-auto mt-0.5">
                        {item.resumeEvidence}
                      </p>
                    )}
                  </div>

                  {/* Right Column: Role B Status */}
                  <div className="col-span-3 text-right">
                    {renderStatusBadge(item.matchB)}
                    {item.matchB && (
                      <span className="block text-3xs text-slate-400 mt-0.5">
                        {item.matchB.isRequired ? 'Required' : 'Preferred'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Expanded Evidence & Context Accordion */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600 space-y-2 overflow-hidden"
                    >
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1.5">
                        <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                          Detected Resume Evidence:
                        </span>
                        <p className="text-xs text-slate-700 italic">
                          "{item.resumeEvidence || 'No direct mention detected on uploaded resume.'}"
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-2xs pt-1">
                        {item.matchA && (
                          <div className="p-2 bg-indigo-50/50 rounded-lg border border-indigo-100">
                            <strong>{roleAConfig.role} Expectation:</strong>{' '}
                            {item.matchA.explanation}
                          </div>
                        )}
                        {item.matchB && (
                          <div className="p-2 bg-emerald-50/50 rounded-lg border border-emerald-100">
                            <strong>{roleBConfig.role} Expectation:</strong>{' '}
                            {item.matchB.explanation}
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}

          {filteredSkills.length === 0 && (
            <div className="p-10 text-center text-xs text-slate-500">
              No skills match the current search or status filter.
            </div>
          )}
        </div>
      </div>

      {/* 7. Strategic Bridge & Pivot Action Plan */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 rounded-2xl p-6 text-white shadow-lg space-y-5">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-400">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Upskilling Strategy & Bridge Analysis</span>
            </div>
            <h3 className="text-lg font-black text-white">
              Which Role Should You Target First?
            </h3>
          </div>

          {onNavigateToRoadmap && (
            <button
              onClick={onNavigateToRoadmap}
              className="px-4 py-2 text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all cursor-pointer shadow-xs flex items-center gap-1.5 shrink-0"
            >
              <span>View 30-60-90 Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {/* Bridge to Role A */}
          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
            <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider">
              To Qualify Faster for {roleAConfig.role}:
            </span>
            <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
              {evalA.skillMatches
                .filter((m) => m.status === 'MISSING')
                .slice(0, 3)
                .map((m, idx) => (
                  <li key={idx}>
                    Focus on <strong>{m.skill}</strong> — mandatory requirement for {roleAConfig.role}.
                  </li>
                ))}
              {evalA.skillMatches.filter((m) => m.status === 'MISSING').length === 0 && (
                <li className="text-emerald-400">
                  All critical core skills for {roleAConfig.role} are covered on your resume!
                </li>
              )}
            </ul>
          </div>

          {/* Bridge to Role B */}
          <div className="p-4 bg-slate-800/80 rounded-xl border border-slate-700 space-y-2">
            <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
              To Pivot Toward {roleBConfig.role}:
            </span>
            <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
              {evalB.skillMatches
                .filter((m) => m.status === 'MISSING')
                .slice(0, 3)
                .map((m, idx) => (
                  <li key={idx}>
                    Acquire competency in <strong>{m.skill}</strong> to close the primary gap for {roleBConfig.role}.
                  </li>
                ))}
              {evalB.skillMatches.filter((m) => m.status === 'MISSING').length === 0 && (
                <li className="text-emerald-400">
                  All critical core skills for {roleBConfig.role} are covered on your resume!
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
