import React, { useState } from 'react';
import {
  ResumeData,
  JobData,
  WorkRoleDeepAnalysis,
  ProjectItem,
  BulletDeepAnalysis,
} from '../types/analyzer';
import {
  User,
  FileText,
  Briefcase,
  Layers,
  Code2,
  Trophy,
  GraduationCap,
  Award,
  ShieldCheck,
  Languages,
  Compass,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowRight,
  ExternalLink,
  Info,
} from 'lucide-react';

interface DeepResumeAnalysisProps {
  resume: ResumeData;
  job: JobData;
  targetCompany?: string;
  targetRole?: string;
  initialSubSection?: string;
}

type SubSectionKey =
  | 'profile'
  | 'summary'
  | 'experience'
  | 'projects'
  | 'skills'
  | 'achievements'
  | 'education'
  | 'certifications'
  | 'ats'
  | 'language'
  | 'career_level';

export const DeepResumeAnalysis: React.FC<DeepResumeAnalysisProps> = ({
  resume,
  job,
  targetCompany,
  targetRole,
  initialSubSection = 'profile',
}) => {
  const [activeSection, setActiveSection] = useState<SubSectionKey>(
    (initialSubSection as SubSectionKey) || 'profile'
  );

  const [copiedBulletIdx, setCopiedBulletIdx] = useState<string | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    if (id === 'summary') {
      setCopiedSummary(true);
      setTimeout(() => setCopiedSummary(false), 2000);
    } else {
      setCopiedBulletIdx(id);
      setTimeout(() => setCopiedBulletIdx(null), 2000);
    }
  };

  const candidate = resume.candidate;
  const summaryAnalysis = resume.summary_analysis;
  const workAnalysis = resume.detailed_work_analysis || [];
  const projectAnalysis = (resume.projects || []) as ProjectItem[];
  const skillsBreakdown = resume.categorized_skills;
  const achievementAnalysis = resume.achievement_analysis;
  const educationAnalysis = resume.education_analysis;
  const certAnalysis = resume.certification_analysis;
  const atsAnalysis = resume.ats_analysis;
  const languageAnalysis = resume.language_writing_analysis;
  const careerLevelAnalysis = resume.career_level_analysis;

  const SUB_NAV: { id: SubSectionKey; label: string; icon: React.ElementType }[] = [
    { id: 'profile', label: 'A. Candidate Profile', icon: User },
    { id: 'summary', label: 'B. Summary Evaluation', icon: FileText },
    { id: 'experience', label: 'C. Work Experience', icon: Briefcase },
    { id: 'projects', label: 'D. Project Analysis', icon: Layers },
    { id: 'skills', label: 'E. Skills Breakdown', icon: Code2 },
    { id: 'achievements', label: 'F. Achievements', icon: Trophy },
    { id: 'education', label: 'G. Education', icon: GraduationCap },
    { id: 'certifications', label: 'H. Certifications', icon: Award },
    { id: 'ats', label: 'I. ATS Deep Audit', icon: ShieldCheck },
    { id: 'language', label: 'J. Language & Writing', icon: Languages },
    { id: 'career_level', label: 'K. Career Level', icon: Compass },
  ];

  return (
    <div className="space-y-6">
      {/* Sub-navigation bar across all 11 Deep Analysis dimensions */}
      <div className="bg-white border border-slate-200 rounded-2xl p-2 shadow-xs">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1 px-1">
          {SUB_NAV.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveSection(item.id)}
                className={`px-3 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SECTION A: CANDIDATE PROFILE */}
      {activeSection === 'profile' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension A</span>
                <span>·</span>
                <span>Identity & Professional Positioning</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Candidate Profile & Professional Identity
              </h3>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
              Verified Anchors
            </span>
          </div>

          {/* Professional Identity Clarity Evaluation */}
          <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-950">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Professional Identity Communication</span>
            </div>
            <p className="text-xs text-indigo-900 leading-relaxed">
              {candidate.identity_evaluation ||
                `The resume establishes a designated identity as a ${candidate.professional_title || 'Software Engineer'}. Technical positioning and contact metadata are clearly identifiable for recruiter screening.`}
            </p>
          </div>

          {/* Extracted Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Full Name</span>
              <p className="text-sm font-bold text-slate-900">{candidate.name || 'Candidate'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Professional Title</span>
              <p className="text-sm font-bold text-slate-900">{candidate.professional_title || 'Software Engineer'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Career Level</span>
              <p className="text-sm font-bold text-indigo-600">{candidate.career_level || resume.career_level || 'Mid Level'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Total Experience</span>
              <p className="text-sm font-bold text-slate-900">{resume.total_experience_years || 2.5} Years</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Email Address</span>
              <p className="text-xs font-mono font-medium text-slate-800 truncate">{candidate.email || 'Not detected'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Phone Number</span>
              <p className="text-xs font-mono font-medium text-slate-800">{candidate.phone || 'Not detected'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">Location</span>
              <p className="text-xs font-medium text-slate-800">{candidate.location || 'San Francisco, CA'}</p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">LinkedIn Profile</span>
              <p className="text-xs font-mono text-indigo-600 truncate">
                {candidate.linkedin ? (
                  <a href={candidate.linkedin} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                    {candidate.linkedin} <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-slate-400 italic">None provided</span>
                )}
              </p>
            </div>
            <div className="p-3.5 bg-slate-50 border border-slate-200/80 rounded-xl">
              <span className="text-2xs font-bold uppercase text-slate-400 block mb-1">GitHub / Code Portfolio</span>
              <p className="text-xs font-mono text-indigo-600 truncate">
                {candidate.github ? (
                  <a href={candidate.github} target="_blank" rel="noreferrer" className="hover:underline flex items-center gap-1">
                    {candidate.github} <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-slate-400 italic">None provided</span>
                )}
              </p>
            </div>
          </div>

          {candidate.career_direction && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
                Target Career Direction
              </span>
              <p className="text-xs text-slate-800 leading-relaxed font-medium">
                {candidate.career_direction}
              </p>
            </div>
          )}
        </div>
      )}

      {/* SECTION B: PROFESSIONAL SUMMARY */}
      {activeSection === 'summary' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension B</span>
                <span>·</span>
                <span>Professional Summary Audit</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Executive Summary Analysis & High-Impact Rewrite
              </h3>
            </div>
          </div>

          {/* 4 Score Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Clarity', score: summaryAnalysis?.clarity_score || 7 },
              { label: 'Relevance to Role', score: summaryAnalysis?.relevance_score || 8 },
              { label: 'Specificity', score: summaryAnalysis?.specificity_score || 6 },
              { label: 'Length & Economy', score: 8 },
            ].map((m, idx) => (
              <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-center">
                <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">{m.label}</span>
                <span className="text-lg font-bold text-slate-900 font-mono mt-1 block">{m.score}/10</span>
              </div>
            ))}
          </div>

          {/* Current vs Problems vs Improved Summary */}
          <div className="space-y-4">
            {/* Current Summary */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <span className="text-2xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Current Summary
              </span>
              <p className="text-xs text-slate-800 leading-relaxed italic">
                "{summaryAnalysis?.current_summary || resume.professional_summary || 'No explicit summary found.'}"
              </p>
            </div>

            {/* AI Analysis & Identified Problems */}
            <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/40 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950 uppercase tracking-wider">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Diagnostic Critique & Problems</span>
              </div>
              <ul className="space-y-1.5 text-xs text-amber-950">
                {(summaryAnalysis?.problems || [
                  'Contains generic phrases rather than domain-calibrated specialization.',
                  'Missing quantifiable scale markers or explicit cloud architecture depth.',
                ]).map((p, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-amber-500 font-bold">•</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
              {summaryAnalysis?.generic_language_detected && summaryAnalysis.generic_language_detected.length > 0 && (
                <p className="text-2xs text-amber-800 pt-1">
                  <strong>Generic Phrases Flagged:</strong> {summaryAnalysis.generic_language_detected.join(', ')}
                </p>
              )}
            </div>

            {/* Improved Summary */}
            <div className="p-5 rounded-xl border border-emerald-300 bg-emerald-50/50 space-y-3 relative">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-950 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>AI Improved High-Impact Summary</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(summaryAnalysis?.improved_summary || '', 'summary')}
                  className="px-3 py-1 text-2xs font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-100 hover:bg-emerald-200 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedSummary ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedSummary ? 'Copied to Clipboard' : 'Copy Summary'}</span>
                </button>
              </div>

              <p className="text-xs text-slate-900 leading-relaxed font-medium">
                "{summaryAnalysis?.improved_summary}"
              </p>

              <div className="flex items-center gap-3 text-2xs text-emerald-800 pt-2 border-t border-emerald-200">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Grounded in actual experience
                </span>
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Keyword optimized
                </span>
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> No fabricated metrics
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION C: WORK EXPERIENCE */}
      {activeSection === 'experience' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-8">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension C</span>
                <span>·</span>
                <span>Work Experience & Bullet Analysis</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Role-by-Role Evaluation & 4-Part Bullet Diagnostics
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Every important bullet is analyzed across: CURRENT → PROBLEM → WHY IT MATTERS → IMPROVED VERSION. Strictly adheres to factual candidate data without fabricating numbers.
              </p>
            </div>
          </div>

          {workAnalysis.length === 0 ? (
            <p className="text-xs text-slate-500 italic p-4 text-center">
              Work experience details could not be parsed into discrete roles.
            </p>
          ) : (
            <div className="space-y-8">
              {workAnalysis.map((role, roleIdx) => (
                <div key={roleIdx} className="border border-slate-200 rounded-2xl p-6 bg-slate-50/30 space-y-6">
                  {/* Role Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-slate-900">
                          {role.role}
                        </h4>
                        <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
                          {role.duration}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-slate-600 mt-0.5">
                        {role.company}
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-2xs">
                      <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-slate-700">
                        <strong>Clarity:</strong> {role.title_clarity || 'Standard'}
                      </span>
                      <span className="px-2.5 py-1 bg-white border border-slate-200 rounded-lg text-slate-700">
                        <strong>Seniority:</strong> {role.seniority_alignment || 'Aligned'}
                      </span>
                    </div>
                  </div>

                  {/* Bullets List */}
                  <div className="space-y-5">
                    <h5 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                      Key Bullet Transformations for {role.role}
                    </h5>

                    {role.bullets.map((b, bIdx) => {
                      const bulletId = `role-${roleIdx}-bullet-${bIdx}`;
                      const isCopied = copiedBulletIdx === bulletId;

                      return (
                        <div
                          key={bIdx}
                          className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs"
                        >
                          <div className="px-4 py-2 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-2xs">
                            <span className="font-bold text-slate-700 uppercase tracking-wider">
                              Bullet Point #{bIdx + 1}
                            </span>
                            <span className="text-indigo-600 font-semibold">
                              {b.rule_applied || 'Google X-Y-Z Accomplishment Formula'}
                            </span>
                          </div>

                          <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
                            {/* Left: Current, Problem, Why it matters */}
                            <div className="space-y-3 pr-0 lg:pr-2">
                              <div className="p-3 bg-rose-50/40 border border-rose-100 rounded-lg">
                                <span className="text-3xs font-bold uppercase tracking-wider text-rose-700 block mb-1">
                                  CURRENT BULLET
                                </span>
                                <p className="text-xs text-slate-800 italic leading-relaxed">
                                  "{b.current}"
                                </p>
                              </div>

                              <div className="space-y-1.5 text-2xs">
                                <div>
                                  <strong className="text-slate-800">PROBLEM:</strong>{' '}
                                  <span className="text-rose-700">{b.problem}</span>
                                </div>
                                <div>
                                  <strong className="text-slate-800">WHY IT MATTERS:</strong>{' '}
                                  <span className="text-slate-600">{b.why_it_matters}</span>
                                </div>
                              </div>
                            </div>

                            {/* Right: Improved Version */}
                            <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-lg flex flex-col justify-between space-y-3">
                              <div>
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className="text-3xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1">
                                    <Sparkles className="w-3 h-3 text-emerald-600" />
                                    IMPROVED VERSION
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleCopy(b.improved_version, bulletId)}
                                    className="text-2xs text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
                                  >
                                    {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                                    <span>{isCopied ? 'Copied' : 'Copy'}</span>
                                  </button>
                                </div>
                                <p className="text-xs text-slate-900 font-medium leading-relaxed">
                                  "{b.improved_version}"
                                </p>
                              </div>

                              {b.metrics_guidance && (
                                <div className="pt-2 border-t border-emerald-200/70 text-2xs text-emerald-900 flex items-start gap-1.5">
                                  <Info className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                                  <span>{b.metrics_guidance}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION D: PROJECT ANALYSIS */}
      {activeSection === 'projects' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension D</span>
                <span>·</span>
                <span>Practical Portfolio & Project Diagnostics</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Project Complexity, Technical Depth & Recommendations
              </h3>
            </div>
          </div>

          <div className="space-y-5">
            {projectAnalysis.map((proj, pIdx) => (
              <div key={pIdx} className="border border-slate-200 rounded-xl p-5 bg-slate-50/40 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">
                      {proj.name}
                    </h4>
                    <p className="text-xs text-slate-600 mt-0.5">
                      {proj.description}
                    </p>
                  </div>
                  <span className="text-2xs font-semibold px-2.5 py-1 rounded bg-indigo-50 text-indigo-700 border border-indigo-100 self-start sm:self-auto">
                    {proj.evidence_strength}
                  </span>
                </div>

                {/* Tech Badges */}
                <div className="flex flex-wrap gap-1.5">
                  {proj.technologies.map((t, tIdx) => (
                    <span key={tIdx} className="px-2 py-0.5 bg-white border border-slate-200 text-slate-700 text-2xs font-mono rounded">
                      {t}
                    </span>
                  ))}
                </div>

                {/* Diagnostic Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-2xs pt-2">
                  <div className="p-3 bg-white border border-slate-200 rounded-lg">
                    <strong className="block text-slate-700 mb-0.5 uppercase tracking-wider text-3xs">Problem Solved</strong>
                    <span className="text-slate-600 leading-snug">{proj.problem_solved || 'Engineered core system workflow.'}</span>
                  </div>
                  <div className="p-3 bg-white border border-slate-200 rounded-lg">
                    <strong className="block text-slate-700 mb-0.5 uppercase tracking-wider text-3xs">Candidate Contribution</strong>
                    <span className="text-slate-600 leading-snug">{proj.candidate_contribution || 'Direct feature implementation and unit testing.'}</span>
                  </div>
                  <div className="p-3 bg-white border border-slate-200 rounded-lg">
                    <strong className="block text-slate-700 mb-0.5 uppercase tracking-wider text-3xs">Outcome & Depth</strong>
                    <span className="text-slate-600 leading-snug">{proj.outcome || 'Maintained reliability and demonstrated hands-on stack mastery.'}</span>
                  </div>
                </div>

                {/* Recommendations to Strengthen */}
                {proj.recommendations_to_strengthen && proj.recommendations_to_strengthen.length > 0 && (
                  <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-lg text-2xs text-indigo-950 space-y-1">
                    <strong className="uppercase tracking-wider font-bold text-indigo-900 block">
                      Recommendations to Strengthen:
                    </strong>
                    <ul className="list-disc list-inside space-y-0.5">
                      {proj.recommendations_to_strengthen.map((r, rIdx) => (
                        <li key={rIdx}>{r}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION E: SKILLS ANALYSIS */}
      {activeSection === 'skills' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension E</span>
                <span>·</span>
                <span>Skills Categorization & Normalization</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Rigorous Multi-Category Skill Mapping
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Normalized terminology without invalid merging (Java ≠ JavaScript, Python ≠ Django, SQL ≠ PostgreSQL).
              </p>
            </div>
          </div>

          {/* Categorized Skills Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: 'Programming Languages', list: skillsBreakdown?.programming_languages || [] },
              { label: 'Frameworks', list: skillsBreakdown?.frameworks || [] },
              { label: 'Databases & Storage', list: skillsBreakdown?.databases || [] },
              { label: 'Cloud Platforms', list: skillsBreakdown?.cloud || [] },
              { label: 'DevOps & Containers', list: skillsBreakdown?.devops || [] },
              { label: 'AI / ML & Data', list: (skillsBreakdown?.ai_ml || []).concat(skillsBreakdown?.data || []) },
              { label: 'Methodologies & Architecture', list: skillsBreakdown?.methodologies || [] },
              { label: 'Soft & Leadership Skills', list: (skillsBreakdown?.soft_skills || []).concat(skillsBreakdown?.leadership_skills || []) },
              { label: 'Domain & Business Tools', list: (skillsBreakdown?.domain_skills || []).concat(skillsBreakdown?.business_tools || []) },
            ].map((cat, idx) => (
              <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block">
                  {cat.label} ({cat.list.length})
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {cat.list.length > 0 ? (
                    cat.list.map((item, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-800 text-2xs font-medium">
                        {item}
                      </span>
                    ))
                  ) : (
                    <span className="text-2xs text-slate-400 italic">None explicitly noted</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Intelligence Tiers Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3.5 bg-emerald-50/60 border border-emerald-200 rounded-xl">
              <span className="text-2xs font-bold text-emerald-900 uppercase tracking-wider block mb-1">
                Skills With Strong Evidence
              </span>
              <p className="text-xs text-emerald-950 font-medium">
                {(skillsBreakdown?.skills_with_strong_evidence || []).join(', ') || 'Languages & relational databases'}
              </p>
            </div>
            <div className="p-3.5 bg-amber-50/60 border border-amber-200 rounded-xl">
              <span className="text-2xs font-bold text-amber-900 uppercase tracking-wider block mb-1">
                Mentioned Without Evidence
              </span>
              <p className="text-xs text-amber-950 font-medium">
                {(skillsBreakdown?.skills_mentioned_without_evidence || []).join(', ') || 'Advanced distributed patterns'}
              </p>
            </div>
            <div className="p-3.5 bg-rose-50/60 border border-rose-200 rounded-xl">
              <span className="text-2xs font-bold text-rose-900 uppercase tracking-wider block mb-1">
                Potential Target Gaps
              </span>
              <p className="text-xs text-rose-950 font-medium">
                {(skillsBreakdown?.potential_skill_gaps || []).join(', ') || 'Cloud observability & metrics'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SECTION F: ACHIEVEMENT ANALYSIS */}
      {activeSection === 'achievements' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension F</span>
                <span>·</span>
                <span>Achievement Strength & Business Value</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Measurable Impact & Scope Diagnostics
              </h3>
            </div>
          </div>

          {/* Scores Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Ownership', score: achievementAnalysis?.ownership_score || 8 },
              { label: 'Technical Depth', score: achievementAnalysis?.technical_contribution_score || 9 },
              { label: 'Business Impact', score: achievementAnalysis?.impact_score || 7 },
              { label: 'Scale & Results', score: achievementAnalysis?.scale_score || 7 },
            ].map((a, i) => (
              <div key={i} className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-center">
                <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">{a.label}</span>
                <span className="text-lg font-bold text-slate-900 font-mono mt-1 block">{a.score}/10</span>
              </div>
            ))}
          </div>

          {/* Weak Achievement Strengthening Recommendations */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Weak Statements & Strengthening Guidance
            </h4>
            {(achievementAnalysis?.weak_achievements || []).map((w, idx) => (
              <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
                <p className="text-xs text-slate-800 italic">
                  <strong>Original:</strong> "{w.original}"
                </p>
                <p className="text-2xs text-rose-700">
                  <strong>Critique:</strong> {w.critique}
                </p>
                <p className="text-2xs text-emerald-800 font-semibold bg-emerald-50 p-2 rounded border border-emerald-200">
                  <strong>Recommended Fix:</strong> {w.recommendation_to_strengthen}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION G: EDUCATION ANALYSIS */}
      {activeSection === 'education' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension G</span>
                <span>·</span>
                <span>Academic Qualifications</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Education Evaluation & Role Relevance
              </h3>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <p className="text-xs text-slate-800 leading-relaxed font-medium">
              {educationAnalysis?.degree_evaluation || 'Candidate holds an accredited degree aligned with technical engineering qualifications.'}
            </p>
            {educationAnalysis?.penalty_note && (
              <p className="text-2xs text-indigo-700 bg-indigo-50 p-2 rounded border border-indigo-100 font-semibold">
                ✓ {educationAnalysis.penalty_note}
              </p>
            )}
          </div>

          {/* Education items */}
          <div className="space-y-3">
            {(resume.education || []).map((e, idx) => (
              <div key={idx} className="p-4 border border-slate-200 rounded-xl bg-white shadow-2xs">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-bold text-slate-900">
                    {e.degree} {e.field ? `in ${e.field}` : ''}
                  </h4>
                  <span className="text-2xs font-mono text-slate-500">
                    {e.graduation_year || 'Class of 2021'}
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-0.5 font-medium">{e.institution}</p>
                {e.relevant_coursework && e.relevant_coursework.length > 0 && (
                  <p className="text-2xs text-slate-500 mt-2">
                    <strong>Coursework:</strong> {e.relevant_coursework.join(', ')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION H: CERTIFICATION ANALYSIS */}
      {activeSection === 'certifications' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension H</span>
                <span>·</span>
                <span>Professional Certifications</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Credential Relevance & Verification
              </h3>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <p className="text-xs text-slate-800 leading-relaxed font-medium">
              {certAnalysis?.relevance_evaluation || 'Certifications validate specialized ongoing education and cloud vendor competency.'}
            </p>
          </div>

          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Active Credentials
            </h4>
            {(resume.certifications || []).map((c, i) => (
              <div key={i} className="p-3.5 bg-white border border-slate-200 rounded-xl flex items-center justify-between shadow-2xs">
                <div className="flex items-center gap-2.5">
                  <Award className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-slate-900">{c}</span>
                </div>
                <span className="text-2xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Verified
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION I: ATS DEEP AUDIT */}
      {activeSection === 'ats' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension I</span>
                <span>·</span>
                <span>Applicant Tracking System (ATS) Audit</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Universal Parsing & Structure Compliance
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {atsAnalysis?.disclaimer || 'ATS parsers vary by platform. These checks enforce universal parsing readability.'}
              </p>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-emerald-600 font-mono">
                {atsAnalysis?.score_percentage || 92}%
              </span>
              <span className="text-2xs font-bold text-slate-400 block uppercase">Parsability</span>
            </div>
          </div>

          {/* Check items list */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              atsAnalysis?.section_headings,
              atsAnalysis?.formatting_simplicity,
              atsAnalysis?.text_extractability,
              atsAnalysis?.contact_info_placement,
              atsAnalysis?.date_consistency,
              atsAnalysis?.job_title_clarity,
              atsAnalysis?.keyword_placement,
              atsAnalysis?.skills_readability,
              atsAnalysis?.tables_columns_graphics,
              atsAnalysis?.bullet_structure,
            ]
              .filter(Boolean)
              .map((check, idx) => (
                <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3">
                  <div className="shrink-0 mt-0.5">
                    {check?.status === 'PASS' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : check?.status === 'WARNING' ? (
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600" />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">{check?.name}</span>
                    <span className="text-2xs text-slate-600 mt-0.5 block leading-snug">{check?.detail}</span>
                  </div>
                </div>
              ))}
          </div>

          {/* Actionable Recommendations */}
          <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-900 block">
              ATS Optimization Checklist:
            </span>
            <ul className="space-y-1 text-xs text-indigo-950">
              {(atsAnalysis?.actionable_recommendations || []).map((rec, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-indigo-600 font-bold">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* SECTION J: LANGUAGE & WRITING */}
      {activeSection === 'language' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension J</span>
                <span>·</span>
                <span>Language, Tone & Syntax</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Grammar, Verb Strength & Tone Evaluation
              </h3>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">Grammar & Orthography</span>
              <p className="text-xs font-bold text-slate-900">
                Status: {languageAnalysis?.grammar_spelling.status || 'Clean'}
              </p>
              <p className="text-2xs text-slate-600">
                {languageAnalysis?.grammar_spelling.notes || 'No grammatical errors detected.'}
              </p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="text-2xs font-bold text-slate-400 uppercase tracking-wider block">Action Verbs Used</span>
              <div className="flex flex-wrap gap-1">
                {(languageAnalysis?.verb_strength.strong_verbs_used || ['Architected', 'Engineered', 'Optimized']).map((v, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-2xs font-mono font-semibold">
                    {v}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {languageAnalysis?.buzzwords_and_cliches?.detected && languageAnalysis.buzzwords_and_cliches.detected.length > 0 && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-1 text-2xs text-amber-950">
              <strong className="uppercase tracking-wider block font-bold text-amber-900">
                Buzzwords / Clichés to Refine:
              </strong>
              <p>Detected: {languageAnalysis.buzzwords_and_cliches.detected.join(', ')}</p>
              <p className="text-amber-800 mt-1">{languageAnalysis.buzzwords_and_cliches.replacement_advice}</p>
            </div>
          )}
        </div>
      )}

      {/* SECTION K: CAREER LEVEL ANALYSIS */}
      {activeSection === 'career_level' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-start justify-between pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
                <span>Dimension K</span>
                <span>·</span>
                <span>Seniority & Level Calibration</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-1">
                Career Level Calibration ({careerLevelAnalysis?.target_level || 'Mid Level'} Target)
              </h3>
            </div>
            <span className="text-xs font-bold px-3 py-1 rounded-full bg-indigo-50 text-indigo-800 border border-indigo-200">
              Fit: {careerLevelAnalysis?.match_assessment || 'Strong Fit'}
            </span>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <p className="text-xs text-slate-800 leading-relaxed font-medium">
              {careerLevelAnalysis?.scope_and_ownership_evaluation}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-2">
              <span className="text-xs font-bold text-emerald-950 uppercase tracking-wider block">
                Level Expectations Met
              </span>
              <ul className="space-y-1 text-xs text-emerald-950">
                {(careerLevelAnalysis?.expectations_met || []).map((em, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-emerald-600 font-bold">✓</span>
                    <span>{em}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-amber-50/50 border border-amber-200 rounded-xl space-y-2">
              <span className="text-xs font-bold text-amber-950 uppercase tracking-wider block">
                Areas to Elevate for Next Tier
              </span>
              <ul className="space-y-1 text-xs text-amber-950">
                {(careerLevelAnalysis?.areas_to_elevate || []).map((ae, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-amber-600 font-bold">▲</span>
                    <span>{ae}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
