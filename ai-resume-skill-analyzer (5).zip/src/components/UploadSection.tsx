import React, { useState, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { dropdownVariants } from '../utils/motion';
import {
  UploadCloud,
  FileText,
  Trash2,
  Edit3,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Search,
  Building2,
  Briefcase,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Info,
  Clock,
  Layers,
  Plus,
  Database,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { TOP_COMPANIES, OTHER_COMPANY, CompanyOption } from '../data/companies';
import {
  JOB_CATEGORIES,
  POPULAR_ROLES,
  SENIORITY_LEVELS,
} from '../data/jobRoles';
import { CompanyLogo } from './CompanyLogo';
import { SamplePair, SAMPLE_DATASETS } from '../../server/sampleData';
import {
  extractDocumentClientSide,
  DocumentExtractionError,
  ExtractionProgress,
} from '../utils/documentExtractor';

export type UploadStatus =
  | 'IDLE'
  | 'FILE_SELECTED'
  | 'READING'
  | 'EXTRACTING'
  | 'VALIDATING'
  | 'READY'
  | 'ERROR';

interface UploadSectionProps {
  resumeText: string;
  resumeFileName: string;
  resumeFileSize?: number;
  resumePageCount?: number;
  resumeFileType?: string;
  jobDescription: string;
  jobTitle: string;
  company: string;
  seniorityLevel: string;
  targetGoal: string;
  onResumeChange: (text: string, filename: string, size?: number, pages?: number, fileType?: string) => void;
  onJobDescChange: (text: string) => void;
  onJobTitleChange: (val: string) => void;
  onCompanyChange: (val: string) => void;
  onSeniorityChange: (val: string) => void;
  onTargetGoalChange: (val: string) => void;
  onStartAnalysis: () => void;
  isAnalyzing: boolean;
  onSelectSample: (sample: SamplePair) => void;
}

export const UploadSection: React.FC<UploadSectionProps> = ({
  resumeText,
  resumeFileName,
  resumeFileSize,
  resumePageCount,
  resumeFileType,
  jobDescription,
  jobTitle,
  company,
  seniorityLevel,
  targetGoal,
  onResumeChange,
  onJobDescChange,
  onJobTitleChange,
  onCompanyChange,
  onSeniorityChange,
  onTargetGoalChange,
  onStartAnalysis,
  isAnalyzing,
  onSelectSample,
}) => {
  const { currentUser, credentials } = useAuth();
  // Drag & drop and upload status states
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<UploadStatus>(
    resumeText.trim().length >= 20 ? 'READY' : 'IDLE'
  );
  const [selectedFileName, setSelectedFileName] = useState<string>(resumeFileName || '');
  const [progressInfo, setProgressInfo] = useState<ExtractionProgress | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [showRawEditor, setShowRawEditor] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Search state for Company
  const [companySearch, setCompanySearch] = useState('');
  const [isCompanyDropdownOpen, setIsCompanyDropdownOpen] = useState(false);
  const [isCustomCompany, setIsCustomCompany] = useState(false);

  // Search state for Job Role
  const [roleSearch, setRoleSearch] = useState('');
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [isCustomRole, setIsCustomRole] = useState(false);

  // Optional Job Description accordion
  const [isJdExpanded, setIsJdExpanded] = useState(Boolean(jobDescription.trim().length > 0));

  const isProcessing =
    uploadStatus === 'FILE_SELECTED' ||
    uploadStatus === 'READING' ||
    uploadStatus === 'EXTRACTING' ||
    uploadStatus === 'VALIDATING';

  const hasResume = resumeText.trim().length >= 20 && !isProcessing && uploadStatus !== 'ERROR';
  const hasCompany = company.trim().length > 0;
  const hasRole = jobTitle.trim().length > 0;
  const canAnalyze = hasResume && hasCompany && hasRole && !isAnalyzing;

  // Filter companies based on search input
  const filteredCompanies = useMemo(() => {
    if (!companySearch.trim()) return TOP_COMPANIES;
    const q = companySearch.toLowerCase();
    return TOP_COMPANIES.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.industry.toLowerCase().includes(q) ||
        (c.ticker && c.ticker.toLowerCase().includes(q))
    );
  }, [companySearch]);

  // Filter role categories based on search input
  const filteredCategories = useMemo(() => {
    if (!roleSearch.trim()) return JOB_CATEGORIES;
    const q = roleSearch.toLowerCase();
    return JOB_CATEGORIES.map((cat) => ({
      ...cat,
      roles: cat.roles.filter((r) => r.toLowerCase().includes(q)),
    })).filter((cat) => cat.roles.length > 0);
  }, [roleSearch]);

  // Handle file upload with client-side document extraction
  const handleFileUpload = async (file: File) => {
    setUploadError(null);
    setSelectedFileName(file.name);
    setUploadStatus('FILE_SELECTED');

    try {
      const doc = await extractDocumentClientSide(file, (p) => {
        setUploadStatus(p.stage);
        setProgressInfo(p);
      });

      setUploadStatus('READY');
      setProgressInfo(null);
      onResumeChange(doc.text, file.name, file.size, doc.pages, doc.fileType);
      setShowRawEditor(false);
    } catch (err: any) {
      console.error('File extraction error:', err);
      setUploadStatus('ERROR');
      setProgressInfo(null);
      const msg = err?.message || "We couldn't process this resume. Please try again or upload a DOCX file.";
      setUploadError(msg);
    }
  };

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const onDragLeave = () => {
    setIsDragging(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const clearResume = () => {
    onResumeChange('', '', undefined);
    setSelectedFileName('');
    setUploadStatus('IDLE');
    setProgressInfo(null);
    setShowRawEditor(false);
    setUploadError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const onPresetClick = (sample: SamplePair) => {
    onSelectSample(sample);
    if (sample.company) onCompanyChange(sample.company);
    setIsCustomCompany(false);
    setIsCustomRole(false);
    setSelectedFileName(sample.resumeFileName);
    setUploadStatus('READY');
    setUploadError(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      {/* 1-Click Quick Presets */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 rounded-2xl p-5 text-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-200">
              Quick Test Presets
            </h4>
          </div>
          <p className="text-xs text-slate-300 mt-1">
            Load a complete verified candidate profile and target company in one click:
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_DATASETS.map((sample) => (
            <button
              key={sample.id}
              type="button"
              onClick={() => onPresetClick(sample)}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 text-white border border-white/10 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>{(sample.label || sample.name).split('—')[0].trim()}</span>
              <span className="text-2xs opacity-75 font-normal">
                ({sample.company || 'Tech'})
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Flow Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-8">
        {/* ================= STEP 1: UPLOAD RESUME ================= */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
                1
              </span>
              <h3 className="text-base font-bold text-slate-900">
                Upload Your Resume
              </h3>
            </div>
            {hasResume && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Resume uploaded ✓
              </span>
            )}
          </div>

          <p className="text-xs text-slate-500 mb-4">
            Upload your resume in PDF, Word (.docx), or plain text format. We analyze your actual background without modifying your details.
          </p>

          {isProcessing ? (
            /* ================= PROCESSING STATE (FILE_SELECTED, READING, EXTRACTING, VALIDATING) ================= */
            <div className="border-2 border-indigo-200 bg-indigo-50/50 rounded-2xl p-8 text-center transition-all shadow-2xs">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto mb-3 border border-indigo-200">
                <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-indigo-200 text-xs font-semibold text-indigo-900 mb-2 font-mono shadow-2xs">
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                <span>{selectedFileName || resumeFileName || 'Resume file'}</span>
              </div>
              <p className="text-base font-bold text-slate-800">
                {uploadStatus === 'FILE_SELECTED' && `Selected: ${selectedFileName}`}
                {uploadStatus === 'READING' && 'Reading your resume...'}
                {uploadStatus === 'EXTRACTING' && (
                  progressInfo?.totalPages && progressInfo.totalPages > 1
                    ? `Extracting resume content... (Page ${progressInfo.currentPage || 1} of ${progressInfo.totalPages})`
                    : 'Extracting resume content...'
                )}
                {uploadStatus === 'VALIDATING' && 'Checking extracted content...'}
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Parsing document structure, sections, bullets, and text layout
              </p>
              <div className="w-48 h-1.5 bg-indigo-200/60 rounded-full mx-auto mt-4 overflow-hidden">
                <div className="w-full h-full bg-indigo-600 rounded-full animate-pulse" />
              </div>
            </div>
          ) : hasResume ? (
            /* ================= READY STATE ================= */
            <div className="rounded-xl border border-emerald-300 bg-emerald-50/50 p-4 transition-all shadow-2xs">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 font-mono">
                        ✓ {resumeFileName || selectedFileName || 'Candidate_Resume.pdf'}
                      </span>
                      <span className="text-2xs font-semibold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-200">
                        Resume ready for analysis
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 font-medium mt-0.5">
                      {resumeFileType || (resumeFileName?.toLowerCase().endsWith('.docx') ? 'DOCX' : 'PDF')} • {resumePageCount ? `${resumePageCount} page${resumePageCount > 1 ? 's' : ''} • ` : ''}{resumeFileSize ? `${(resumeFileSize / 1024).toFixed(0)} KB` : `${(resumeText.length / 1024).toFixed(0)} KB`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <UploadCloud className="w-3.5 h-3.5 text-slate-500" />
                    <span>Replace file</span>
                  </button>
                  <button
                    type="button"
                    onClick={clearResume}
                    className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-red-200 bg-white hover:bg-red-50 text-red-600 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Remove file"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove file</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowRawEditor(!showRawEditor)}
                    className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{showRawEditor ? 'Hide' : 'Inspect'}</span>
                  </button>
                </div>
              </div>

              {showRawEditor && (
                <div className="mt-4 pt-4 border-t border-emerald-200/60">
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Extracted Resume Content (editable):
                  </label>
                  <textarea
                    rows={8}
                    value={resumeText}
                    onChange={(e) => {
                      onResumeChange(e.target.value, resumeFileName || selectedFileName || 'Candidate_Resume.txt', e.target.value.length);
                      if (e.target.value.trim().length >= 20) {
                        setUploadStatus('READY');
                      }
                    }}
                    className="w-full text-xs font-mono p-3 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800 leading-relaxed"
                  />
                </div>
              )}
            </div>
          ) : uploadStatus === 'ERROR' ? (
            /* ================= ERROR STATE ================= */
            <div className="border-2 border-red-200 bg-red-50/60 rounded-2xl p-6 text-center transition-all">
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
              <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3 border border-red-200 shadow-2xs">
                <AlertCircle className="w-6 h-6" />
              </div>
              {selectedFileName && (
                <p className="text-xs font-mono text-red-900 mb-1 font-semibold">
                  {selectedFileName}
                </p>
              )}
              <p className="text-sm font-bold text-red-800">
                {uploadError || "We couldn't process this resume. Please try again or upload a DOCX file."}
              </p>
              <p className="text-xs text-red-600 mt-1">
                Please upload a valid text-based file or paste your resume content directly.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs font-bold px-4 py-2 rounded-xl bg-red-600 text-white hover:bg-red-700 transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Choose Another File</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowRawEditor(true);
                  }}
                  className="text-xs font-bold px-4 py-2 rounded-xl bg-white border border-red-300 text-red-700 hover:bg-red-50 transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Paste Resume Text Directly</span>
                </button>
              </div>

              {showRawEditor && (
                <div className="mt-4 pt-4 border-t border-red-200 text-left">
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    Paste Resume Text Below:
                  </label>
                  <textarea
                    rows={6}
                    value={resumeText}
                    placeholder="Paste your plain resume text here..."
                    onChange={(e) => {
                      onResumeChange(e.target.value, selectedFileName || 'Pasted_Resume.txt', e.target.value.length);
                      if (e.target.value.trim().length >= 20) {
                        setUploadStatus('READY');
                        setUploadError(null);
                      }
                    }}
                    className="w-full text-xs font-mono p-3 bg-white border border-red-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 leading-relaxed"
                  />
                </div>
              )}
            </div>
          ) : (
            /* ================= IDLE & DRAG-OVER STATE (Requirement #6) ================= */
            <div
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onDrop={onDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`group border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
                isDragging
                  ? 'border-indigo-600 bg-indigo-50/70 ring-4 ring-indigo-500/20 shadow-md scale-[1.01]'
                  : 'border-slate-300 hover:border-indigo-400 bg-slate-50/50 hover:bg-slate-50/80 hover:shadow-xs'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.txt"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mx-auto mb-3 border shadow-2xs transition-all duration-300 ${
                isDragging 
                  ? 'bg-indigo-600 text-white border-indigo-700 scale-110 -translate-y-1' 
                  : 'bg-indigo-50 text-indigo-600 border-indigo-100 group-hover:-translate-y-1 group-hover:bg-indigo-100 animate-breathing'
              }`}>
                <UploadCloud className="w-6 h-6" />
              </div>
              <p className="text-base font-bold text-slate-800 transition-colors group-hover:text-indigo-900">
                {isDragging ? 'Drop your resume here to begin extraction' : 'Upload your resume'}
              </p>
              <p className="text-xs font-medium text-slate-500 mt-1">
                PDF or DOCX • Max 10 MB
              </p>
              <p className="text-2xs text-indigo-600 font-semibold mt-2 group-hover:underline">
                {isDragging ? 'Release to upload' : 'Drag and drop your file here, or click to browse files'}
              </p>
            </div>
          )}
        </div>

        <hr className="border-slate-200" />

        {/* Cloud SQL Credentials Auto-Fill Banner (if authenticated and has credentials) */}
        {credentials && (credentials.targetRole || credentials.targetCompany) && (
          <div className="p-3.5 bg-gradient-to-r from-indigo-50 to-slate-50 border border-indigo-200/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
                <Database className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">
                    Saved Cloud Profile: {credentials.targetRole || 'Target Role'}
                  </span>
                  <span className="text-2xs font-semibold text-indigo-700 bg-indigo-100/60 px-1.5 py-0.2 rounded">
                    Cloud SQL
                  </span>
                </div>
                <p className="text-2xs text-slate-500">
                  Target: {credentials.targetCompany || 'Google'} · Seniority: {credentials.experienceLevel || '2–4 Years'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (credentials.targetRole) onJobTitleChange(credentials.targetRole);
                if (credentials.targetCompany) onCompanyChange(credentials.targetCompany);
                if (credentials.experienceLevel) onSeniorityChange(credentials.experienceLevel);
              }}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all cursor-pointer shadow-2xs shrink-0 flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
              <span>Apply Saved Profile</span>
            </button>
          </div>
        )}

        {/* ================= STEP 2: SELECT COMPANY ================= */}
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
              2
            </span>
            <h3 className="text-base font-bold text-slate-900">
              Which company are you applying to?
            </h3>
          </div>
          <p className="text-xs text-slate-500 mb-4">
            Select your target company. This selector represents your target organization (does not claim active vacancies).
          </p>

          {/* Popular Companies Quick Selector */}
          <div className="mb-4">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Popular Target Companies:
            </span>
            <div className="flex flex-wrap gap-2">
              {TOP_COMPANIES.slice(0, 8).map((c) => {
                const isSelected = company.toLowerCase() === c.name.toLowerCase() && !isCustomCompany;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      onCompanyChange(c.name);
                      setIsCustomCompany(false);
                      setIsCompanyDropdownOpen(false);
                    }}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-indigo-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <CompanyLogo name={c.name} size="sm" />
                    <span>{c.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Searchable Selector Box */}
          <div className="relative">
            {!isCustomCompany ? (
              <div>
                <div
                  onClick={() => setIsCompanyDropdownOpen(!isCompanyDropdownOpen)}
                  className="w-full flex items-center justify-between p-3.5 bg-slate-50 border border-slate-300 rounded-xl cursor-pointer hover:border-indigo-400 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {company ? (
                      <>
                        <CompanyLogo name={company} size="md" />
                        <div>
                          <p className="text-sm font-bold text-slate-900">{company}</p>
                          <p className="text-2xs text-slate-500">Selected target organization</p>
                        </div>
                      </>
                    ) : (
                      <div className="flex items-center gap-2 text-slate-400 text-xs">
                        <Building2 className="w-4 h-4" />
                        <span>Search or choose a target company...</span>
                      </div>
                    )}
                  </div>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isCompanyDropdownOpen ? 'rotate-180' : ''}`} />
                </div>

                {/* Dropdown Menu */}
                <AnimatePresence>
                  {isCompanyDropdownOpen && (
                    <motion.div
                      variants={dropdownVariants}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      className="absolute z-20 mt-2 w-full bg-white border border-slate-200 rounded-2xl shadow-lg p-3 space-y-2 max-h-80 overflow-y-auto"
                    >
                      {/* Search Input */}
                      <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type="text"
                          placeholder="Search companies (e.g. Google, Microsoft, Deloitte)..."
                          value={companySearch}
                          onChange={(e) => setCompanySearch(e.target.value)}
                          className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          autoFocus
                        />
                      </div>

                      <div className="space-y-1">
                        {filteredCompanies.map((c) => (
                          <div
                            key={c.id}
                            onClick={() => {
                              onCompanyChange(c.name);
                              setIsCompanyDropdownOpen(false);
                              setCompanySearch('');
                            }}
                            className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition-colors ${
                              company === c.name ? 'bg-indigo-50 text-indigo-900 font-bold' : 'hover:bg-slate-50 text-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <CompanyLogo name={c.name} size="sm" />
                              <div>
                                <p className="text-xs font-semibold">{c.name}</p>
                                <p className="text-2xs text-slate-400">{c.industry}</p>
                              </div>
                            </div>
                            {c.ticker && (
                              <span className="text-2xs font-mono text-slate-400 px-1.5 py-0.5 bg-slate-100 rounded">
                                {c.ticker}
                              </span>
                            )}
                          </div>
                        ))}

                        {/* Other / Not Listed Item */}
                        <div
                          onClick={() => {
                            setIsCustomCompany(true);
                            setIsCompanyDropdownOpen(false);
                            onCompanyChange('');
                          }}
                          className="flex items-center gap-3 p-2.5 rounded-xl cursor-pointer hover:bg-indigo-50 text-indigo-600 font-bold border-t border-slate-100 mt-2"
                        >
                          <div className="w-6 h-6 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
                            <Plus className="w-4 h-4" />
                          </div>
                          <span className="text-xs">Other / Not Listed (Enter Custom Company)</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800">
                    Enter Target Company Name:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomCompany(false);
                      onCompanyChange(TOP_COMPANIES[0].name);
                    }}
                    className="text-xs text-indigo-600 hover:underline font-semibold"
                  >
                    Back to Company List
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={company}
                    onChange={(e) => onCompanyChange(e.target.value)}
                    placeholder="e.g. Stripe, Airbnb, Spotify, Siemens, Custom Tech Corp"
                    className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                    autoFocus
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <hr className="border-slate-200" />

        {/* ================= STEP 3: SELECT JOB ROLE ================= */}
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
              3
            </span>
            <h3 className="text-base font-bold text-slate-900">
              Which job role are you applying for?
            </h3>
          </div>
          <p className="text-xs text-slate-500 mb-4">
            Choose from categorized engineering, data, management, or business positions.
          </p>

          {/* Popular Roles Pills */}
          <div className="mb-4">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block mb-2">
              Popular Job Roles:
            </span>
            <div className="flex flex-wrap gap-2">
              {POPULAR_ROLES.map((r) => {
                const isSelected = jobTitle.toLowerCase() === r.toLowerCase() && !isCustomRole;
                return (
                  <button
                    key={r}
                    type="button"
                    onClick={() => {
                      onJobTitleChange(r);
                      setIsCustomRole(false);
                      setIsRoleDropdownOpen(false);
                    }}
                    className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-indigo-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {r}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Searchable Role Selector Box */}
          <div className="relative">
            {!isCustomRole ? (
              <div>
                <div
                  onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                  className="w-full flex items-center justify-between p-3.5 bg-slate-50 border border-slate-300 rounded-xl cursor-pointer hover:border-indigo-400 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Briefcase className="w-5 h-5 text-indigo-600" />
                    <div>
                      {jobTitle ? (
                        <>
                          <p className="text-sm font-bold text-slate-900">{jobTitle}</p>
                          <p className="text-2xs text-slate-500">Selected target position</p>
                        </>
                      ) : (
                        <span className="text-xs text-slate-400">
                          Search or select a role (e.g. Software Engineer, Data Scientist)...
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isRoleDropdownOpen ? 'rotate-180' : ''}`} />
                </div>

                <AnimatePresence>
                  {isRoleDropdownOpen && (
                    <motion.div
                      variants={dropdownVariants}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      className="absolute z-20 mt-2 w-full bg-white border border-slate-200 rounded-2xl shadow-lg p-3 space-y-3 max-h-96 overflow-y-auto"
                    >
                      <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type="text"
                          placeholder="Search roles (e.g. frontend, data, manager, security)..."
                          value={roleSearch}
                          onChange={(e) => setRoleSearch(e.target.value)}
                          className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          autoFocus
                        />
                      </div>

                      <div className="space-y-4">
                        {filteredCategories.map((cat) => (
                          <div key={cat.name} className="space-y-1">
                            <span className="text-2xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                              {cat.name}
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 pt-1">
                              {cat.roles.map((r) => (
                                <button
                                  key={r}
                                  type="button"
                                  onClick={() => {
                                    onJobTitleChange(r);
                                    setIsRoleDropdownOpen(false);
                                    setRoleSearch('');
                                  }}
                                  className={`text-left text-xs px-2.5 py-1.5 rounded-lg transition-colors ${
                                    jobTitle === r
                                      ? 'bg-indigo-600 text-white font-bold'
                                      : 'hover:bg-slate-100 text-slate-800'
                                  }`}
                                >
                                  {r}
                                </button>
                              ))}
                            </div>
                          </div>
                        ))}

                        {/* Custom Role Option */}
                        <div
                          onClick={() => {
                            setIsCustomRole(true);
                            setIsRoleDropdownOpen(false);
                            onJobTitleChange('');
                          }}
                          className="flex items-center gap-2 p-2.5 rounded-xl cursor-pointer hover:bg-indigo-50 text-indigo-600 font-bold border-t border-slate-100 pt-2"
                        >
                          <Plus className="w-4 h-4" />
                          <span className="text-xs">Other Role (Enter Custom Title)</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800">
                    Enter Your Custom Job Role:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomRole(false);
                      onJobTitleChange('Software Engineer');
                    }}
                    className="text-xs text-indigo-600 hover:underline font-semibold"
                  >
                    Back to Standard Roles
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => onJobTitleChange(e.target.value)}
                    placeholder="e.g. Staff Distributed Systems Engineer, Principal Architect"
                    className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                    autoFocus
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <hr className="border-slate-200" />

        {/* ================= STEP 4: EXPERIENCE LEVEL ================= */}
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-2xs">
              4
            </span>
            <h3 className="text-base font-bold text-slate-900">
              Experience Level
            </h3>
          </div>
          <p className="text-xs text-slate-500 mb-3">
            Select your target experience tier (intelligently calibrated with your resume).
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {SENIORITY_LEVELS.map((level) => {
              const isSelected = seniorityLevel === level;
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => onSeniorityChange(level)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all text-center ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:border-indigo-300 text-slate-700 hover:bg-white'
                  }`}
                >
                  {level}
                </button>
              );
            })}
          </div>
        </div>

        {/* ================= OPTIONAL JOB DESCRIPTION ================= */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setIsJdExpanded(!isJdExpanded)}
            className="w-full p-4 bg-slate-50/80 hover:bg-slate-50 flex items-center justify-between text-left transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Layers className="w-4 h-4 text-indigo-600" />
              <div>
                <span className="text-xs font-bold text-slate-800">
                  Have a specific job description? (Optional)
                </span>
                <p className="text-2xs text-slate-500">
                  {isJdExpanded ? 'Paste exact JD below for prioritized matching' : 'Click to add specific job description text'}
                </p>
              </div>
            </div>
            {isJdExpanded ? (
              <ChevronUp className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {isJdExpanded && (
            <div className="p-4 bg-white border-t border-slate-200 space-y-2">
              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-indigo-50/60 border border-indigo-100 text-indigo-950 text-2xs mb-2">
                <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <span>
                  <strong>High Priority Mode:</strong> If you paste an exact job description, it becomes the primary source for skill requirements and matching. If left empty, our platform evaluates requirements based on your target company, role, and experience tier.
                </span>
              </div>
              <textarea
                rows={5}
                value={jobDescription}
                onChange={(e) => onJobDescChange(e.target.value)}
                placeholder="Paste the full job description requirements here (optional)..."
                className="w-full text-xs p-3 bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800"
              />
            </div>
          )}
        </div>

        {/* ================= ANALYZE CTA BUTTON ================= */}
        <div className="pt-2">
          <button
            type="button"
            onClick={onStartAnalysis}
            disabled={!canAnalyze || isAnalyzing}
            className={`w-full py-4 px-6 rounded-2xl font-bold text-sm tracking-wide shadow-md transition-all flex items-center justify-center gap-2.5 ${
              canAnalyze && !isAnalyzing
                ? 'bg-gradient-to-r from-indigo-600 via-indigo-700 to-indigo-800 hover:from-indigo-500 hover:to-indigo-700 active:scale-[0.99] text-white cursor-pointer hover:shadow-lg hover:shadow-indigo-500/25 ring-2 ring-indigo-600/20'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
            }`}
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>STARTING DEEP AI ANALYSIS...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                <span>✨ Analyze My Resume</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          {!canAnalyze && (
            <p className="text-2xs text-center text-slate-400 mt-2">
              {isProcessing
                ? 'Extracting resume content...'
                : !hasResume
                ? 'Please upload your resume to begin'
                : !hasCompany
                ? 'Please select your target company'
                : !hasRole
                ? 'Please select your target job role'
                : 'Ready to analyze'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
