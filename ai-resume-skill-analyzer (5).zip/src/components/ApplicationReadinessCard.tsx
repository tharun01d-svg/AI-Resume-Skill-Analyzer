import React from 'react';
import { ApplicationReadiness, ReadinessLevel } from '../types/analyzer';
import { CheckCircle2, AlertTriangle, AlertCircle, ShieldCheck } from 'lucide-react';

interface ApplicationReadinessCardProps {
  readiness?: ApplicationReadiness;
  companyName: string;
  roleTitle: string;
}

export const ApplicationReadinessCard: React.FC<ApplicationReadinessCardProps> = ({
  readiness,
  companyName,
  roleTitle,
}) => {
  if (!readiness) return null;

  const getBadge = (level: ReadinessLevel) => {
    switch (level) {
      case 'Strong':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Strong
          </span>
        );
      case 'Moderate':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            Moderate
          </span>
        );
      case 'Needs Improvement':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
            <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
            Needs Improvement
          </span>
        );
    }
  };

  const dimensions = [
    {
      label: 'Skills',
      level: readiness.skills,
      description: 'Match against mandatory technical and functional qualifications',
    },
    {
      label: 'Experience',
      level: readiness.experience,
      description: 'Tenure, scope of ownership, and seniority expectations',
    },
    {
      label: 'Projects',
      level: readiness.projects,
      description: 'Demonstrable production systems and practical portfolio evidence',
    },
    {
      label: 'Resume Quality',
      level: readiness.resumeQuality,
      description: 'ATS readability, action verbs, and Google X-Y-Z quantified outcomes',
    },
    {
      label: 'Role Alignment',
      level: readiness.roleAlignment,
      description: 'Composite mathematical match across all 7 evaluation rubrics',
    },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900">
            Application Readiness
          </h3>
        </div>
        <span className="text-2xs text-slate-500">
          Calibrated for {roleTitle} at {companyName}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {dimensions.map((dim) => (
          <div
            key={dim.label}
            className="p-3.5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-slate-800">{dim.label}</span>
              </div>
              <p className="text-2xs text-slate-500 mb-3 leading-snug">
                {dim.description}
              </p>
            </div>
            <div>{getBadge(dim.level)}</div>
          </div>
        ))}
      </div>

      {readiness.summary && (
        <p className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200/80">
          {readiness.summary}
        </p>
      )}
    </div>
  );
};
