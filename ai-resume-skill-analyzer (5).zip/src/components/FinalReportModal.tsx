import React from 'react';
import { AnalysisReport } from '../types/analyzer';
import { Printer, Download, X, CheckCircle2, AlertCircle, XCircle, FileText, Calendar, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { modalOverlayVariants, modalDialogVariants } from '../utils/motion';

interface FinalReportModalProps {
  report: AnalysisReport;
  isOpen: boolean;
  onClose: () => void;
}

export const FinalReportModal: React.FC<FinalReportModalProps> = ({ report, isOpen, onClose }) => {
  const {
    resumeFileName,
    targetGoal,
    timestamp,
    resumeData,
    jobData,
    skillMatches,
    scoreResult,
    recommendations,
  } = report;

  const handlePrint = () => {
    window.print();
  };

  const matchedSkills = skillMatches.filter((m) => m.status === 'MATCHED');
  const partialSkills = skillMatches.filter((m) => m.status === 'PARTIAL');
  const missingSkills = skillMatches.filter((m) => m.status === 'MISSING');

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="final-report-overlay"
          variants={modalOverlayVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs"
        >
          <motion.div
            key="final-report-dialog"
            variants={modalDialogVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-5xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh]"
          >
        {/* Modal Toolbar - Hidden during print */}
        <div className="no-print px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Official Resume Alignment & Gap Audit Report
              </h2>
              <p className="text-xs text-slate-500">
                Generated {new Date(timestamp).toLocaleDateString()} for {candidateName(resumeData)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-indigo-600 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save as PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Content Container */}
        <div className="p-6 sm:p-10 overflow-y-auto space-y-8 text-slate-900 leading-normal" id="printable-report">
          {/* 1. Header Banner */}
          <div className="border-b border-slate-200 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 block mb-1">
                AI Resume Skill Analyzer · Audit Document
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                Candidate Evaluation Report
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                <span><strong>Candidate:</strong> {candidateName(resumeData)}</span>
                <span aria-hidden="true">·</span>
                <span><strong>File:</strong> {resumeFileName}</span>
                <span aria-hidden="true">·</span>
                <span><strong>Date:</strong> {new Date(timestamp).toLocaleString()}</span>
              </div>
            </div>

            {/* Score Callout */}
            <div className="text-right sm:border-l sm:border-slate-200 sm:pl-6">
              <span className="text-xs text-slate-500 uppercase tracking-widest font-semibold block">
                Resume-to-Role Alignment
              </span>
              <span className="text-4xl font-extrabold text-slate-900 font-mono tabular-nums">
                {scoreResult.totalScore} <span className="text-sm font-normal text-slate-400">/ 100</span>
              </span>
              <span className="text-xs font-bold block text-indigo-600 mt-0.5">
                {scoreResult.alignmentLevel}
              </span>
            </div>
          </div>

          {/* 2. Target Job & Candidate Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs">
            <div>
              <span className="font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Target Role & Organization
              </span>
              <p className="text-sm font-bold text-slate-900">{report.targetRole || jobData.job_title}</p>
              <p className="text-slate-700 font-medium mt-0.5">
                Target Company: <strong>{report.targetCompany || jobData.company_inferred}</strong>
              </p>
              <p className="text-slate-600 mt-0.5">
                Experience Tier: <strong>{report.experienceLevel || jobData.seniority_level}</strong> · Industry: {jobData.industry || 'Technology & Business'}
              </p>
              <p className="text-2xs text-slate-500 mt-1 font-medium">
                {report.isJobDescriptionSupplied
                  ? '• Analysis based on supplied job description'
                  : '• Analysis based on selected company, role, and experience level'}
              </p>
            </div>
            <div>
              <span className="font-bold text-slate-500 uppercase tracking-wider block mb-1">
                Candidate Profile
              </span>
              <p className="text-sm font-bold text-slate-900">
                {resumeData.career_level || 'Candidate'} · {resumeData.total_experience_years || 0} years experience
              </p>
              {targetGoal && (
                <p className="text-slate-700 mt-0.5">
                  <strong>Career Goal:</strong> "{targetGoal}"
                </p>
              )}
              {report.applicationReadiness && (
                <p className="text-xs text-indigo-900 bg-indigo-50 border border-indigo-100 p-2 rounded mt-2">
                  <strong>Application Readiness:</strong> {report.applicationReadiness.summary}
                </p>
              )}
              {resumeData.education?.[0] && (
                <p className="text-slate-600">
                  Education: {resumeData.education[0].degree} in {resumeData.education[0].field}
                </p>
              )}
            </div>
          </div>

          {/* 3. Executive Summary */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
              1. Executive Alignment Summary
            </h3>
            <p className="text-xs text-slate-700 leading-relaxed bg-slate-50/60 p-3 rounded border border-slate-200">
              {scoreResult.summary}
            </p>
          </div>

          {/* 4. Score Category Breakdown */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              2. Mathematical Category Breakdown (/100)
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-700">
                  <tr>
                    <th className="px-3 py-2">Category</th>
                    <th className="px-3 py-2 font-mono">Earned / Max</th>
                    <th className="px-3 py-2">Audit Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {Object.values(scoreResult.categories)
                    .filter((c): c is NonNullable<typeof c> => !!c && typeof c === 'object' && !!c.name)
                    .map((cat) => (
                      <tr key={cat.name}>
                        <td className="px-3 py-2 font-medium text-slate-900">{cat.name}</td>
                        <td className="px-3 py-2 font-mono tabular-nums font-bold">
                          {cat.is_applicable ? `${cat.earned} / ${cat.max}` : 'N/A (neutralized)'}
                        </td>
                        <td className="px-3 py-2 text-slate-600 text-2xs">{cat.details}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            <p className="mt-1 text-2xs text-slate-400 font-mono">
              {scoreResult.formula_explanation}
            </p>
          </div>

          {/* 5. Strong Matches */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1 mb-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              3. Strong Matches & Proven Strengths ({matchedSkills.length})
            </h3>
            <div className="space-y-1.5 text-xs">
              {matchedSkills.map((m, idx) => (
                <div key={idx} className="p-2.5 bg-emerald-50/50 border border-emerald-100 rounded flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div>
                    <span className="font-bold text-slate-900">{m.skill}</span>
                    <p className="text-2xs text-slate-600 mt-0.5">{m.resumeEvidence}</p>
                  </div>
                  <span className="text-2xs font-semibold text-emerald-700 bg-white border border-emerald-200 px-2 py-0.5 rounded shrink-0">
                    MATCHED
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 6. Partial Matches */}
          {partialSkills.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-800 flex items-center gap-1 mb-2">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                4. Partial & Related Matches ({partialSkills.length})
              </h3>
              <div className="space-y-1.5 text-xs">
                {partialSkills.map((m, idx) => (
                  <div key={idx} className="p-2.5 bg-amber-50/50 border border-amber-100 rounded flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-slate-900">{m.skill}</span>
                      <p className="text-2xs text-slate-600 mt-0.5">{m.resumeEvidence}</p>
                      {m.missingComponent && (
                        <p className="text-2xs text-amber-900 mt-1 font-medium">Missing: {m.missingComponent}</p>
                      )}
                    </div>
                    <span className="text-2xs font-semibold text-amber-700 bg-white border border-amber-200 px-2 py-0.5 rounded shrink-0">
                      PARTIAL
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. Skill Gaps */}
          {missingSkills.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-800 flex items-center gap-1 mb-2">
                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                5. Critical Skill Gaps to Close ({missingSkills.length})
              </h3>
              <div className="space-y-1.5 text-xs">
                {missingSkills.map((m, idx) => (
                  <div key={idx} className="p-2.5 bg-rose-50/50 border border-rose-100 rounded flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{m.skill}</span>
                        {m.isRequired && (
                          <span className="text-2xs font-bold text-rose-700 bg-white px-1.5 py-0.2 rounded border border-rose-200">
                            Required
                          </span>
                        )}
                      </div>
                      <p className="text-2xs text-slate-600 mt-0.5">{m.explanation}</p>
                    </div>
                    <span className="text-2xs font-semibold text-rose-700 bg-white border border-rose-200 px-2 py-0.5 rounded shrink-0">
                      MISSING
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 8. Resume Bullet Improvements */}
          {recommendations.resume_improvements?.length > 0 && (
            <div className="page-break">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                6. Recommended Resume Bullet Rewrites
              </h3>
              <div className="space-y-3 text-xs">
                {recommendations.resume_improvements.map((item, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <div className="text-2xs text-rose-700 line-through mb-1">
                      "{item.original_bullet}"
                    </div>
                    <div className="text-xs font-medium text-emerald-900">
                      "{item.improved_bullet}"
                    </div>
                    <div className="text-2xs text-slate-500 mt-1">
                      Rule: {item.rule_applied} · {item.reason}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 9. Personalized Learning Roadmap */}
          {recommendations.learning_roadmap?.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                7. Recommended Learning Roadmap
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {recommendations.learning_roadmap.map((week, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <span className="font-mono text-2xs font-bold text-indigo-600 block">
                      WEEK {week.week || idx + 1}
                    </span>
                    <h4 className="font-bold text-slate-900 mt-0.5">{week.focus}</h4>
                    <p className="text-2xs text-slate-600 mt-1">
                      <strong>Practice:</strong> {week.practice}
                    </p>
                    <p className="text-2xs text-emerald-800 mt-0.5">
                      <strong>Milestone:</strong> {week.milestone}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 10. Recommended Projects */}
          {recommendations.project_recommendations?.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                8. Gap-Closing Portfolio Project Recommendations
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {recommendations.project_recommendations.map((p, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-slate-900">{p.project}</span>
                      <span className="text-2xs bg-white border border-slate-200 px-1.5 py-0.2 rounded font-semibold text-indigo-700">
                        {p.difficulty}
                      </span>
                    </div>
                    <p className="text-2xs text-slate-600">{p.reason}</p>
                    <div className="mt-2 text-2xs text-slate-500 font-mono">
                      Skills: {p.skills.join(', ')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 11. Final Action Plan */}
          {recommendations.final_action_plan?.length > 0 && (
            <div className="p-4 bg-slate-100 rounded-lg text-xs space-y-1">
              <span className="font-bold uppercase tracking-wider text-slate-700 block mb-1">
                Final Action Plan
              </span>
              {recommendations.final_action_plan.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <span className="font-bold text-indigo-600">{idx + 1}.</span>
                  <span className="text-slate-800">{step}</span>
                </div>
              ))}
            </div>
          )}

          {/* Disclaimer Footer */}
          <div className="pt-6 border-t border-slate-200 text-center text-2xs text-slate-400">
            This report represents semantic resume-to-job requirement alignment calculated by AI Resume Skill Analyzer.
            It does not guarantee interviews or employment outcomes. Generated for educational and career enhancement purposes.
          </div>
        </div>

        {/* Modal Footer (Screen only) */}
        <div className="no-print px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Click "Print / Save as PDF" to generate an official hardcopy or PDF export.
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-indigo-600 rounded-lg transition-colors cursor-pointer"
            >
              Print / PDF
            </button>
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

function candidateName(resumeData: any): string {
  if (resumeData?.candidate?.name && resumeData.candidate.name !== 'Candidate') {
    return resumeData.candidate.name;
  }
  return 'Candidate';
}
