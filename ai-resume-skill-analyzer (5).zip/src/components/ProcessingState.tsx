import React, { useEffect, useState, useRef } from 'react';
import { CheckCircle2, Circle, Loader2, Sparkles, FileText, Cpu, Check, Layers, Target, Compass } from 'lucide-react';
import { motion } from 'motion/react';

interface ProcessingStateProps {
  targetCompany?: string;
  targetRole?: string;
}

export const ANALYSIS_STAGES = [
  { id: 1, label: 'Reading resume', sub: 'Parsing document text structure and raw sections' },
  { id: 2, label: 'Extracting candidate information', sub: 'Capturing contact, social links, and identity anchors' },
  { id: 3, label: 'Understanding career profile', sub: 'Analyzing professional trajectory and core specializations' },
  { id: 4, label: 'Detecting technical skills', sub: 'Categorizing languages, frameworks, databases, cloud, and tools' },
  { id: 5, label: 'Detecting non-technical skills', sub: 'Identifying leadership, cross-functional, and domain capabilities' },
  { id: 6, label: 'Analyzing work experience', sub: 'Evaluating roles, chronology, depth, and responsibility scopes' },
  { id: 7, label: 'Analyzing projects', sub: 'Assessing technical complexity, problem statements, and outcomes' },
  { id: 8, label: 'Evaluating achievements', sub: 'Verifying measurable business impact and scale markers' },
  { id: 9, label: 'Evaluating education', sub: 'Reviewing degrees, academic honors, and coursework relevance' },
  { id: 10, label: 'Evaluating certifications', sub: 'Verifying professional credentials and continuous learning' },
  { id: 11, label: 'Checking ATS structure', sub: 'Auditing headings, formatting simplicity, and parser compliance' },
  { id: 12, label: 'Evaluating keyword relevance', sub: 'Mapping domain terminology and role-specific requirements' },
  { id: 13, label: 'Evaluating clarity and writing', sub: 'Checking action verb vigor, passive voice, and wordiness' },
  { id: 14, label: 'Evaluating career-level alignment', sub: 'Benchmarking seniority expectations and execution autonomy' },
  { id: 15, label: 'Comparing against selected job role', sub: 'Measuring alignment against target enterprise competencies' },
  { id: 16, label: 'Identifying skill gaps', sub: 'Pinpointing missing mandatory and preferred qualifications' },
  { id: 17, label: 'Identifying resume weaknesses', sub: 'Isolating passive phrasing, vague metrics, and structural issues' },
  { id: 18, label: 'Creating improvement recommendations', sub: 'Formulating Google X-Y-Z bullet rewrites and actionable fixes' },
  { id: 19, label: 'Preparing personalized action plan', sub: 'Synthesizing customized 4-6 week learning milestones' },
  { id: 20, label: 'Generating final report', sub: 'Finalizing 10-category breakdown and ATS-ready resume model' },
];

export const ProcessingState: React.FC<ProcessingStateProps> = ({
  targetCompany,
  targetRole,
}) => {
  const [activeStep, setActiveStep] = useState(1);
  const activeItemRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const totalDuration = 16000; // 16s total progression
    const intervalTime = totalDuration / ANALYSIS_STAGES.length;

    const timer = setInterval(() => {
      setActiveStep((prev) => {
        if (prev < ANALYSIS_STAGES.length) return prev + 1;
        return prev;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, []);

  // Auto-scroll active item into view within the stages container
  useEffect(() => {
    if (activeItemRef.current) {
      activeItemRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    }
  }, [activeStep]);

  const progressPct = Math.round((activeStep / ANALYSIS_STAGES.length) * 100);

  return (
    <div className="max-w-2xl mx-auto my-8">
      {/* Container matching Prompt Spec */}
      <div className="bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-8 shadow-md relative overflow-hidden">
        {/* Top subtle glowing accent bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600" />

        {/* Header Section */}
        <div className="text-center mb-6">
          {/* ✦ AI ANALYSIS pill */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold tracking-wider uppercase mb-3 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
            <span>✦ AI ANALYSIS</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Analyzing your resume...
          </h3>

          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            {targetCompany && targetRole
              ? `Benchmarking qualifications for ${targetRole} at ${targetCompany}`
              : 'Evaluating comprehensive skills, ATS structure, and role alignment'}
          </p>
        </div>

        {/* Animated Visual Pipeline Flow (Requirement #9) */}
        <div className="mb-6 p-3 bg-slate-50/80 rounded-xl border border-slate-200/60">
          <div className="flex items-center justify-between gap-1 sm:gap-2">
            {[
              { label: 'Ingestion', icon: FileText, threshold: 3 },
              { label: 'Semantic Parser', icon: Cpu, threshold: 8 },
              { label: 'Skill Ontology', icon: Layers, threshold: 14 },
              { label: 'Deterministic Rubric', icon: Target, threshold: 17 },
              { label: 'Roadmap & Report', icon: Compass, threshold: 20 },
            ].map((node, index, arr) => {
              const NodeIcon = node.icon;
              const isPassed = activeStep >= node.threshold;
              const isCurrent = activeStep < node.threshold && (index === 0 || activeStep >= arr[index - 1].threshold);

              return (
                <React.Fragment key={node.label}>
                  <div className="flex flex-col items-center text-center flex-1">
                    <div
                      className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-all duration-300 ${
                        isPassed
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : isCurrent
                          ? 'bg-indigo-600 text-white ring-2 ring-indigo-400/40 shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-400'
                      }`}
                    >
                      {isPassed ? (
                        <Check className="w-4 h-4" />
                      ) : isCurrent ? (
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                      ) : (
                        <NodeIcon className="w-3.5 h-3.5" />
                      )}
                    </div>
                    <span
                      className={`text-3xs font-semibold mt-1 hidden sm:block truncate max-w-[70px] ${
                        isCurrent ? 'text-indigo-700 font-bold' : isPassed ? 'text-slate-700' : 'text-slate-400'
                      }`}
                    >
                      {node.label}
                    </span>
                  </div>

                  {index < arr.length - 1 && (
                    <div className="h-0.5 flex-1 bg-slate-200 relative overflow-hidden self-center mb-3 sm:mb-4">
                      <div
                        className={`h-full transition-all duration-500 ${
                          activeStep >= node.threshold ? 'bg-emerald-500' : 'bg-transparent'
                        }`}
                      />
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>

        {/* Progress Bar with Visual Representation */}
        <div className="mb-6 space-y-1.5">
          <div className="flex items-center justify-between text-2xs font-bold text-slate-500 font-mono">
            <span className="uppercase tracking-wider text-indigo-700">
              Stage {activeStep} of {ANALYSIS_STAGES.length}
            </span>
            <span className="text-slate-900 font-semibold">{progressPct}%</span>
          </div>

          <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden p-0.5 border border-slate-200/60">
            <div
              className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full transition-all duration-500 ease-out shadow-xs"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* 20-Stage Animated Sequence List */}
        <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1 border border-slate-100 rounded-xl p-2 bg-slate-50/40">
          {ANALYSIS_STAGES.map((stage) => {
            const isDone = stage.id < activeStep;
            const isCurrent = stage.id === activeStep;
            const isUpcoming = stage.id > activeStep;

            return (
              <div
                key={stage.id}
                ref={isCurrent ? activeItemRef : null}
                className={`flex items-start gap-3 p-2.5 rounded-lg border transition-all text-left ${
                  isCurrent
                    ? 'bg-indigo-50/90 border-indigo-300 text-indigo-950 shadow-2xs ring-1 ring-indigo-400/30'
                    : isDone
                    ? 'bg-white border-slate-200/70 text-slate-700'
                    : 'bg-transparent border-transparent text-slate-400 opacity-50'
                }`}
              >
                <div className="shrink-0 mt-0.5">
                  {isDone ? (
                    <motion.div
                      initial={{ scale: 0.6 }}
                      animate={{ scale: [0.6, 1.25, 1] }}
                      transition={{ duration: 0.25, ease: 'easeOut' }}
                      className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-2xs"
                    >
                      ✓
                    </motion.div>
                  ) : isCurrent ? (
                    <div className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center text-2xs shadow-2xs">
                      <Loader2 className="w-3 h-3 animate-spin text-white" />
                    </div>
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-300 text-slate-300 flex items-center justify-center text-2xs">
                      ○
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <p
                      className={`text-xs font-semibold ${
                        isCurrent
                          ? 'text-indigo-950 font-bold'
                          : isDone
                          ? 'text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {stage.id}. {stage.label}
                    </p>
                    {isDone && (
                      <span className="text-3xs font-bold font-mono text-emerald-700 uppercase tracking-wider bg-emerald-50 px-1.5 py-0.5 rounded">
                        Done
                      </span>
                    )}
                    {isCurrent && (
                      <span className="text-3xs font-bold font-mono text-indigo-700 uppercase tracking-wider bg-indigo-100 px-1.5 py-0.5 rounded animate-pulse">
                        Analyzing
                      </span>
                    )}
                  </div>
                  <p className="text-2xs text-slate-500 mt-0.5 truncate">
                    {stage.sub}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Deep analysis in progress indicator */}
        <div className="mt-6 pt-4 border-t border-slate-100 text-center flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />
          <span className="text-xs text-indigo-900 font-semibold tracking-wide">
            Deep analysis in progress
          </span>
          <span className="text-2xs text-slate-400 font-medium">
            · Real-time semantic grounding
          </span>
        </div>
      </div>
    </div>
  );
};
