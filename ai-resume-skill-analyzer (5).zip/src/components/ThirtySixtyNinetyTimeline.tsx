import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  Flame,
  AlertTriangle,
  TrendingUp,
  Award,
  Layers,
  Code,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Sparkles,
  Target,
  ArrowRight,
  BookOpen,
  CheckSquare,
  Square,
  Milestone,
  Check,
} from 'lucide-react';
import {
  RoadmapStage,
  PersonalizedSkillRecommendation,
} from '../utils/learningHubGenerator';
import { ResourceStatusControl } from './ResourceStatusControl';
import { buildResourceId } from '../hooks/useLearningProgress';

export interface ThirtySixtyNinetyTimelineProps {
  roadmap: {
    thirtyDays: RoadmapStage;
    sixtyDays: RoadmapStage;
    ninetyDays: RoadmapStage;
  };
  recommendations: PersonalizedSkillRecommendation[];
  roleTitle: string;
  targetCompany: string;
  experienceLevel?: string;
  onNavigateToSkill?: (skillName: string) => void;
}

type StageKey = '30_DAYS' | '60_DAYS' | '90_DAYS';

interface TimelineProgressState {
  stageStatus: Record<StageKey, 'not_started' | 'in_progress' | 'completed'>;
  completedTasks: string[];
  masteredSkills: string[];
}

const STORAGE_KEY = 'career_hub_30_60_90_timeline_v2';

export const ThirtySixtyNinetyTimeline: React.FC<ThirtySixtyNinetyTimelineProps> = ({
  roadmap,
  recommendations,
  roleTitle,
  targetCompany,
  experienceLevel = 'Mid-Level',
  onNavigateToSkill,
}) => {
  const stagesList = useMemo(() => [
    {
      key: '30_DAYS' as StageKey,
      phaseNumber: 1,
      shortLabel: '30 Days',
      title: '30 DAYS: Core Foundation & Gap Fundamentals',
      subtitle: 'Build syntax fluency, core APIs, and address primary resume disqualifiers.',
      accentColor: 'indigo',
      badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      activeBorderClass: 'border-indigo-500 ring-2 ring-indigo-500/20',
      dotClass: 'bg-indigo-600',
      data: roadmap.thirtyDays,
    },
    {
      key: '60_DAYS' as StageKey,
      phaseNumber: 2,
      shortLabel: '60 Days',
      title: '60 DAYS: Practical Integration & Full-Stack Rigor',
      subtitle: 'Integrate multi-tier backend services, databases, caching, and CI/CD pipelines.',
      accentColor: 'purple',
      badgeClass: 'bg-purple-50 text-purple-700 border-purple-200',
      activeBorderClass: 'border-purple-500 ring-2 ring-purple-500/20',
      dotClass: 'bg-purple-600',
      data: roadmap.sixtyDays,
    },
    {
      key: '90_DAYS' as StageKey,
      phaseNumber: 3,
      shortLabel: '90 Days',
      title: '90 DAYS: Scalability, Portfolio & Career Synthesis',
      subtitle: 'High-concurrency systems design, ATS portfolio proofs, and interview mastery.',
      accentColor: 'emerald',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      activeBorderClass: 'border-emerald-500 ring-2 ring-emerald-500/20',
      dotClass: 'bg-emerald-600',
      data: roadmap.ninetyDays,
    },
  ], [roadmap]);

  // Local state initialized from localStorage
  const [progressState, setProgressState] = useState<TimelineProgressState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return {
      stageStatus: {
        '30_DAYS': 'in_progress',
        '60_DAYS': 'not_started',
        '90_DAYS': 'not_started',
      },
      completedTasks: [],
      masteredSkills: [],
    };
  });

  // Save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progressState));
    } catch {
      // ignore
    }
  }, [progressState]);

  // Active filter or jump target ('ALL' or specific stage)
  const [selectedStageTab, setSelectedStageTab] = useState<'ALL' | StageKey>('ALL');

  // Expanded collapsible sections inside stages
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    '30_DAYS-gaps': true,
    '30_DAYS-tasks': true,
    '30_DAYS-milestone': true,
    '60_DAYS-gaps': true,
    '60_DAYS-tasks': true,
    '60_DAYS-milestone': true,
    '90_DAYS-gaps': true,
    '90_DAYS-tasks': true,
    '90_DAYS-milestone': true,
  });

  const toggleSection = (id: string) => {
    setExpandedSections((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Map identified skill gaps into stages
  const mappedSkillGapsByStage = useMemo(() => {
    const map: Record<StageKey, PersonalizedSkillRecommendation[]> = {
      '30_DAYS': [],
      '60_DAYS': [],
      '90_DAYS': [],
    };

    recommendations.forEach((rec) => {
      const skillLower = rec.skill.toLowerCase();

      // Check if explicitly in stage.skills
      const in30 = roadmap.thirtyDays.skills.some((s) => s.toLowerCase().includes(skillLower) || skillLower.includes(s.toLowerCase()));
      const in60 = roadmap.sixtyDays.skills.some((s) => s.toLowerCase().includes(skillLower) || skillLower.includes(s.toLowerCase()));
      const in90 = roadmap.ninetyDays.skills.some((s) => s.toLowerCase().includes(skillLower) || skillLower.includes(s.toLowerCase()));

      if (in30) {
        map['30_DAYS'].push(rec);
      } else if (in60) {
        map['60_DAYS'].push(rec);
      } else if (in90) {
        map['90_DAYS'].push(rec);
      } else {
        // Fallback mapping based on priority:
        if (rec.priority === 'HIGH') {
          map['30_DAYS'].push(rec);
        } else if (rec.priority === 'MEDIUM') {
          map['60_DAYS'].push(rec);
        } else {
          map['90_DAYS'].push(rec);
        }
      }
    });

    return map;
  }, [recommendations, roadmap]);

  // Compute stage-by-stage task counts and completion
  const stageStats = useMemo(() => {
    return stagesList.map((stage) => {
      const practiceTaskIds = stage.data.practiceTasks.map((_, i) => `${stage.key}-task-${i}`);
      const deliverableIds = stage.data.milestoneProject.deliverables.map((_, i) => `${stage.key}-deliv-${i}`);
      const allItemIds = [...practiceTaskIds, ...deliverableIds];

      const completedCount = allItemIds.filter((id) => progressState.completedTasks.includes(id)).length;
      const totalCount = allItemIds.length || 1;
      const percent = Math.round((completedCount / totalCount) * 100);

      const status = progressState.stageStatus[stage.key] || 'not_started';

      return {
        key: stage.key,
        phaseNumber: stage.phaseNumber,
        shortLabel: stage.shortLabel,
        title: stage.title,
        status,
        completedCount,
        totalCount,
        percent: status === 'completed' ? 100 : percent,
      };
    });
  }, [stagesList, progressState]);

  // Overall progress summary calculation
  const overallSummary = useMemo(() => {
    const totalPracticeTasks = stagesList.reduce(
      (acc, s) => acc + s.data.practiceTasks.length + s.data.milestoneProject.deliverables.length,
      0
    );
    const completedTasksCount = progressState.completedTasks.length;
    const stagesCompletedCount = Object.values(progressState.stageStatus).filter((st) => st === 'completed').length;

    // Weighted percentage: 70% task checks + 30% stage completions
    const taskPercent = totalPracticeTasks > 0 ? (completedTasksCount / totalPracticeTasks) * 100 : 0;
    const stagePercent = (stagesCompletedCount / 3) * 100;
    const combinedPercent = Math.min(100, Math.round(taskPercent * 0.7 + stagePercent * 0.3));

    // Active stage detection
    let activeStage: StageKey = '30_DAYS';
    if (progressState.stageStatus['30_DAYS'] === 'completed') {
      activeStage = progressState.stageStatus['60_DAYS'] === 'completed' ? '90_DAYS' : '60_DAYS';
    }

    return {
      combinedPercent,
      completedTasksCount,
      totalPracticeTasks,
      stagesCompletedCount,
      activeStage,
    };
  }, [stagesList, progressState]);

  // Actions
  const toggleTask = (taskId: string, stageKey: StageKey) => {
    setProgressState((prev) => {
      const isDone = prev.completedTasks.includes(taskId);
      const nextTasks = isDone
        ? prev.completedTasks.filter((id) => id !== taskId)
        : [...prev.completedTasks, taskId];

      // Auto update stage status if not marked completed yet
      const nextStageStatus = { ...prev.stageStatus };
      if (!isDone && nextStageStatus[stageKey] === 'not_started') {
        nextStageStatus[stageKey] = 'in_progress';
      }

      return {
        ...prev,
        completedTasks: nextTasks,
        stageStatus: nextStageStatus,
      };
    });
  };

  const toggleSkillMastery = (skillName: string) => {
    setProgressState((prev) => {
      const isMastered = prev.masteredSkills.includes(skillName);
      return {
        ...prev,
        masteredSkills: isMastered
          ? prev.masteredSkills.filter((s) => s !== skillName)
          : [...prev.masteredSkills, skillName],
      };
    });
  };

  const setStageState = (stageKey: StageKey, newStatus: 'not_started' | 'in_progress' | 'completed') => {
    setProgressState((prev) => ({
      ...prev,
      stageStatus: {
        ...prev.stageStatus,
        [stageKey]: newStatus,
      },
    }));
  };

  const resetAllProgress = () => {
    if (window.confirm('Reset all 30-60-90 timeline progress and checklist items?')) {
      setProgressState({
        stageStatus: {
          '30_DAYS': 'in_progress',
          '60_DAYS': 'not_started',
          '90_DAYS': 'not_started',
        },
        completedTasks: [],
        masteredSkills: [],
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* ========================================================================= */}
      {/* 1. PROGRESS BAR SUMMARY & TIMELINE HEADER GAUGE */}
      {/* ========================================================================= */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600">
                <Milestone className="w-5 h-5" />
              </span>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                30 – 60 – 90 Days Progression Timeline
              </h3>
            </div>
            <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
              Maps your verified resume skill gaps into a sequential 3-phase curriculum customized for{' '}
              <strong className="text-slate-800">{roleTitle}</strong> at{' '}
              <strong className="text-slate-800">{targetCompany}</strong>. Check off deliverables as you build real evidence.
            </p>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 self-start lg:self-center shrink-0">
            <button
              type="button"
              onClick={resetAllProgress}
              className="px-2.5 py-1.5 text-2xs font-semibold text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer border border-transparent hover:border-slate-200"
              title="Reset progress to start over"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Progress</span>
            </button>
          </div>
        </div>

        {/* Master Progress Bar Summary Component */}
        <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-xl p-5 text-white shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-2xs font-mono uppercase tracking-wider text-indigo-300 font-bold block">
                Total Career Execution Progress
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-3xl font-black font-mono tracking-tight text-white tabular-nums">
                  {overallSummary.combinedPercent}%
                </span>
                <span className="text-xs text-slate-300">
                  ({overallSummary.completedTasksCount} of {overallSummary.totalPracticeTasks} practice milestones completed)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-2xs font-semibold bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-indigo-400" />
                <span>
                  {overallSummary.combinedPercent === 100
                    ? '🎉 Curriculum Mastered!'
                    : `Active Phase: ${overallSummary.activeStage.replace('_', ' ')}`}
                </span>
              </span>
            </div>
          </div>

          {/* Dynamic Master Gradient Progress Bar */}
          <div className="w-full h-3 rounded-full bg-slate-800/80 p-0.5 border border-slate-700/60 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 rounded-full transition-all duration-500 shadow-sm"
              style={{ width: `${Math.max(4, overallSummary.combinedPercent)}%` }}
            />
          </div>

          {/* 3-Stage Progress Breakdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {stageStats.map((st) => {
              const isCompleted = st.status === 'completed' || st.percent === 100;
              const isInProgress = st.status === 'in_progress';

              return (
                <div
                  key={st.key}
                  onClick={() => setSelectedStageTab(st.key)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer select-none ${
                    selectedStageTab === st.key
                      ? 'bg-indigo-900/60 border-indigo-400/80 shadow-xs'
                      : 'bg-slate-800/50 border-slate-700/60 hover:bg-slate-800/80'
                  }`}
                >
                  <div className="flex items-center justify-between text-2xs mb-1">
                    <span className="font-mono font-bold text-slate-300 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                      Phase {st.phaseNumber}: {st.shortLabel}
                    </span>
                    <span className={`font-mono font-bold ${isCompleted ? 'text-emerald-400' : 'text-indigo-300'}`}>
                      {st.percent}%
                    </span>
                  </div>

                  <div className="w-full h-1.5 rounded-full bg-slate-700/80 overflow-hidden mb-2">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isCompleted
                          ? 'bg-emerald-400'
                          : isInProgress
                          ? 'bg-indigo-400'
                          : 'bg-slate-600'
                      }`}
                      style={{ width: `${st.percent}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-2xs text-slate-400">
                    <span>{st.completedCount}/{st.totalCount} items</span>
                    <span className={`px-1.5 py-0.5 rounded text-3xs font-bold uppercase tracking-wider ${
                      isCompleted
                        ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-700/60'
                        : isInProgress
                        ? 'bg-indigo-900/60 text-indigo-300 border border-indigo-700/60'
                        : 'bg-slate-700/60 text-slate-400'
                    }`}>
                      {isCompleted ? 'Completed' : isInProgress ? 'In Progress' : 'Pending'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stage Filter Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs font-semibold">
            <button
              type="button"
              onClick={() => setSelectedStageTab('ALL')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                selectedStageTab === 'ALL'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All 3 Stages (Full Timeline)
            </button>
            <button
              type="button"
              onClick={() => setSelectedStageTab('30_DAYS')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedStageTab === '30_DAYS'
                  ? 'bg-white text-indigo-600 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>30 Days</span>
              <span className="text-2xs font-mono font-bold bg-slate-200 px-1 rounded">
                {mappedSkillGapsByStage['30_DAYS'].length} gaps
              </span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedStageTab('60_DAYS')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedStageTab === '60_DAYS'
                  ? 'bg-white text-purple-600 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>60 Days</span>
              <span className="text-2xs font-mono font-bold bg-slate-200 px-1 rounded">
                {mappedSkillGapsByStage['60_DAYS'].length} gaps
              </span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedStageTab('90_DAYS')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedStageTab === '90_DAYS'
                  ? 'bg-white text-emerald-600 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>90 Days</span>
              <span className="text-2xs font-mono font-bold bg-slate-200 px-1 rounded">
                {mappedSkillGapsByStage['90_DAYS'].length} gaps
              </span>
            </button>
          </div>

          <div className="text-2xs text-slate-500 font-medium">
            💡 Click any checklist item or milestone deliverable to update your progress.
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. VISUAL TIMELINE STEPPER RIBBON */}
      {/* ========================================================================= */}
      <div className="relative bg-white border border-slate-200 rounded-2xl p-5 shadow-xs overflow-hidden">
        {/* Decorative background gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-50/20 via-purple-50/20 to-emerald-50/20 pointer-events-none" />

        {/* Connecting Progress Line (visible on desktop) */}
        <div className="hidden md:block absolute top-[45px] left-12 right-12 h-1 bg-slate-100 z-0">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 transition-all duration-700 ease-out"
            style={{
              width: `${
                overallSummary.activeStage === '90_DAYS'
                  ? 100
                  : overallSummary.activeStage === '60_DAYS'
                  ? 66
                  : 33
              }%`,
            }}
          />
        </div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4">
          {stagesList.map((stage, idx) => {
            const st = stageStats.find((s) => s.key === stage.key)!;
            const isCompleted = st.status === 'completed' || st.percent === 100;
            const isInProgress = st.status === 'in_progress';
            const mappedGaps = mappedSkillGapsByStage[stage.key];

            return (
              <motion.div
                key={stage.key}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.35,
                  delay: idx * 0.1,
                  ease: [0.16, 1, 0.3, 1],
                }}
                onClick={() => setSelectedStageTab(stage.key)}
                className={`p-4 rounded-xl border transition-all cursor-pointer relative bg-white flex flex-col justify-between ${
                  selectedStageTab === stage.key
                    ? 'border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                    : 'border-slate-200 hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div>
                  {/* Step Ribbon Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-black ${
                          isCompleted
                            ? 'bg-emerald-600 text-white'
                            : isInProgress
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : stage.phaseNumber}
                      </span>
                      <div>
                        <span className="text-2xs font-bold font-mono uppercase tracking-wider text-slate-400 block leading-none">
                          Phase {stage.phaseNumber}
                        </span>
                        <span className="text-xs font-black text-slate-900">
                          {stage.shortLabel}
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-2xs font-mono font-bold px-2 py-0.5 rounded ${
                        isCompleted
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : isInProgress
                          ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {isCompleted ? '✓ Completed' : isInProgress ? '● In Progress' : '○ Not Started'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-2 leading-snug mb-3">
                    {stage.subtitle}
                  </p>

                  {/* Identified Skill Gaps Mapped */}
                  <div className="space-y-1.5 pt-2 border-t border-slate-100">
                    <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block">
                      Skill Gaps Mapped ({mappedGaps.length}):
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {mappedGaps.slice(0, 3).map((gap, gIdx) => {
                        const isMastered = progressState.masteredSkills.includes(gap.skill);
                        return (
                          <span
                            key={gIdx}
                            className={`text-2xs px-1.5 py-0.5 rounded font-medium border flex items-center gap-1 ${
                              isMastered
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : gap.priority === 'HIGH'
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : 'bg-slate-50 text-slate-700 border-slate-200'
                            }`}
                          >
                            <span>{gap.skill}</span>
                            {isMastered && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />}
                          </span>
                        );
                      })}
                      {mappedGaps.length > 3 && (
                        <span className="text-2xs px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                          +{mappedGaps.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Progress bar at bottom of card */}
                <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between text-2xs text-slate-500">
                  <span>{st.completedCount} of {st.totalCount} completed</span>
                  <span className="font-mono font-bold text-slate-700">{st.percent}%</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. STRUCTURED LEARNING PATH STAGE DETAILS */}
      {/* ========================================================================= */}
      <div className="space-y-6">
        {stagesList
          .filter((st) => selectedStageTab === 'ALL' || selectedStageTab === st.key)
          .map((stage) => {
            const stStat = stageStats.find((s) => s.key === stage.key)!;
            const mappedGaps = mappedSkillGapsByStage[stage.key];
            const isCompleted = stStat.status === 'completed' || stStat.percent === 100;
            const isInProgress = stStat.status === 'in_progress';

            const gapsSectionKey = `${stage.key}-gaps`;
            const tasksSectionKey = `${stage.key}-tasks`;
            const milestoneSectionKey = `${stage.key}-milestone`;

            return (
              <div
                key={stage.key}
                className={`bg-white border rounded-2xl overflow-hidden shadow-xs transition-all ${
                  isCompleted
                    ? 'border-emerald-300'
                    : isInProgress
                    ? 'border-indigo-300'
                    : 'border-slate-200'
                }`}
              >
                {/* Stage Hero Banner */}
                <div className="p-6 bg-slate-50/90 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-indigo-600 text-white shadow-2xs">
                        PHASE {stage.phaseNumber}: {stage.shortLabel}
                      </span>
                      <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700">
                        {stage.data.timeframe}
                      </span>
                      <span
                        className={`text-2xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                          isCompleted
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : isInProgress
                            ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                            : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {isCompleted ? 'Phase Completed' : isInProgress ? 'In Progress' : 'Pending'}
                      </span>
                    </div>

                    <h4 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
                      {stage.title}
                    </h4>

                    <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">
                      {stage.subtitle}
                    </p>
                  </div>

                  {/* Stage Progress & Action Toggle */}
                  <div className="bg-white p-3.5 rounded-xl border border-slate-200 shrink-0 w-full sm:w-64 space-y-2.5 shadow-2xs">
                    <div className="flex items-center justify-between text-2xs">
                      <span className="font-bold uppercase tracking-wider text-slate-500">Stage Progress</span>
                      <span className="font-mono font-bold text-indigo-600 text-xs">{stStat.percent}%</span>
                    </div>

                    <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted
                            ? 'bg-emerald-500'
                            : isInProgress
                            ? 'bg-indigo-600'
                            : 'bg-slate-300'
                        }`}
                        style={{ width: `${stStat.percent}%` }}
                      />
                    </div>

                    <div className="flex items-center gap-1.5 pt-0.5">
                      <button
                        type="button"
                        onClick={() =>
                          setStageState(
                            stage.key,
                            isCompleted ? 'in_progress' : 'completed'
                          )
                        }
                        className={`w-full py-1.5 px-2.5 rounded-lg text-2xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border ${
                          isCompleted
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                            : 'bg-indigo-600 text-white border-indigo-700 hover:bg-indigo-700'
                        }`}
                      >
                        {isCompleted ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Marked Completed</span>
                          </>
                        ) : (
                          <>
                            <Check className="w-3.5 h-3.5 text-white" />
                            <span>Mark Stage Complete</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="p-6 space-y-6">
                  {/* ========================================================================= */}
                  {/* SUBSECTION A: IDENTIFIED SKILL GAPS MAPPED TO THIS STAGE */}
                  {/* ========================================================================= */}
                  <div className="bg-slate-50/70 border border-slate-200/90 rounded-xl p-4 space-y-3">
                    <div
                      onClick={() => toggleSection(gapsSectionKey)}
                      className="flex items-center justify-between cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2">
                        <Target className="w-4 h-4 text-indigo-600" />
                        <h5 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                          Identified Resume Skill Gaps Mapped to Phase {stage.phaseNumber} ({mappedGaps.length})
                        </h5>
                      </div>
                      <button type="button" className="text-slate-400 hover:text-slate-700">
                        {expandedSections[gapsSectionKey] ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </button>
                    </div>

                    {expandedSections[gapsSectionKey] && (
                      <div className="space-y-2 pt-1">
                        {mappedGaps.length === 0 ? (
                          <p className="text-xs text-slate-500 italic">
                            No immediate gaps designated for this timeframe. Focus on architectural synthesis.
                          </p>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            {mappedGaps.map((gap) => {
                              const isMastered = progressState.masteredSkills.includes(gap.skill);

                              return (
                                <div
                                  key={gap.id}
                                  className={`p-3.5 rounded-lg border bg-white flex flex-col justify-between transition-colors ${
                                    isMastered ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200'
                                  }`}
                                >
                                  <div>
                                    <div className="flex items-start justify-between gap-2 mb-1.5">
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-bold text-xs text-slate-900">{gap.skill}</span>
                                        <span
                                          className={`text-3xs font-bold uppercase tracking-wider px-1.5 py-0.2 rounded border ${
                                            gap.priority === 'HIGH'
                                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                                              : gap.priority === 'MEDIUM'
                                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                          }`}
                                        >
                                          {gap.priority}
                                        </span>
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => toggleSkillMastery(gap.skill)}
                                        className={`px-2 py-0.5 rounded text-2xs font-semibold border transition-colors cursor-pointer flex items-center gap-1 ${
                                          isMastered
                                            ? 'bg-emerald-600 text-white border-emerald-700'
                                            : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                                        }`}
                                      >
                                        {isMastered ? (
                                          <>
                                            <Check className="w-3 h-3 text-white" />
                                            <span>Mastered</span>
                                          </>
                                        ) : (
                                          <span>Mark Mastered</span>
                                        )}
                                      </button>
                                    </div>

                                    <div className="space-y-1 text-2xs text-slate-600">
                                      <p>
                                        <strong className="text-slate-800">Gap:</strong> {gap.gap}
                                      </p>
                                      <p className="line-clamp-2">
                                        <strong className="text-slate-800">Target Outcome:</strong> {gap.expectedOutcome}
                                      </p>
                                    </div>
                                  </div>

                                  {onNavigateToSkill && (
                                    <button
                                      type="button"
                                      onClick={() => onNavigateToSkill(gap.skill)}
                                      className="text-2xs text-indigo-600 hover:text-indigo-800 font-semibold pt-2 flex items-center gap-1 self-start cursor-pointer"
                                    >
                                      <span>View Full Skill Resources</span>
                                      <ArrowRight className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* ========================================================================= */}
                  {/* SUBSECTION B: CORE TECHNICAL SYLLABUS */}
                  {/* ========================================================================= */}
                  <div className="space-y-2">
                    <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                      Core Technical Syllabus for Phase {stage.phaseNumber}:
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                      {stage.data.topics.map((topic, tIdx) => (
                        <div
                          key={tIdx}
                          className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-lg flex items-start gap-2.5 text-slate-800"
                        >
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-2xs font-mono font-bold shrink-0 mt-0.5">
                            {tIdx + 1}
                          </span>
                          <span className="leading-snug">{topic}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* ========================================================================= */}
                  {/* SUBSECTION C: INTERACTIVE HANDS-ON PRACTICE CHECKLIST */}
                  {/* ========================================================================= */}
                  <div className="space-y-2.5">
                    <div
                      onClick={() => toggleSection(tasksSectionKey)}
                      className="flex items-center justify-between cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                        <h5 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                          Interactive Practice & Validation Tasks ({stage.data.practiceTasks.length})
                        </h5>
                      </div>
                      <span className="text-2xs font-mono text-slate-400">
                        Click to check off
                      </span>
                    </div>

                    <div className="space-y-2">
                      {stage.data.practiceTasks.map((task, pIdx) => {
                        const taskId = `${stage.key}-task-${pIdx}`;
                        const isDone = progressState.completedTasks.includes(taskId);

                        return (
                          <div
                            key={pIdx}
                            onClick={() => toggleTask(taskId, stage.key)}
                            className={`p-3 rounded-lg border flex items-center justify-between gap-3 text-xs cursor-pointer transition-all ${
                              isDone
                                ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950 line-through'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              {isDone ? (
                                <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                              ) : (
                                <Square className="w-4 h-4 text-slate-400 shrink-0" />
                              )}
                              <span>{task}</span>
                            </div>

                            <span
                              className={`text-2xs font-mono font-bold px-2 py-0.5 rounded shrink-0 ${
                                isDone ? 'bg-emerald-200/60 text-emerald-800' : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {isDone ? 'COMPLETED' : 'PENDING'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* ========================================================================= */}
                  {/* SUBSECTION D: VERIFIED LEARNING RESOURCES */}
                  {/* ========================================================================= */}
                  {stage.data.learningResources && stage.data.learningResources.length > 0 && (
                    <div className="space-y-2">
                      <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                        Recommended Direct Learning Pathways:
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {stage.data.learningResources.map((res, rIdx) => {
                          const resId = buildResourceId('timeline-res', stage.key, res.name);
                          return (
                            <div
                              key={rIdx}
                              className="p-3 bg-white border border-slate-200 hover:border-indigo-300 rounded-lg flex items-center justify-between gap-3 text-xs transition-colors"
                            >
                              <a
                                href={res.url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="space-y-0.5 grow group cursor-pointer"
                              >
                                <span className="font-bold text-slate-900 group-hover:text-indigo-600 block line-clamp-1">
                                  {res.name}
                                </span>
                                <span className="text-2xs text-slate-500 flex items-center gap-1.5">
                                  <span>{res.platform}</span>
                                  <span>·</span>
                                  <span className="font-medium text-indigo-600">{res.type}</span>
                                </span>
                              </a>
                              <div className="flex items-center gap-1.5 shrink-0">
                                <ResourceStatusControl resourceId={resId} compact />
                                <a
                                  href={res.url}
                                  target="_blank"
                                  rel="noreferrer noopener"
                                  className="p-1 text-slate-400 hover:text-indigo-600 cursor-pointer"
                                  title="Open learning resource"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </a>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* ========================================================================= */}
                  {/* SUBSECTION E: STAGE MILESTONE CAPSTONE PROJECT */}
                  {/* ========================================================================= */}
                  <div className="p-4 bg-gradient-to-br from-indigo-50/70 to-purple-50/70 border border-indigo-200 rounded-xl space-y-3">
                    <div
                      onClick={() => toggleSection(milestoneSectionKey)}
                      className="flex items-center justify-between cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2">
                        <Layers className="w-4 h-4 text-indigo-600" />
                        <h5 className="text-xs font-bold uppercase tracking-wider text-indigo-950">
                          Phase {stage.phaseNumber} Milestone Deliverable: {stage.data.milestoneProject.title}
                        </h5>
                      </div>
                      <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-white text-indigo-700 border border-indigo-200">
                        Portfolio Proof
                      </span>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-indigo-100 space-y-3">
                      <p className="text-xs text-slate-700 leading-relaxed">
                        {stage.data.milestoneProject.description}
                      </p>

                      <div className="space-y-1.5 pt-1">
                        <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                          Deliverable Verification Checklist:
                        </span>
                        <div className="space-y-1.5">
                          {stage.data.milestoneProject.deliverables.map((del, dIdx) => {
                            const delivId = `${stage.key}-deliv-${dIdx}`;
                            const isDone = progressState.completedTasks.includes(delivId);

                            return (
                              <div
                                key={dIdx}
                                onClick={() => toggleTask(delivId, stage.key)}
                                className={`p-2 rounded border flex items-center justify-between gap-2 text-2xs cursor-pointer transition-colors ${
                                  isDone
                                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900 line-through'
                                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  {isDone ? (
                                    <CheckSquare className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  ) : (
                                    <Square className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                  )}
                                  <span>{del}</span>
                                </div>
                                <span className="font-mono text-3xs font-bold text-slate-400 uppercase">
                                  {isDone ? 'Verified' : 'To Do'}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      <div className="pt-2 border-t border-slate-100 text-2xs text-indigo-900">
                        <strong>Resume Proof Target:</strong> {stage.data.milestoneProject.portfolioEvidence}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
};
