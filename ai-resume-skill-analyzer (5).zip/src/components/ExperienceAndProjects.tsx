import React from 'react';
import { ResumeData, JobData } from '../types/analyzer';
import { Briefcase, Code, GraduationCap, Award, CheckCircle2, AlertCircle, ArrowUpRight } from 'lucide-react';

interface ExperienceAndProjectsProps {
  resume: ResumeData;
  job: JobData;
}

export const ExperienceAndProjects: React.FC<ExperienceAndProjectsProps> = ({ resume, job }) => {
  const candYears = resume.total_experience_years || 0;
  const reqMinYears = job.experience_requirements?.min_years ?? 0;
  const reqPrefYears = job.experience_requirements?.preferred_years;

  const experienceRatio = reqMinYears > 0 ? (candYears / reqMinYears) : 1;
  const isExpSufficient = candYears >= reqMinYears;

  return (
    <div className="space-y-6">
      {/* 1. Experience & Seniority Alignment */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
          <Briefcase className="w-5 h-5 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900">
            Professional Experience & Seniority Alignment
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Experience Comparison Card */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Experience Duration
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
                {candYears} {candYears === 1 ? 'Year' : 'Years'}
              </span>
              <span className="text-xs text-slate-500">
                vs {reqMinYears}+ years required
              </span>
            </div>
            {/* Visual ratio bar */}
            <div className="mt-3 w-full bg-slate-200 rounded-full h-2 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isExpSufficient ? 'bg-emerald-600' : experienceRatio >= 0.7 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${Math.min(100, Math.round(experienceRatio * 100))}%` }}
              />
            </div>
            <p className="mt-2 text-2xs text-slate-600">
              {isExpSufficient
                ? 'Candidate meets or exceeds stated minimum experience threshold.'
                : `Shortfall of ${(reqMinYears - candYears).toFixed(1)} year(s) relative to target requirement.`}
            </p>
          </div>

          {/* Seniority Tier Card */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Target Seniority Level
            </span>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-lg font-bold text-slate-900">
                {job.seniority_level}
              </span>
              <span className="text-xs text-slate-500">
                (Candidate: {resume.career_level || 'Mid Level'})
              </span>
            </div>
            <p className="mt-3 text-xs text-slate-600 leading-relaxed">
              {job.seniority_level === resume.career_level
                ? 'Direct alignment in operational ownership and expected technical autonomy.'
                : `Job expects ${job.seniority_level} scope. Emphasize end-to-end architecture, cross-team ownership, and mentoring.`}
            </p>
          </div>

          {/* Job Stated Expectations */}
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-lg">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Employer Requirement Description
            </span>
            <p className="mt-2 text-xs text-slate-700 italic leading-relaxed">
              "{job.experience_requirements?.description || 'Prior verifiable industry experience in target domain.'}"
            </p>
          </div>
        </div>

        {/* Detailed Work Experience Bullets from Resume */}
        {resume.work_experience && resume.work_experience.length > 0 && (
          <div className="mt-6 pt-5 border-t border-slate-100">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
              Documented Work History Analyzed
            </h4>
            <div className="space-y-4">
              {resume.work_experience.map((exp, idx) => (
                <div key={idx} className="p-3.5 bg-slate-50/70 border border-slate-200/60 rounded-lg">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                    <span className="font-semibold text-slate-900 text-xs sm:text-sm">
                      {exp.role} <span className="text-slate-400 font-normal">at</span> {exp.company}
                    </span>
                    <span className="text-2xs text-slate-500 font-mono tabular-nums">
                      {exp.duration} {exp.years ? `(${exp.years} yr)` : ''}
                    </span>
                  </div>
                  {exp.responsibilities && exp.responsibilities.length > 0 && (
                    <ul className="list-disc list-inside space-y-1 text-xs text-slate-700">
                      {exp.responsibilities.map((r, rIdx) => (
                        <li key={rIdx} className="leading-relaxed">
                          {r}
                        </li>
                      ))}
                    </ul>
                  )}
                  {exp.technologies_used && exp.technologies_used.length > 0 && (
                    <div className="mt-2.5 flex items-center gap-1.5 flex-wrap text-2xs text-slate-500">
                      <span className="font-medium text-slate-600">Technologies:</span>
                      {exp.technologies_used.map((tech, tIdx) => (
                        <span key={tIdx} className="bg-white border border-slate-200 px-1.5 py-0.5 rounded text-slate-700">
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 2. Project Analysis Deep Dive */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
          <Code className="w-5 h-5 text-indigo-600" />
          <h3 className="text-base font-bold text-slate-900">
            Portfolio Project Depth & Practical Evidence
          </h3>
        </div>

        {(!resume.projects || resume.projects.length === 0) ? (
          <div className="p-6 bg-slate-50 rounded-lg text-center text-slate-500 text-xs">
            No projects explicitly documented in resume. Adding 1–2 portfolio artifacts will significantly boost match scores.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {resume.projects.map((proj, idx) => (
              <div key={idx} className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="font-bold text-sm text-slate-900">
                      {proj.name}
                    </h4>
                    <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 shrink-0">
                      {proj.evidence_strength || 'Demonstrated'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed mb-3">
                    {proj.description}
                  </p>

                  {proj.problem_solved && (
                    <div className="mb-2 text-2xs text-slate-700 bg-white p-2 rounded border border-slate-200/80">
                      <strong>Problem Solved:</strong> {proj.problem_solved}
                    </div>
                  )}

                  {proj.quantified_impact && (
                    <div className="mb-2 text-2xs text-emerald-800 bg-emerald-50/70 p-2 rounded border border-emerald-100">
                      <strong>Impact:</strong> {proj.quantified_impact}
                    </div>
                  )}
                </div>

                {proj.technologies && proj.technologies.length > 0 && (
                  <div className="pt-3 border-t border-slate-200/60 mt-2 flex flex-wrap gap-1">
                    {proj.technologies.map((tech, tIdx) => (
                      <span key={tIdx} className="text-2xs bg-white border border-slate-200 px-1.5 py-0.5 rounded text-slate-700 font-mono">
                        {tech}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. Education & Certifications Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Education */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Education & Coursework
            </h3>
          </div>

          {(!resume.education || resume.education.length === 0) ? (
            <p className="text-xs text-slate-500 italic">No formal education stated on resume.</p>
          ) : (
            <div className="space-y-3">
              {resume.education.map((edu, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
                  <div className="font-semibold text-xs text-slate-900">
                    {edu.degree} {edu.field ? `in ${edu.field}` : ''}
                  </div>
                  <div className="text-2xs text-slate-500 mt-0.5">
                    {edu.institution} {edu.graduation_year ? `· ${edu.graduation_year}` : ''}
                  </div>
                  {edu.relevant_coursework && edu.relevant_coursework.length > 0 && (
                    <div className="mt-2 text-2xs text-slate-600">
                      <strong>Relevant Coursework:</strong> {edu.relevant_coursework.join(', ')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Certifications */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
          <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-100">
            <Award className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Certifications & Credentials
            </h3>
          </div>

          {(!resume.certifications || resume.certifications.length === 0) ? (
            <div className="p-4 bg-slate-50 rounded-lg text-xs text-slate-600">
              <p>No industry certifications listed.</p>
              {job.certifications && job.certifications.length > 0 && (
                <p className="mt-1 text-2xs text-amber-800">
                  Job lists: {job.certifications.join(', ')}.
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              {resume.certifications.map((cert, idx) => (
                <div key={idx} className="p-2.5 bg-slate-50 rounded border border-slate-200/70 flex items-center gap-2 text-xs text-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{cert}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
