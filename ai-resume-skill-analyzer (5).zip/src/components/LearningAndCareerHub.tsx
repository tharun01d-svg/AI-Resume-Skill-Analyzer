import React, { useState, useEffect, useMemo } from 'react';
import { AnalysisReport } from '../types/analyzer';
import {
  generatePersonalizedLearningHubData,
  PersonalizedLearningHubData,
  PersonalizedSkillRecommendation,
  LearningPriority,
} from '../utils/learningHubGenerator';
import { ThirtySixtyNinetyTimeline } from './ThirtySixtyNinetyTimeline';
import { SkillProgressionChart } from './SkillProgressionChart';
import { ResourceStatusControl } from './ResourceStatusControl';
import {
  useLearningProgress,
  ResourceProgressStatus,
  buildResourceId,
} from '../hooks/useLearningProgress';
import {
  Compass,
  Calendar,
  Target,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Clock,
  PlayCircle,
  BookOpen,
  Award,
  ExternalLink,
  Code,
  Layers,
  Sparkles,
  Search,
  Filter,
  ArrowRight,
  CheckSquare,
  Square,
  Bookmark,
  BookmarkCheck,
  FileCheck,
  Briefcase,
  TrendingUp,
  HelpCircle,
  FileText,
  RotateCcw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface LearningAndCareerHubProps {
  report: AnalysisReport;
  onSelectTab?: (tab: 'overview' | 'deep' | 'rewrite' | 'skills' | 'experience' | 'roadmap') => void;
}

type HubViewMode = 'roadmap' | 'skills' | 'resources';
type ResourceTypeFilter = 'ALL' | 'YOUTUBE' | 'FREE_COURSE' | 'CERTIFICATE' | 'DOCS' | 'PRACTICE' | 'PROJECT';

const STORAGE_KEY = 'career_hub_progress_state';

interface UserProgressState {
  inProgressSkills: string[];
  completedSkills: string[];
  completedTasks: string[];
}

export const LearningAndCareerHub: React.FC<LearningAndCareerHubProps> = ({
  report,
  onSelectTab,
}) => {
  const data: PersonalizedLearningHubData = useMemo(() => {
    return generatePersonalizedLearningHubData(report);
  }, [report]);

  const [viewMode, setViewMode] = useState<HubViewMode>('skills');
  const [priorityFilter, setPriorityFilter] = useState<'ALL' | LearningPriority>('ALL');
  const [resourceTypeFilter, setResourceTypeFilter] = useState<ResourceTypeFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSkillIds, setExpandedSkillIds] = useState<Record<string, boolean>>({});
  const [resourceStatusFilter, setResourceStatusFilter] = useState<'ALL' | ResourceProgressStatus>('ALL');

  // Individual resource tracker persisted via useLearningProgress
  const {
    getStatus: getResourceStatus,
    setStatus: setResourceStatus,
    cycleStatus: cycleResourceStatus,
    getStats: getResourceStats,
    resetAll: resetAllResourceProgress,
  } = useLearningProgress();

  // User learning tracker in localStorage
  const [progressState, setProgressState] = useState<UserProgressState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return { inProgressSkills: [], completedSkills: [], completedTasks: [] };
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progressState));
    } catch {
      // Ignore storage errors
    }
  }, [progressState]);

  // Expand the first two skill cards by default
  useEffect(() => {
    if (data.recommendations.length > 0) {
      setExpandedSkillIds({
        [data.recommendations[0].id]: true,
        ...(data.recommendations[1] ? { [data.recommendations[1].id]: true } : {}),
      });
    }
  }, [data]);

  const toggleSkillExpand = (id: string) => {
    setExpandedSkillIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const expandAll = () => {
    const allExpanded: Record<string, boolean> = {};
    data.recommendations.forEach((r) => {
      allExpanded[r.id] = true;
    });
    setExpandedSkillIds(allExpanded);
  };

  const collapseAll = () => {
    setExpandedSkillIds({});
  };

  const toggleSkillProgress = (skillName: string) => {
    setProgressState((prev) => {
      const isInProgress = prev.inProgressSkills.includes(skillName);
      const isCompleted = prev.completedSkills.includes(skillName);

      if (!isInProgress && !isCompleted) {
        // Mark as In Progress
        return {
          ...prev,
          inProgressSkills: [...prev.inProgressSkills, skillName],
        };
      } else if (isInProgress) {
        // Move to Completed
        return {
          ...prev,
          inProgressSkills: prev.inProgressSkills.filter((s) => s !== skillName),
          completedSkills: [...prev.completedSkills, skillName],
        };
      } else {
        // Reset back to unstarted
        return {
          ...prev,
          completedSkills: prev.completedSkills.filter((s) => s !== skillName),
        };
      }
    });
  };

  const toggleTaskCompleted = (taskId: string) => {
    setProgressState((prev) => {
      const isDone = prev.completedTasks.includes(taskId);
      return {
        ...prev,
        completedTasks: isDone
          ? prev.completedTasks.filter((t) => t !== taskId)
          : [...prev.completedTasks, taskId],
      };
    });
  };

  // Filter skills
  const filteredSkills = useMemo(() => {
    return data.recommendations.filter((rec) => {
      const matchesPriority = priorityFilter === 'ALL' || rec.priority === priorityFilter;
      const matchesSearch =
        searchQuery === '' ||
        rec.skill.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.whyItMatters.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.whatToLearn.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchesPriority && matchesSearch;
    });
  }, [data.recommendations, priorityFilter, searchQuery]);

  // Statistics
  const totalSkillsCount = data.recommendations.length;
  const inProgressCount = data.recommendations.filter((r) =>
    progressState.inProgressSkills.includes(r.skill)
  ).length;
  const completedCount = data.recommendations.filter((r) =>
    progressState.completedSkills.includes(r.skill)
  ).length;
  const progressPercent = totalSkillsCount > 0 ? Math.round(((completedCount + inProgressCount * 0.5) / totalSkillsCount) * 100) : 0;

  // Compute all individual resource IDs in recommendations for stats tracking
  const allResourceIds = useMemo(() => {
    const ids: string[] = [];
    data.recommendations.forEach((rec) => {
      rec.youtube?.forEach((yt) => ids.push(buildResourceId('youtube', rec.skill, yt.title)));
      rec.freeCourses?.forEach((fc) => ids.push(buildResourceId('freecourse', rec.skill, fc.title)));
      rec.certificateCourses?.forEach((cert) => ids.push(buildResourceId('cert', rec.skill, cert.title)));
      rec.officialDocs?.forEach((doc) => ids.push(buildResourceId('docs', rec.skill, doc.title)));
      rec.practicePlatforms?.forEach((p) => ids.push(buildResourceId('practice', rec.skill, p.name)));
      rec.projects?.forEach((proj) => ids.push(buildResourceId('project', rec.skill, proj.title)));
    });
    return ids;
  }, [data.recommendations]);

  const resourceGlobalStats = useMemo(() => {
    return getResourceStats(allResourceIds);
  }, [getResourceStats, allResourceIds]);

  const getSkillResourceStats = (rec: PersonalizedSkillRecommendation) => {
    const ids: string[] = [];
    if (rec.youtube?.[0]) ids.push(buildResourceId('youtube', rec.skill, rec.youtube[0].title));
    if (rec.certificateCourses?.[0]) ids.push(buildResourceId('cert', rec.skill, rec.certificateCourses[0].title));
    if (rec.officialDocs?.[0]) ids.push(buildResourceId('docs', rec.skill, rec.officialDocs[0].title));
    if (rec.practicePlatforms?.[0]) ids.push(buildResourceId('practice', rec.skill, rec.practicePlatforms[0].name));
    if (rec.projects?.[0]) ids.push(buildResourceId('project', rec.skill, rec.projects[0].title));
    return getResourceStats(ids);
  };

  return (
    <div className="space-y-6">
      {/* 1. HERO HEADER: "What Should You Learn Next?" */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/50 rounded-2xl p-6 sm:p-7 text-white shadow-sm relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Personalized Learning & Career Hub</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <span>🚀 What Should You Learn Next?</span>
            </h2>

            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Build the skills that can strengthen your profile for your target role. Every recommendation is curated from your actual resume evidence, target company standards, and verified skill gaps.
            </p>

            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-300 pt-2">
              <span>Target Role: <strong className="text-white">{data.roleTitle}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Company: <strong className="text-white">{data.targetCompany}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Level: <strong className="text-indigo-300">{data.experienceLevel}</strong></span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-emerald-400 font-bold">{data.totalGapsIdentified} Skill Gaps Identified</span>
            </div>
          </div>

          {/* Quick Progress Indicator Card */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 md:w-72 shrink-0 space-y-2.5 shadow-xs backdrop-blur-xs">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-2xs">Skill Gaps Progress</span>
              <span className="font-mono font-bold text-indigo-400 text-xs tabular-nums">{progressPercent}%</span>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full h-2 rounded-full bg-slate-700/70 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-2xs text-slate-400 pt-0.5">
              <span>{inProgressCount} in progress</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400 font-semibold">{completedCount} mastered</span>
              <span aria-hidden="true">·</span>
              <span>{totalSkillsCount} total</span>
            </div>

            {/* Individual Resource Tracking Summary */}
            <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-2xs">
              <span className="text-slate-400">Tracked Resources:</span>
              <span className="font-semibold text-emerald-300">
                {resourceGlobalStats.completed} completed · {resourceGlobalStats.inProgress} active
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. CAREER JOURNEY PIPELINE NAVIGATOR (RESUME → SKILLS → PROJECTS → CAREER) */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Candidate Career Execution Journey
            </h3>
          </div>
          <span className="text-2xs text-slate-500">
            Interactive multi-stage roadmap back to core sections
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* Step 1: Resume */}
          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('rewrite')}
            className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-300 transition-all text-left flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <span className="text-2xs font-mono font-bold text-slate-400 group-hover:text-indigo-600 block mb-0.5">
                STEP 1
              </span>
              <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700 flex items-center justify-between">
                <span>Resume Rewrite</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </span>
            </div>
            <p className="text-2xs text-slate-500 mt-1 line-clamp-2">
              Transform weak bullets with Google X-Y-Z formula.
            </p>
          </button>

          {/* Step 2: Skills */}
          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('skills')}
            className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-300 transition-all text-left flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <span className="text-2xs font-mono font-bold text-slate-400 group-hover:text-indigo-600 block mb-0.5">
                STEP 2
              </span>
              <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700 flex items-center justify-between">
                <span>Skill Matrix</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </span>
            </div>
            <p className="text-2xs text-slate-500 mt-1 line-clamp-2">
              Inspect matched, partial, and missing requirements.
            </p>
          </button>

          {/* Step 3: Projects */}
          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('experience')}
            className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-300 transition-all text-left flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <span className="text-2xs font-mono font-bold text-slate-400 group-hover:text-indigo-600 block mb-0.5">
                STEP 3
              </span>
              <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700 flex items-center justify-between">
                <span>Gap Projects</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </span>
            </div>
            <p className="text-2xs text-slate-500 mt-1 line-clamp-2">
              Build demonstrable portfolio proof on GitHub.
            </p>
          </button>

          {/* Step 4: Career */}
          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('deep')}
            className="p-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-indigo-50 hover:border-indigo-300 transition-all text-left flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <span className="text-2xs font-mono font-bold text-slate-400 group-hover:text-indigo-600 block mb-0.5">
                STEP 4
              </span>
              <span className="text-xs font-bold text-slate-900 group-hover:text-indigo-700 flex items-center justify-between">
                <span>Career Seniority</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5" />
              </span>
            </div>
            <p className="text-2xs text-slate-500 mt-1 line-clamp-2">
              Align scope, ownership, and interview readiness.
            </p>
          </button>
        </div>
      </div>

      {/* 3. VIEW MODE CONTROLS & SEARCH BAR */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* View Mode Segmented Switcher */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setViewMode('skills')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'skills'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>Skill Gaps ({data.recommendations.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setViewMode('roadmap')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'roadmap'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>30-60-90 Day Timeline</span>
              <span className="text-3xs font-mono font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 px-1.5 py-0.2 rounded">
                Timeline
              </span>
            </button>

            <button
              type="button"
              onClick={() => setViewMode('resources')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'resources'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Curated Resource Catalog</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skills, topics, or resources..."
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
            />
          </div>
        </div>

        {/* Priority Filter Tabs & Expand/Collapse All (for skills view) */}
        {viewMode === 'skills' && (
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 mr-1">
                Priority:
              </span>

              {[
                { id: 'ALL', label: 'All Recommendations', count: data.recommendations.length },
                {
                  id: 'HIGH',
                  label: '🔥 High Priority',
                  count: data.recommendations.filter((r) => r.priority === 'HIGH').length,
                },
                {
                  id: 'MEDIUM',
                  label: '🟡 Medium Priority',
                  count: data.recommendations.filter((r) => r.priority === 'MEDIUM').length,
                },
                {
                  id: 'LONG_TERM',
                  label: '🟢 Long-Term',
                  count: data.recommendations.filter((r) => r.priority === 'LONG_TERM').length,
                },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setPriorityFilter(f.id as any)}
                  className={`px-2.5 py-1 text-2xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
                    priorityFilter === f.id
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                  }`}
                >
                  <span>{f.label}</span>
                  <span className={`text-2xs font-mono font-bold px-1 rounded ${
                    priorityFilter === f.id ? 'bg-indigo-700/60 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {f.count}
                  </span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-2xs">
              <button
                type="button"
                onClick={expandAll}
                className="text-indigo-600 hover:text-indigo-800 font-medium cursor-pointer"
              >
                Expand all
              </button>
              <span className="text-slate-300">·</span>
              <button
                type="button"
                onClick={collapseAll}
                className="text-slate-500 hover:text-slate-800 font-medium cursor-pointer"
              >
                Collapse all
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 4. MAIN CONTENT AREA: SKILLS VIEW */}
      {viewMode === 'skills' && (
        <div className="space-y-4">
          {/* Quick Timeline Banner Callout */}
          <div className="p-4 bg-gradient-to-r from-indigo-50/90 via-purple-50/70 to-slate-50 border border-indigo-200/90 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <Calendar className="w-5 h-5" />
              </div>
              <div className="space-y-0.5">
                <span className="text-2xs font-bold font-mono uppercase tracking-wider text-indigo-700 block">
                  Structured Learning Path Available
                </span>
                <p className="text-xs font-bold text-slate-900">
                  Track your gaps across a sequential 30 – 60 – 90 Days Progression Timeline
                </p>
                <p className="text-2xs text-slate-600">
                  All {data.recommendations.length} identified gaps mapped into Foundation (30d), Integration (60d), and Capstone (90d) with interactive progress tracking.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setViewMode('roadmap')}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 shrink-0 cursor-pointer shadow-2xs self-start sm:self-center"
            >
              <span>View 30-60-90 Timeline</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {filteredSkills.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-slate-500">
              <HelpCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-800">No skill recommendations match your filter.</p>
              <p className="text-xs text-slate-500 mt-1">Try clearing search or switching priority filters.</p>
            </div>
          ) : (
            filteredSkills.map((rec, idx) => {
              const isExpanded = Boolean(expandedSkillIds[rec.id]);
              const isInProgress = progressState.inProgressSkills.includes(rec.skill);
              const isCompleted = progressState.completedSkills.includes(rec.skill);

              return (
                <div
                  key={rec.id}
                  className={`bg-white border rounded-xl overflow-hidden shadow-xs transition-all ${
                    isCompleted
                      ? 'border-emerald-300 bg-emerald-50/10'
                      : isInProgress
                      ? 'border-indigo-300 bg-indigo-50/10'
                      : 'border-slate-200'
                  }`}
                >
                  {/* Card Header Accordion Trigger */}
                  <div
                    onClick={() => toggleSkillExpand(rec.id)}
                    className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer hover:bg-slate-50/70 transition-colors select-none"
                  >
                    <div className="space-y-1.5 grow">
                      <div className="flex flex-wrap items-center gap-2">
                        {/* Priority Badge */}
                        <span
                          className={`text-2xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border flex items-center gap-1 ${
                            rec.priority === 'HIGH'
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : rec.priority === 'MEDIUM'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}
                        >
                          {rec.priority === 'HIGH' ? (
                            <>
                              <Flame className="w-3 h-3 text-rose-600" />
                              <span>HIGH PRIORITY</span>
                            </>
                          ) : rec.priority === 'MEDIUM' ? (
                            <>
                              <AlertTriangle className="w-3 h-3 text-amber-600" />
                              <span>MEDIUM PRIORITY</span>
                            </>
                          ) : (
                            <>
                              <TrendingUp className="w-3 h-3 text-emerald-600" />
                              <span>LONG-TERM</span>
                            </>
                          )}
                        </span>

                        {/* Status tracking indicator */}
                        {isCompleted ? (
                          <span className="text-2xs font-bold text-emerald-700 bg-emerald-100/70 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Mastered</span>
                          </span>
                        ) : isInProgress ? (
                          <span className="text-2xs font-bold text-indigo-700 bg-indigo-100/70 border border-indigo-200 px-2 py-0.5 rounded flex items-center gap-1">
                            <Clock className="w-3 h-3 text-indigo-600" />
                            <span>In Progress</span>
                          </span>
                        ) : null}

                        {/* Skill resources progress mini-pill */}
                        {(() => {
                          const sStats = getSkillResourceStats(rec);
                          if (sStats.completed > 0 || sStats.inProgress > 0) {
                            return (
                              <span className="text-3xs font-mono font-semibold text-slate-600 bg-slate-100 border border-slate-200 px-1.5 py-0.5 rounded flex items-center gap-1">
                                <BookOpen className="w-2.5 h-2.5 text-indigo-500" />
                                <span>{sStats.completed}/{sStats.total} resources done</span>
                              </span>
                            );
                          }
                          return null;
                        })()}
                      </div>

                      <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-slate-400">
                          #{idx + 1}
                        </span>
                        <span>{rec.skill}</span>
                      </h3>

                      <p className="text-xs text-slate-600 line-clamp-2 max-w-3xl leading-relaxed">
                        {rec.whyItMatters}
                      </p>
                    </div>

                    {/* Right side controls */}
                    <div className="flex items-center gap-3 shrink-0 self-start md:self-center" onClick={(e) => e.stopPropagation()}>
                      {/* Interactive Progress Button */}
                      <button
                        type="button"
                        onClick={() => toggleSkillProgress(rec.skill)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 cursor-pointer ${
                          isCompleted
                            ? 'bg-emerald-600 text-white border-emerald-700 hover:bg-emerald-700'
                            : isInProgress
                            ? 'bg-indigo-600 text-white border-indigo-700 hover:bg-indigo-700'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {isCompleted ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                            <span>Mastered</span>
                          </>
                        ) : isInProgress ? (
                          <>
                            <Clock className="w-3.5 h-3.5 text-white" />
                            <span>In Progress</span>
                          </>
                        ) : (
                          <>
                            <Square className="w-3.5 h-3.5 text-slate-400" />
                            <span>Start Learning</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => toggleSkillExpand(rec.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                        title={isExpanded ? 'Collapse' : 'Expand'}
                      >
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5" />
                        ) : (
                          <ChevronDown className="w-5 h-5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Expanded Body */}
                  {isExpanded && (
                    <div className="px-5 pb-6 pt-2 border-t border-slate-100 space-y-6">
                      {/* Diagnostic Analysis Strip: Evidence, Level, Gap, Why It Matters */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 text-xs">
                        <div className="space-y-1">
                          <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                            Current Resume Evidence:
                          </span>
                          <p className="text-slate-800 font-medium leading-relaxed">
                            {rec.currentEvidence}
                          </p>
                          <div className="pt-1 flex items-center gap-2 text-2xs text-slate-500">
                            <span>Detected Level:</span>
                            <span className="font-semibold text-slate-700">{rec.currentLevel}</span>
                          </div>
                        </div>

                        <div className="space-y-1 border-t md:border-t-0 md:border-l border-slate-200 md:pl-4 pt-2 md:pt-0">
                          <span className="text-2xs font-bold uppercase tracking-wider text-rose-500 block">
                            Specific Gap for {data.roleTitle}:
                          </span>
                          <p className="text-slate-800 font-medium leading-relaxed">
                            {rec.gap}
                          </p>
                        </div>
                      </div>

                      {/* What to Learn Syllabus */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-indigo-600" />
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900">
                            Recommended Learning Syllabus:
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {rec.whatToLearn.map((topic, tIdx) => (
                            <div
                              key={tIdx}
                              className="p-2.5 bg-white border border-slate-200/80 rounded-lg flex items-start gap-2 text-xs text-slate-700"
                            >
                              <span className="w-5 h-5 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xs font-mono font-bold shrink-0 mt-0.5">
                                {tIdx + 1}
                              </span>
                              <span className="leading-snug">{topic}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Multimodal Resource Categories */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-indigo-600" />
                            <span>Curated Multi-Platform Learning Options</span>
                          </h4>
                          <span className="text-2xs text-slate-400">
                            Verified channels, official docs & courses
                          </span>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                          {/* 1. YouTube Learning */}
                          {rec.youtube && rec.youtube.length > 0 && (
                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex flex-col justify-between">
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                                    <PlayCircle className="w-4 h-4 text-rose-600" />
                                    <span>Recommended YouTube Learning</span>
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-2xs font-mono text-slate-500">
                                      {rec.youtube[0].duration}
                                    </span>
                                    <ResourceStatusControl
                                      resourceId={buildResourceId('youtube', rec.skill, rec.youtube[0].title)}
                                    />
                                  </div>
                                </div>

                                <div className="bg-white p-3 rounded-lg border border-slate-200/80 space-y-1.5">
                                  <p className="font-bold text-xs text-slate-900">
                                    {rec.youtube[0].title}
                                  </p>
                                  <div className="flex flex-wrap items-center gap-x-2 text-2xs text-slate-500">
                                    <span>Channel: <strong className="text-slate-700">{rec.youtube[0].channel}</strong></span>
                                    <span>·</span>
                                    <span>Level: <strong className="text-slate-700">{rec.youtube[0].level}</strong></span>
                                  </div>

                                  {rec.youtube[0].topics && rec.youtube[0].topics.length > 0 && (
                                    <div className="flex flex-wrap gap-1 pt-1">
                                      {rec.youtube[0].topics.map((t, idx) => (
                                        <span
                                          key={idx}
                                          className="text-2xs px-1.5 py-0.5 rounded bg-slate-100 text-slate-600"
                                        >
                                          {t}
                                        </span>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <a
                                href={rec.youtube[0].url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="w-full py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                              >
                                <PlayCircle className="w-4 h-4" />
                                <span>
                                  {rec.youtube[0].isSearchFallback
                                    ? `▶ Search on YouTube`
                                    : `▶ Watch on YouTube`}
                                </span>
                                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                              </a>
                            </div>
                          )}

                          {/* 2. Certificate Course Recommendations */}
                          {rec.certificateCourses && rec.certificateCourses.length > 0 && (
                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex flex-col justify-between">
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                                    <Award className="w-4 h-4 text-indigo-600" />
                                    <span>Certificate Course</span>
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                                      {rec.certificateCourses[0].platform}
                                    </span>
                                    <ResourceStatusControl
                                      resourceId={buildResourceId('cert', rec.skill, rec.certificateCourses[0].title)}
                                    />
                                  </div>
                                </div>

                                <div className="bg-white p-3 rounded-lg border border-slate-200/80 space-y-1.5">
                                  <p className="font-bold text-xs text-slate-900">
                                    {rec.certificateCourses[0].title}
                                  </p>
                                  <div className="flex flex-wrap items-center gap-x-2 text-2xs text-slate-500">
                                    <span>Duration: <strong className="text-slate-700">{rec.certificateCourses[0].duration}</strong></span>
                                    <span>·</span>
                                    <span className="text-emerald-700 font-semibold">{rec.certificateCourses[0].priceStatus}</span>
                                  </div>
                                  <p className="text-2xs text-slate-600 leading-snug pt-0.5">
                                    {rec.certificateCourses[0].whyRelevant}
                                  </p>
                                </div>
                              </div>

                              <a
                                href={rec.certificateCourses[0].url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                              >
                                <Award className="w-4 h-4" />
                                <span>Explore Course & Certificate</span>
                                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                              </a>
                            </div>
                          )}

                          {/* 3. Official Documentation */}
                          {rec.officialDocs && rec.officialDocs.length > 0 && (
                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex flex-col justify-between">
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                                    <FileText className="w-4 h-4 text-emerald-600" />
                                    <span>Official Documentation</span>
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-2xs text-slate-500 font-mono">
                                      Authoritative
                                    </span>
                                    <ResourceStatusControl
                                      resourceId={buildResourceId('docs', rec.skill, rec.officialDocs[0].title)}
                                    />
                                  </div>
                                </div>

                                <div className="bg-white p-3 rounded-lg border border-slate-200/80 space-y-1.5">
                                  <p className="font-bold text-xs text-slate-900">
                                    {rec.officialDocs[0].title}
                                  </p>
                                  <p className="text-2xs text-slate-600 leading-relaxed">
                                    {rec.officialDocs[0].description}
                                  </p>
                                  {rec.officialDocs[0].keySections && (
                                    <div className="flex flex-wrap gap-1 pt-1">
                                      {rec.officialDocs[0].keySections.map((sec, sIdx) => (
                                        <span
                                          key={sIdx}
                                          className="text-2xs px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-100"
                                        >
                                          {sec}
                                        </span>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </div>

                              <a
                                href={rec.officialDocs[0].url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="w-full py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                              >
                                <FileText className="w-4 h-4 text-slate-600" />
                                <span>Read Official Documentation</span>
                                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                              </a>
                            </div>
                          )}

                          {/* 4. Practice Platforms */}
                          {rec.practicePlatforms && rec.practicePlatforms.length > 0 && (
                            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex flex-col justify-between">
                              <div className="space-y-2">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                                    <Code className="w-4 h-4 text-purple-600" />
                                    <span>Interactive Practice Platforms</span>
                                  </span>
                                  <div className="flex items-center gap-2">
                                    <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                                      {rec.practicePlatforms[0].name}
                                    </span>
                                    <ResourceStatusControl
                                      resourceId={buildResourceId('practice', rec.skill, rec.practicePlatforms[0].name)}
                                    />
                                  </div>
                                </div>

                                <div className="bg-white p-3 rounded-lg border border-slate-200/80 space-y-1.5">
                                  <p className="font-bold text-xs text-slate-900">
                                    {rec.practicePlatforms[0].focus}
                                  </p>
                                  {rec.practicePlatforms[0].recommendedProblems && (
                                    <div className="space-y-1 pt-1">
                                      <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                                        Suggested Problem Focus:
                                      </span>
                                      <ul className="space-y-0.5 text-2xs text-slate-700">
                                        {rec.practicePlatforms[0].recommendedProblems.map((prob, pIdx) => (
                                          <li key={pIdx} className="flex items-center gap-1.5">
                                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                                            <span>{prob}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                </div>
                              </div>

                              <a
                                href={rec.practicePlatforms[0].url}
                                target="_blank"
                                rel="noreferrer noopener"
                                className="w-full py-2 px-3 bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-200 text-slate-800 hover:text-purple-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                              >
                                <Code className="w-4 h-4 text-purple-600" />
                                <span>Launch Practice Challenges</span>
                                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                              </a>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Project-Based Learning Highlight Card */}
                      {rec.projects && rec.projects[0] && (
                        <div className="p-4 rounded-xl border border-indigo-200 bg-gradient-to-r from-indigo-50/70 to-purple-50/70 space-y-3">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <Layers className="w-4 h-4 text-indigo-600" />
                              <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-950">
                                Gap-Closing Portfolio Project
                              </h4>
                            </div>
                            <div className="flex items-center gap-2 self-start sm:self-center">
                              <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-white border border-indigo-200 text-indigo-700">
                                {rec.projects[0].difficulty} Level
                              </span>
                              <ResourceStatusControl
                                resourceId={buildResourceId('project', rec.skill, rec.projects[0].title)}
                              />
                            </div>
                          </div>

                          <div className="bg-white p-3.5 rounded-lg border border-indigo-100 space-y-2">
                            <p className="font-bold text-sm text-slate-900">
                              {rec.projects[0].title}
                            </p>
                            <p className="text-xs text-slate-600 leading-relaxed">
                              {rec.projects[0].problemStatement}
                            </p>

                            <div className="space-y-1 pt-1">
                              <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
                                Core Deliverables:
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-2xs text-slate-700">
                                {rec.projects[0].features.map((feat, fIdx) => (
                                  <div key={fIdx} className="flex items-start gap-1.5">
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                    <span>{feat}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-2xs text-indigo-900">
                              <span><strong>Portfolio Goal:</strong> {rec.projects[0].evidenceGoal}</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Expected Outcome */}
                      <div className="p-3 bg-emerald-50/80 border border-emerald-200/80 rounded-lg flex items-start gap-2 text-xs text-emerald-950">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold uppercase tracking-wider text-2xs text-emerald-800 block">
                            Expected Skill Mastery Outcome:
                          </span>
                          <p className="mt-0.5">{rec.expectedOutcome}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* 5. 30-60-90 DAYS LEARNING ROADMAP & VISUAL TIMELINE VIEW */}
      {viewMode === 'roadmap' && (
        <div className="space-y-6">
          <SkillProgressionChart report={report} />
          <ThirtySixtyNinetyTimeline
            roadmap={data.roadmap}
            recommendations={data.recommendations}
            roleTitle={data.roleTitle}
            targetCompany={data.targetCompany}
            experienceLevel={data.experienceLevel}
            onNavigateToSkill={(skillName) => {
              setViewMode('skills');
              setSearchQuery(skillName);
            }}
          />
        </div>
      )}

      {/* 6. CURATED RESOURCE CATALOG VIEW */}
      {viewMode === 'resources' && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Verified Multi-Platform Learning Catalog
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                All resources are grounded in direct industry recommendations and official platforms without broken links.
              </p>
            </div>

            {/* Resource Type Filter Pills */}
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'ALL', label: 'All Resources' },
                { id: 'YOUTUBE', label: '🎥 YouTube' },
                { id: 'FREE_COURSE', label: '🎓 Free Courses' },
                { id: 'CERTIFICATE', label: '📜 Certificates' },
                { id: 'DOCS', label: '📖 Official Docs' },
                { id: 'PRACTICE', label: '💻 Practice' },
                { id: 'PROJECT', label: '🛠️ Projects' },
              ].map((rf) => (
                <button
                  key={rf.id}
                  type="button"
                  onClick={() => setResourceTypeFilter(rf.id as ResourceTypeFilter)}
                  className={`px-2.5 py-1 text-2xs font-semibold rounded-md transition-colors cursor-pointer ${
                    resourceTypeFilter === rf.id
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {rf.label}
                </button>
              ))}
            </div>
          </div>

          {/* Resource Progress Status Summary Bar */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Resource Progress Tracker
                </span>
                <span className="font-mono text-xs font-bold text-indigo-600 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
                  {resourceGlobalStats.percentCompleted}% Completed
                </span>
              </div>
              <p className="text-2xs text-slate-500">
                {resourceGlobalStats.completed} completed · {resourceGlobalStats.inProgress} in progress · {resourceGlobalStats.notStarted} not started across {resourceGlobalStats.total} total curated resources
              </p>
            </div>

            {/* Filter by Progress Status */}
            <div className="flex flex-wrap items-center gap-1.5 self-start md:self-center">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 mr-1">Status:</span>
              {[
                { id: 'ALL', label: 'All' },
                { id: 'not started', label: 'Not Started', count: resourceGlobalStats.notStarted },
                { id: 'in progress', label: 'In Progress', count: resourceGlobalStats.inProgress },
                { id: 'completed', label: 'Completed', count: resourceGlobalStats.completed },
              ].map((st) => (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setResourceStatusFilter(st.id as any)}
                  className={`px-2 py-1 text-2xs font-semibold rounded-md transition-colors cursor-pointer flex items-center gap-1 ${
                    resourceStatusFilter === st.id
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <span>{st.label}</span>
                  {st.count !== undefined && (
                    <span className={`text-3xs font-mono font-bold px-1 rounded ${
                      resourceStatusFilter === st.id ? 'bg-indigo-700 text-white' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {st.count}
                    </span>
                  )}
                </button>
              ))}

              {resourceGlobalStats.completed > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm('Reset progress on all individual learning resources?')) {
                      resetAllResourceProgress();
                    }
                  }}
                  className="px-2 py-1 text-2xs font-semibold rounded-md border border-slate-200 text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors ml-1 cursor-pointer flex items-center gap-1"
                  title="Reset all resource progress"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              )}
            </div>
          </div>

          {/* Catalog Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.recommendations.map((rec) => (
              <React.Fragment key={rec.id}>
                {/* YouTube Cards */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'YOUTUBE') &&
                  rec.youtube?.map((yt, idx) => {
                    const resId = buildResourceId('youtube', rec.skill, yt.title);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`yt-${rec.id}-${idx}`}
                        className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-rose-600 uppercase flex items-center gap-1">
                              <PlayCircle className="w-3 h-3" />
                              YouTube
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-slate-500 font-mono">{yt.duration}</span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {yt.title}
                          </h4>
                          <div className="flex items-center gap-2 text-2xs text-slate-500">
                            <span>{yt.channel}</span>
                            <span>·</span>
                            <span>Skill: <strong>{rec.skill}</strong></span>
                          </div>
                        </div>

                        <a
                          href={yt.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="py-1.5 px-3 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-800 hover:text-rose-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <PlayCircle className="w-3.5 h-3.5 text-rose-600" />
                          <span>Watch on YouTube</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      </div>
                    );
                  })}

                {/* Free Course Cards */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'FREE_COURSE') &&
                  rec.freeCourses?.map((fc, idx) => {
                    const resId = buildResourceId('freecourse', rec.skill, fc.title);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`fc-${rec.id}-${idx}`}
                        className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-emerald-700 uppercase flex items-center gap-1">
                              <BookOpen className="w-3 h-3" />
                              Free Course
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-emerald-700 font-semibold">{fc.freeStatus}</span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {fc.title}
                          </h4>
                          <div className="flex items-center gap-2 text-2xs text-slate-500">
                            <span>{fc.platform}</span>
                            <span>·</span>
                            <span>Skill: <strong>{rec.skill}</strong></span>
                          </div>
                        </div>

                        <a
                          href={fc.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="py-1.5 px-3 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 text-slate-800 hover:text-emerald-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Start Free Curriculum</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      </div>
                    );
                  })}

                {/* Certificate Course Cards */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'CERTIFICATE') &&
                  rec.certificateCourses?.map((cert, idx) => {
                    const resId = buildResourceId('cert', rec.skill, cert.title);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`cert-${rec.id}-${idx}`}
                        className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-indigo-700 uppercase flex items-center gap-1">
                              <Award className="w-3 h-3" />
                              {cert.platform}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-slate-500 font-mono">{cert.duration}</span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {cert.title}
                          </h4>
                          <p className="text-2xs text-slate-500 line-clamp-2">
                            {cert.whyRelevant}
                          </p>
                        </div>

                        <a
                          href={cert.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="py-1.5 px-3 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 text-slate-800 hover:text-indigo-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Award className="w-3.5 h-3.5 text-indigo-600" />
                          <span>View Certificate Info</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      </div>
                    );
                  })}

                {/* Official Docs */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'DOCS') &&
                  rec.officialDocs?.map((doc, idx) => {
                    const resId = buildResourceId('docs', rec.skill, doc.title);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`doc-${rec.id}-${idx}`}
                        className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-slate-600 uppercase flex items-center gap-1">
                              <FileText className="w-3 h-3" />
                              Documentation
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-slate-500 font-mono">Official</span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {doc.title}
                          </h4>
                          <p className="text-2xs text-slate-500 line-clamp-2">
                            {doc.description}
                          </p>
                        </div>

                        <a
                          href={doc.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="py-1.5 px-3 bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <FileText className="w-3.5 h-3.5 text-slate-500" />
                          <span>Read Docs</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      </div>
                    );
                  })}

                {/* Practice Platforms */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'PRACTICE') &&
                  rec.practicePlatforms?.map((prac, idx) => {
                    const resId = buildResourceId('practice', rec.skill, prac.name);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`prac-${rec.id}-${idx}`}
                        className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-purple-700 uppercase flex items-center gap-1">
                              <Code className="w-3 h-3" />
                              {prac.name}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-slate-500 font-mono">Interactive</span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {prac.focus}
                          </h4>
                          <p className="text-2xs text-slate-500">
                            Challenges focused on {rec.skill}
                          </p>
                        </div>

                        <a
                          href={prac.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="py-1.5 px-3 bg-white hover:bg-purple-50 border border-slate-200 hover:border-purple-200 text-slate-800 hover:text-purple-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <Code className="w-3.5 h-3.5 text-purple-600" />
                          <span>Solve Practice Problems</span>
                          <ExternalLink className="w-3 h-3 text-slate-400" />
                        </a>
                      </div>
                    );
                  })}

                {/* Project-Based Learning Cards */}
                {(resourceTypeFilter === 'ALL' || resourceTypeFilter === 'PROJECT') &&
                  rec.projects?.map((proj, idx) => {
                    const resId = buildResourceId('project', rec.skill, proj.title);
                    if (resourceStatusFilter !== 'ALL' && getResourceStatus(resId) !== resourceStatusFilter) return null;
                    return (
                      <div
                        key={`proj-${rec.id}-${idx}`}
                        className="p-4 bg-gradient-to-br from-indigo-50/50 to-purple-50/50 border border-indigo-200 rounded-xl flex flex-col justify-between space-y-3"
                      >
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-2xs">
                            <span className="font-bold text-indigo-700 uppercase flex items-center gap-1">
                              <Layers className="w-3 h-3" />
                              Project
                            </span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-2xs font-semibold px-1.5 py-0.5 rounded bg-white border border-indigo-200 text-indigo-700">
                                {proj.difficulty}
                              </span>
                              <ResourceStatusControl resourceId={resId} compact />
                            </div>
                          </div>
                          <h4 className="font-bold text-xs text-slate-900 line-clamp-2">
                            {proj.title}
                          </h4>
                          <p className="text-2xs text-slate-600 line-clamp-2">
                            {proj.problemStatement}
                          </p>
                          <div className="text-3xs text-indigo-900 font-medium pt-0.5">
                            Skill: <strong>{rec.skill}</strong>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-indigo-100 flex items-center justify-between text-2xs text-indigo-900">
                          <span className="truncate"><strong>Deliverable:</strong> {proj.features?.[0] || 'Full Architecture'}</span>
                        </div>
                      </div>
                    );
                  })}
              </React.Fragment>
            ))}
          </div>
        </div>
      )}

      {/* 7. CONNECT BACK TO CAREER ACTION FOOTER */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-400" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-white">
            Connect Your Learning Directly to Your Next Career Move
          </h3>
        </div>

        <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
          Learning alone doesn't pass resume screens—demonstrating tangible outcomes does. Integrate these newly acquired skills into your resume bullets, portfolio GitHub repositories, and interview stories.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('rewrite')}
            className="p-3.5 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 rounded-xl text-left transition-all group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-white group-hover:text-emerald-300">
              <span>Update Resume Bullets</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-300 transition-transform group-hover:translate-x-0.5" />
            </div>
            <p className="text-2xs text-slate-400 mt-1">
              Apply the Google X-Y-Z formula to showcase your new capabilities.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('experience')}
            className="p-3.5 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 rounded-xl text-left transition-all group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-white group-hover:text-indigo-300">
              <span>Build Recommended Projects</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-300 transition-transform group-hover:translate-x-0.5" />
            </div>
            <p className="text-2xs text-slate-400 mt-1">
              Inspect technical architectures designed to close your exact gaps.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab && onSelectTab('skills')}
            className="p-3.5 bg-slate-800/90 hover:bg-slate-800 border border-slate-700 rounded-xl text-left transition-all group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-white group-hover:text-purple-300">
              <span>View Full Skill Matrix</span>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-300 transition-transform group-hover:translate-x-0.5" />
            </div>
            <p className="text-2xs text-slate-400 mt-1">
              Verify requirement match statuses and ATS parsing clarity.
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};
