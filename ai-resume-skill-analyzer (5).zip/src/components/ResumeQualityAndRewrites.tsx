import React, { useState } from 'react';
import { ResumeData, ResumeImprovement } from '../types/analyzer';
import { Sparkles, Check, Copy, ArrowRight, ShieldCheck, FileCheck, ThumbsUp, AlertTriangle } from 'lucide-react';

interface ResumeQualityAndRewritesProps {
  resume: ResumeData;
  improvements: ResumeImprovement[];
}

export const ResumeQualityAndRewrites: React.FC<ResumeQualityAndRewritesProps> = ({
  resume,
  improvements,
}) => {
  const quality = resume.resume_quality || {
    overall_score: 3.5,
    structure_score: 3.5,
    formatting_score: 3.5,
    bullet_quality_score: 3.5,
    action_verbs_score: 3.5,
    quantified_impact_score: 3.0,
    ats_readability: 'Medium',
    strengths: [],
    weaknesses: [],
  };

  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleCopy = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* 1. Resume Quality Audit Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-5">
          <div className="flex items-center gap-2">
            <FileCheck className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">
              Resume Quality & ATS Readability Audit
            </h3>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold text-slate-500">Overall Rating:</span>
            <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
              {quality.overall_score} <span className="text-xs text-slate-400 font-normal">/ 5.0</span>
            </span>
          </div>
        </div>

        {/* 5-Dimension Radar / Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[
            { label: 'Structure & Flow', score: quality.structure_score },
            { label: 'Visual Formatting', score: quality.formatting_score },
            { label: 'Action Verb Strength', score: quality.action_verbs_score },
            { label: 'Quantified Metrics', score: quality.quantified_impact_score },
            { label: 'ATS Parsability', value: quality.ats_readability },
          ].map((dim, idx) => (
            <div key={idx} className="p-3 bg-slate-50 border border-slate-200/80 rounded-lg text-center">
              <span className="text-2xs font-semibold text-slate-500 uppercase tracking-wider block truncate">
                {dim.label}
              </span>
              <span className="mt-1 text-base font-bold font-mono text-slate-900 tabular-nums block">
                {dim.score !== undefined ? `${dim.score}/5` : dim.value}
              </span>
            </div>
          ))}
        </div>

        {/* Strengths & Weaknesses */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
          <div className="p-3.5 bg-emerald-50/50 border border-emerald-100 rounded-lg">
            <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <ThumbsUp className="w-3.5 h-3.5 text-emerald-600" />
              Verified Strengths
            </h4>
            <ul className="space-y-1 text-xs text-emerald-950">
              {quality.strengths?.length > 0 ? (
                quality.strengths.map((s, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-emerald-500 mt-0.5">•</span>
                    <span>{s}</span>
                  </li>
                ))
              ) : (
                <li className="italic text-slate-500">Contact information and job titles are clearly designated.</li>
              )}
            </ul>
          </div>

          <div className="p-3.5 bg-amber-50/50 border border-amber-100 rounded-lg">
            <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5 mb-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              High-Impact Fixes
            </h4>
            <ul className="space-y-1 text-xs text-amber-950">
              {quality.weaknesses?.length > 0 ? (
                quality.weaknesses.map((w, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-amber-500 mt-0.5">•</span>
                    <span>{w}</span>
                  </li>
                ))
              ) : (
                <li className="italic text-slate-500">Strengthen passive responsibilities into measurable business impact.</li>
              )}
            </ul>
          </div>
        </div>
      </div>

      {/* 2. Before & After Rewritten Bullets (Requirement #28) */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-5">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Action-Oriented Resume Bullet Improvements
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Rewritten using the Google X-Y-Z formula ("Accomplished [X] as measured by [Y], by doing [Z]"). Grounded strictly in your existing facts without inventing fake numbers or employers.
              </p>
            </div>
          </div>
        </div>

        {(!improvements || improvements.length === 0) ? (
          <p className="text-xs text-slate-500 italic p-4 text-center">
            Existing bullet points already exhibit strong action-verb phrasing and quantified metrics.
          </p>
        ) : (
          <div className="space-y-4">
            {improvements.map((item, idx) => (
              <div key={idx} className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/40">
                <div className="px-4 py-2 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between text-2xs font-semibold text-slate-600">
                  <span className="uppercase tracking-wider">{item.section || 'Work Experience'} Bullet Rewrite #{idx + 1}</span>
                  <span className="text-indigo-600 font-medium">{item.rule_applied || 'Google X-Y-Z Formula'}</span>
                </div>

                <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Current / Original */}
                  <div className="p-3 bg-white border border-rose-100 rounded-lg flex flex-col justify-between">
                    <div>
                      <span className="text-2xs font-bold uppercase tracking-wider text-rose-700 block mb-1">
                        Current Resume Phrasing (Passive / Vague)
                      </span>
                      <p className="text-xs text-slate-700 italic leading-relaxed">
                        "{item.original_bullet}"
                      </p>
                    </div>
                    <p className="text-2xs text-rose-600 mt-3 pt-2 border-t border-rose-50">
                      <strong>Issue:</strong> {item.reason}
                    </p>
                  </div>

                  {/* Improved Rewrite */}
                  <div className="p-3 bg-white border border-emerald-200 rounded-lg flex flex-col justify-between relative group">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-2xs font-bold uppercase tracking-wider text-emerald-700">
                          Recommended High-Impact Phrasing
                        </span>
                        <button
                          onClick={() => handleCopy(item.improved_bullet, idx)}
                          className="text-2xs text-slate-500 hover:text-indigo-600 flex items-center gap-1 cursor-pointer transition-colors"
                          title="Copy to clipboard"
                        >
                          {copiedIdx === idx ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span className="text-emerald-600 font-semibold">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-xs text-slate-900 font-medium leading-relaxed">
                        "{item.improved_bullet}"
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-emerald-50 flex items-center justify-between">
                      <span className="text-2xs text-emerald-800 font-medium">
                        ✓ Grounded in candidate evidence
                      </span>
                      <button
                        onClick={() => handleCopy(item.improved_bullet, idx)}
                        className="text-2xs font-semibold text-indigo-600 hover:underline cursor-pointer"
                      >
                        Use this phrasing →
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
