import React, { useState } from 'react';
import { ScoreResult, CategoryScore } from '../types/analyzer';
import {
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Target,
  Briefcase,
  Layers,
  GraduationCap,
  Award,
  FileCheck,
  ShieldCheck,
  Sparkles,
  Zap,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useCountUp, accordionVariants } from '../utils/motion';

interface ScoreRingProps {
  scoreResult: ScoreResult;
  onOpenFormula: () => void;
  onSelectDeepTab?: (tabKey: string) => void;
}

const CATEGORY_ICONS: Record<string, React.ElementType> = {
  required_skills: Target,
  preferred_skills: Zap,
  experience: Briefcase,
  projects: Layers,
  education: GraduationCap,
  certifications: Award,
  resume_quality: FileCheck,
  ats_readiness: ShieldCheck,
  content_clarity: Sparkles,
  achievement_strength: Zap,
};

export const ScoreRing: React.FC<ScoreRingProps> = ({
  scoreResult,
  onOpenFormula,
  onSelectDeepTab,
}) => {
  const { totalScore, categories } = scoreResult;
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  // Smooth count-up strictly terminating at actual totalScore
  const animatedScore = useCountUp(totalScore, 1100);

  // Dynamic status text matching prompt specification
  let tierBadgeText = 'Good foundation — several areas can be strengthened.';
  let strokeColor = '#4f46e5'; // Indigo
  let badgeColor = 'bg-amber-50 text-amber-800 border-amber-200';

  if (totalScore >= 80) {
    tierBadgeText = 'Strong alignment — well-calibrated for target requirements.';
    strokeColor = '#16a34a'; // Emerald
    badgeColor = 'bg-emerald-50 text-emerald-800 border-emerald-200';
  } else if (totalScore < 60) {
    tierBadgeText = 'Developing profile — several key areas can be strengthened.';
    strokeColor = '#e11d48'; // Rose
    badgeColor = 'bg-rose-50 text-rose-800 border-rose-200';
  }

  // SVG circle calculations synchronized with count-up
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (animatedScore / 100) * circumference;

  const categoryEntries = Object.entries(categories).filter(
    ([_, cat]) => cat && typeof cat === 'object' && cat.name
  ) as [string, CategoryScore][];

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-8">
      {/* Top Header & Visual Ring Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left: Overall Resume Alignment Score Circle */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center text-center lg:border-r lg:border-slate-100 lg:pr-8">
          <div className="relative w-48 h-48 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
              {/* Track */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                stroke="#f1f5f9"
                strokeWidth="11"
                fill="transparent"
              />
              {/* Progress Arc */}
              <circle
                cx="80"
                cy="80"
                r={radius}
                stroke={strokeColor}
                strokeWidth="11"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-300 ease-out"
              />
            </svg>

            {/* Center Numerals with Smooth Count-Up */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="flex items-baseline">
                <span className="text-4xl sm:text-5xl font-extrabold text-slate-900 font-mono tracking-tight tabular-nums">
                  {animatedScore}
                </span>
                <span className="text-base font-semibold text-slate-400 font-mono">
                  /100
                </span>
              </div>
              <span className="text-2xs font-bold text-slate-500 uppercase tracking-wider mt-1">
                Resume Alignment Score
              </span>
            </div>
          </div>

          {/* Under-Score Subheading */}
          <div className="mt-4 max-w-sm">
            <div className={`inline-block px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${badgeColor}`}>
              {tierBadgeText}
            </div>
            <p className="text-2xs text-slate-400 mt-2 leading-relaxed">
              This score represents resume content quality and alignment based on selected criteria, not a probability of getting hired.
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenFormula}
            className="mt-3 text-xs text-indigo-600 hover:text-indigo-800 font-semibold inline-flex items-center gap-1.5 cursor-pointer hover:underline transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Mathematical Model & Weight Breakdown</span>
          </button>
        </div>

        {/* Right: Score Breakdown Section Header & Summary */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                10-Category Deep Score Breakdown
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Click any category card to expand detailed diagnostics and view actionable improvement guidance.
              </p>
            </div>
            <span className="text-2xs font-mono font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-1 rounded">
              10 Dimensions
            </span>
          </div>

          {/* Quick Summary Strip */}
          <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200/70">
            {scoreResult.summary}
          </p>
        </div>
      </div>

      {/* 10 Interactive Category Cards Grid */}
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4">
          Detailed Category Performance & Explanations
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {categoryEntries.map(([catKey, cat]) => {
            const isExpanded = expandedCategory === catKey;
            const pct = cat.score_percentage !== undefined
              ? cat.score_percentage
              : cat.is_applicable && cat.max > 0
              ? Math.round((cat.earned / cat.max) * 100)
              : 0;

            const Icon = CATEGORY_ICONS[catKey] || Target;

            let barColor = 'bg-emerald-600';
            let badgeStyle = 'text-emerald-700 bg-emerald-50 border-emerald-200';
            if (pct < 50) {
              barColor = 'bg-rose-500';
              badgeStyle = 'text-rose-700 bg-rose-50 border-rose-200';
            } else if (pct < 75) {
              barColor = 'bg-amber-500';
              badgeStyle = 'text-amber-700 bg-amber-50 border-amber-200';
            }

            return (
              <div
                key={catKey}
                className={`border rounded-xl transition-all ${
                  isExpanded
                    ? 'border-indigo-300 bg-indigo-50/20 shadow-xs ring-1 ring-indigo-400/20'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-2xs'
                }`}
              >
                {/* Clickable Header Card */}
                <div
                  onClick={() => setExpandedCategory(isExpanded ? null : catKey)}
                  className="p-4 cursor-pointer select-none"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4 text-indigo-600" />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-slate-900">
                          {cat.name}
                        </h5>
                        <span className="text-3xs font-mono text-slate-400">
                          Weight: {cat.weight_percent}%
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${badgeStyle}`}>
                        {cat.is_applicable ? `${pct}%` : 'N/A'}
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden mb-2">
                    <div
                      className={`h-full transition-all duration-700 ease-out rounded-full ${barColor}`}
                      style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                    />
                  </div>

                  {/* Short Explanation */}
                  <p className="text-xs text-slate-600 leading-snug">
                    {cat.explanation || cat.details}
                  </p>
                </div>

                {/* Expandable Details Drawer with Smooth Animated Presence */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      variants={accordionVariants}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      className="px-4 pb-4 pt-2 border-t border-slate-100 bg-slate-50/70 rounded-b-xl space-y-3"
                    >
                      <div className="text-2xs text-slate-600 leading-relaxed">
                        <strong>Audit Details:</strong> {cat.details}
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-3xs font-mono text-slate-400">
                          Earned: {cat.earned} / {cat.max} pts
                        </span>

                        {onSelectDeepTab && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectDeepTab(cat.deep_analysis_key || 'deep');
                            }}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            <span>Explore Deep Analysis</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
