import React from 'react';

interface CompanyLogoProps {
  name: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const CompanyLogo: React.FC<CompanyLogoProps> = ({
  name,
  className = '',
  size = 'md',
}) => {
  const norm = name.trim().toLowerCase();

  const dimensions = {
    sm: 'w-6 h-6 text-[10px]',
    md: 'w-8 h-8 text-xs',
    lg: 'w-10 h-10 text-sm',
  }[size];

  // Vector graphics for verified top tech brands
  if (norm.includes('google')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-white shadow-sm border border-slate-200 shrink-0 ${dimensions} ${className}`}>
        <svg viewBox="0 0 24 24" className="w-5 h-5">
          <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.14z"/>
          <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.28 21.43 7.33 24 12 24z"/>
          <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.6H1.25C.45 8.21 0 10.05 0 12s.45 3.79 1.25 5.4l4.03-3.13z"/>
          <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.28 2.57 1.25 6.6l4.03 3.13c.95-2.83 3.6-4.98 6.72-4.98z"/>
        </svg>
      </div>
    );
  }

  if (norm.includes('microsoft')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-white shadow-sm border border-slate-200 shrink-0 ${dimensions} ${className}`}>
        <svg viewBox="0 0 24 24" className="w-4 h-4">
          <rect fill="#F25022" x="1" y="1" width="10" height="10" />
          <rect fill="#7FBA00" x="13" y="1" width="10" height="10" />
          <rect fill="#00A4EF" x="1" y="13" width="10" height="10" />
          <rect fill="#FFB900" x="13" y="13" width="10" height="10" />
        </svg>
      </div>
    );
  }

  if (norm.includes('amazon')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-slate-900 text-white shadow-sm shrink-0 font-black ${dimensions} ${className}`}>
        <span className="text-[#FF9900] tracking-tighter text-sm">a</span>
      </div>
    );
  }

  if (norm.includes('apple')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-slate-900 text-white shadow-sm shrink-0 ${dimensions} ${className}`}>
        <svg viewBox="0 0 170 170" className="w-4 h-4 fill-white">
          <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.69-7.85-12.01-14.42-6.53-9.98-11.83-21.2-15.91-33.68-4.08-12.48-6.13-24.16-6.13-35.03 0-14.45 3.49-26.44 10.47-35.96 6.98-9.52 15.67-14.36 26.06-14.53 4.58 0 9.85 1.25 15.82 3.75 5.97 2.5 9.77 3.79 11.4 3.86 1.41 0 5.34-1.39 11.8-4.17 6.46-2.78 12.08-3.99 16.85-3.63 12.8.96 22.86 5.86 30.18 14.69-11.16 6.78-16.63 16.03-16.42 27.76.22 9.77 4.04 17.84 11.47 24.2 7.43 6.36 16.36 9.94 26.79 10.74-2.28 7.06-4.78 14.12-7.51 21.19zM119.22 31.42c0-7.39 2.65-14.28 7.95-20.67 5.3-6.39 11.85-10.42 19.65-12.09.22 1.3.33 2.5.33 3.6 0 7.39-2.78 14.46-8.34 21.21-5.56 6.75-12.24 10.6-20.04 11.55-.22-1.2-.33-2.4-.33-3.6z"/>
        </svg>
      </div>
    );
  }

  if (norm.includes('meta')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-[#0081FB] text-white shadow-sm shrink-0 font-bold ${dimensions} ${className}`}>
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.5 13.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5c.83 0 1.5.67 1.5 1.5v2c0 .83-.67 1.5-1.5 1.5zm4.5 0c-.83 0-1.5-.67-1.5-1.5v-2c0-.83.67-1.5 1.5-1.5 1.38 0 2.5 1.12 2.5 2.5s-1.12 2.5-2.5 2.5z"/>
        </svg>
      </div>
    );
  }

  if (norm.includes('nvidia')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-black text-[#76B900] shadow-sm shrink-0 font-black ${dimensions} ${className}`}>
        <span className="text-xs font-black">n</span>
      </div>
    );
  }

  if (norm.includes('oracle')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-[#C74634] text-white shadow-sm shrink-0 font-bold ${dimensions} ${className}`}>
        <span className="text-[11px] font-black tracking-tighter">ORCL</span>
      </div>
    );
  }

  if (norm.includes('ibm')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-[#0F62FE] text-white shadow-sm shrink-0 font-bold ${dimensions} ${className}`}>
        <span className="text-[11px] font-black tracking-widest">IBM</span>
      </div>
    );
  }

  if (norm.includes('adobe')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-[#FA0F00] text-white shadow-sm shrink-0 font-bold ${dimensions} ${className}`}>
        <span className="text-xs font-black">A</span>
      </div>
    );
  }

  if (norm.includes('salesforce')) {
    return (
      <div className={`flex items-center justify-center rounded-lg bg-[#00A1E0] text-white shadow-sm shrink-0 font-bold ${dimensions} ${className}`}>
        <span className="text-xs font-black">sf</span>
      </div>
    );
  }

  // Fallback Initials Badge with deterministic pleasant color
  const initials = name
    .split(/[\s,.-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0].toUpperCase())
    .join('') || name.slice(0, 2).toUpperCase();

  const colors = [
    { bg: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
    { bg: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
    { bg: 'bg-amber-100 text-amber-800 border-amber-200' },
    { bg: 'bg-purple-100 text-purple-700 border-purple-200' },
    { bg: 'bg-sky-100 text-sky-700 border-sky-200' },
    { bg: 'bg-rose-100 text-rose-700 border-rose-200' },
  ];
  const charCode = name.charCodeAt(0) || 0;
  const picked = colors[charCode % colors.length];

  return (
    <div
      className={`flex items-center justify-center rounded-lg font-bold border shrink-0 ${picked.bg} ${dimensions} ${className}`}
      title={name}
    >
      <span>{initials}</span>
    </div>
  );
};
