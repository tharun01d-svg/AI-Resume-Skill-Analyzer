import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { AnalysisReport, PriorityLevel } from '../types/analyzer';
import { generatePersonalizedLearningHubData } from '../utils/learningHubGenerator';
import {
  TrendingUp,
  Target,
  Sparkles,
  Calendar,
  Layers,
  ArrowRight,
  Info,
  CheckCircle2,
  Clock,
  Award,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SkillProgressionChartProps {
  report: AnalysisReport;
  onExploreRoadmap?: () => void;
  className?: string;
}

type ChartViewMode = 'trajectory' | 'skills';

interface MilestoneData {
  id: string;
  stageName: string;
  shortLabel: string;
  days: number;
  timeframe: string;
  projectedScore: number;
  scoreDelta: number;
  focus: string;
  keySkills: string[];
  deliverable: string;
  summary: string;
}

interface SkillPathData {
  skill: string;
  priority: PriorityLevel;
  category: string;
  color: string;
  baseline: number;
  day30: number;
  day60: number;
  day90: number;
  roadmapStage: string;
}

const PALETTE = [
  '#4f46e5', // indigo
  '#0d9488', // teal
  '#ea580c', // orange
  '#8b5cf6', // purple
  '#059669', // emerald
  '#db2777', // pink
];

export const SkillProgressionChart: React.FC<SkillProgressionChartProps> = ({
  report,
  onExploreRoadmap,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const [viewMode, setViewMode] = useState<ChartViewMode>('trajectory');
  const [selectedMilestoneId, setSelectedMilestoneId] = useState<string>('day30');
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [activeTooltip, setActiveTooltip] = useState<{
    visible: boolean;
    x: number;
    y: number;
    title: string;
    score: number;
    delta?: number;
    details: string;
    subDetails?: string;
    skills?: string[];
  }>({
    visible: false,
    x: 0,
    y: 0,
    title: '',
    score: 0,
    details: '',
  });

  const { scoreResult, recommendations, targetRole, targetCompany } = report;
  const baselineScore = scoreResult.totalScore;

  // Generate structured hub data for accurate 30/60/90 skills & milestones
  const hubData = useMemo(() => {
    try {
      return generatePersonalizedLearningHubData(report);
    } catch {
      return null;
    }
  }, [report]);

  // Compute realistic, calibrated trajectory milestones based on current score
  const milestones: MilestoneData[] = useMemo(() => {
    const gap = 100 - baselineScore;
    const score30 = Math.min(88, Math.round(baselineScore + gap * 0.45));
    const score60 = Math.min(94, Math.round(baselineScore + gap * 0.74));
    const score90 = Math.min(98, Math.round(baselineScore + gap * 0.93));

    const skills30 = hubData?.roadmap.thirtyDays.skills.slice(0, 4) ||
      recommendations.top_priorities.slice(0, 2).map((p) => p.skill) || ['Core Syntax', 'Foundation'];

    const skills60 = hubData?.roadmap.sixtyDays.skills.slice(0, 4) ||
      recommendations.top_priorities.slice(2, 4).map((p) => p.skill) || ['Integration', 'API Architecture'];

    const skills90 = hubData?.roadmap.ninetyDays.skills.slice(0, 4) || ['System Design', 'Production Deployment'];

    return [
      {
        id: 'baseline',
        stageName: 'Current Resume Baseline',
        shortLabel: 'Day 0',
        days: 0,
        timeframe: 'Baseline',
        projectedScore: baselineScore,
        scoreDelta: 0,
        focus: 'Existing verified qualifications',
        keySkills: report.skillMatches
          .filter((m) => m.status === 'MATCHED')
          .slice(0, 3)
          .map((m) => m.skill),
        deliverable: 'Current resume state before targeted roadmap progression',
        summary: `Your baseline alignment score based on identified keywords, experience depth, and project evidence.`,
      },
      {
        id: 'day30',
        stageName: '30 Days: Core Foundation',
        shortLabel: 'Day 30',
        days: 30,
        timeframe: '1–4 Weeks',
        projectedScore: score30,
        scoreDelta: score30 - baselineScore,
        focus: 'Close primary technical disqualifiers & core syntax gaps',
        keySkills: skills30,
        deliverable: hubData?.roadmap.thirtyDays.milestoneProject.title || 'Functional Prototype & Syntax Proof',
        summary: `Address critical disqualifiers. Rapidly acquire core syntax and concepts to establish baseline qualification.`,
      },
      {
        id: 'day60',
        stageName: '60 Days: Practical Integration',
        shortLabel: 'Day 60',
        days: 60,
        timeframe: '5–8 Weeks',
        projectedScore: score60,
        scoreDelta: score60 - baselineScore,
        focus: 'Multi-tier backend integration, caching & CI/CD deployment',
        keySkills: skills60,
        deliverable: hubData?.roadmap.sixtyDays.milestoneProject.title || 'End-to-End Integrated Architecture',
        summary: `Build robust full-stack or systems applications with automated test coverage and real-world deployment.`,
      },
      {
        id: 'day90',
        stageName: '90 Days: Production & Interview Mastery',
        shortLabel: 'Day 90',
        days: 90,
        timeframe: '9–12 Weeks',
        projectedScore: score90,
        scoreDelta: score90 - baselineScore,
        focus: 'High-concurrency architecture, ATS portfolio evidence & interview readiness',
        keySkills: skills90,
        deliverable: hubData?.roadmap.ninetyDays.milestoneProject.title || 'Production Scalable System & Case Study',
        summary: `Reach elite candidate tier (90%+ alignment) with verified production-grade proof points ready for technical interviews.`,
      },
    ];
  }, [baselineScore, hubData, recommendations, report.skillMatches]);

  // Compute skill paths for top priority competencies
  const skillPaths: SkillPathData[] = useMemo(() => {
    const rawSkills = recommendations.top_priorities.length > 0
      ? recommendations.top_priorities.slice(0, 5)
      : report.skillMatches.filter((m) => m.status !== 'MATCHED').slice(0, 5).map((m) => ({
          skill: m.skill,
          priority: m.priority,
          reason: m.jobRequirement,
          learning_topics: [m.jobRequirement],
          practice_project: 'Gap project',
          evidence_goal: 'Production evidence',
        }));

    return rawSkills.map((s, idx) => {
      // Find matching status in resume
      const match = report.skillMatches.find((m) => m.skill.toLowerCase() === s.skill.toLowerCase());
      const isPartial = match?.status === 'PARTIAL';
      const baseLevel = isPartial ? 35 : 12;

      return {
        skill: s.skill,
        priority: s.priority,
        category: match?.isRequired ? 'Required' : 'Preferred',
        color: PALETTE[idx % PALETTE.length],
        baseline: baseLevel,
        day30: Math.min(95, baseLevel + 35 + (idx % 2 === 0 ? 5 : 0)),
        day60: Math.min(98, baseLevel + 60 + (idx % 2 === 0 ? 4 : 0)),
        day90: Math.min(100, baseLevel + 82),
        roadmapStage: idx < 2 ? 'Phase 1 (30 Days)' : idx < 4 ? 'Phase 2 (60 Days)' : 'Phase 3 (90 Days)',
      };
    });
  }, [recommendations.top_priorities, report.skillMatches]);

  // Active selected milestone data
  const selectedMilestone = milestones.find((m) => m.id === selectedMilestoneId) || milestones[1];

  // Render D3 chart when viewMode, milestones, or dimensions change
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth || 740;
    const height = 340;
    const margin = { top: 32, right: 36, bottom: 48, left: 52 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('width', '100%')
      .attr('height', height);

    const defs = svg.append('defs');

    // Gradient for overall trajectory area fill
    const areaGradient = defs
      .append('linearGradient')
      .attr('id', 'progressionAreaGradient')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    areaGradient.append('stop').attr('offset', '0%').attr('stop-color', '#4f46e5').attr('stop-opacity', 0.28);
    areaGradient.append('stop').attr('offset', '60%').attr('stop-color', '#06b6d4').attr('stop-opacity', 0.08);
    areaGradient.append('stop').attr('offset', '100%').attr('stop-color', '#10b981').attr('stop-opacity', 0.0);

    // Glowing filter for nodes
    const filter = defs.append('filter').attr('id', 'glow').attr('x', '-30%').attr('y', '-30%').attr('width', '160%').attr('height', '160%');
    filter.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale: Days (0 -> 90)
    const xScale = d3.scaleLinear().domain([0, 90]).range([0, innerWidth]);

    // Y Scale: Score (0 -> 100)
    const yScale = d3.scaleLinear().domain([0, 100]).range([innerHeight, 0]);

    // Background Horizontal Gridlines
    const yTicks = [20, 40, 60, 80, 100];
    g.append('g')
      .attr('class', 'grid')
      .selectAll('line')
      .data(yTicks)
      .enter()
      .append('line')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', (d) => yScale(d))
      .attr('y2', (d) => yScale(d))
      .attr('stroke', '#f1f5f9')
      .attr('stroke-dasharray', (d) => (d === 80 ? '4,4' : '2,2'))
      .attr('stroke-width', (d) => (d === 80 ? 1.5 : 1));

    // Target Benchmark Threshold Reference Line (80%)
    const targetY = yScale(80);
    g.append('line')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', targetY)
      .attr('y2', targetY)
      .attr('stroke', '#10b981')
      .attr('stroke-width', 1.5)
      .attr('stroke-dasharray', '5,5')
      .attr('opacity', 0.85);

    // Target Benchmark Pill Label
    const targetBadgeGroup = g.append('g').attr('transform', `translate(${innerWidth - 195}, ${targetY - 10})`);
    targetBadgeGroup
      .append('rect')
      .attr('width', 195)
      .attr('height', 20)
      .attr('rx', 4)
      .attr('fill', '#ecfdf5')
      .attr('stroke', '#a7f3d0')
      .attr('stroke-width', 1);

    targetBadgeGroup
      .append('text')
      .attr('x', 8)
      .attr('y', 14)
      .attr('fill', '#047857')
      .attr('font-size', '10px')
      .attr('font-family', 'Plus Jakarta Sans, sans-serif')
      .attr('font-weight', '700')
      .text('★ Target Qualification Benchmark (80%)');

    // Axes
    const xAxis = d3
      .axisBottom(xScale)
      .tickValues([0, 30, 60, 90])
      .tickFormat((d) => {
        if (d === 0) return 'Baseline (Day 0)';
        if (d === 30) return 'Phase 1: 30 Days';
        if (d === 60) return 'Phase 2: 60 Days';
        return 'Phase 3: 90 Days';
      });

    const yAxis = d3
      .axisLeft(yScale)
      .tickValues([0, 20, 40, 60, 80, 100])
      .tickFormat((d) => `${d}%`);

    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .attr('color', '#94a3b8')
      .selectAll('text')
      .attr('font-size', '11px')
      .attr('font-family', 'Plus Jakarta Sans, sans-serif')
      .attr('font-weight', '600')
      .attr('dy', '1.2em')
      .attr('fill', '#475569');

    g.append('g')
      .call(yAxis)
      .attr('color', '#cbd5e1')
      .selectAll('text')
      .attr('font-size', '11px')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-weight', '600')
      .attr('fill', '#64748b');

    // -------------------------------------------------------------
    // MODE 1: ROLE ALIGNMENT TRAJECTORY (CURVE + AREA + NODES)
    // -------------------------------------------------------------
    if (viewMode === 'trajectory') {
      const lineGenerator = d3
        .line<MilestoneData>()
        .x((d) => xScale(d.days))
        .y((d) => yScale(d.projectedScore))
        .curve(d3.curveMonotoneX);

      const areaGenerator = d3
        .area<MilestoneData>()
        .x((d) => xScale(d.days))
        .y0(innerHeight)
        .y1((d) => yScale(d.projectedScore))
        .curve(d3.curveMonotoneX);

      // Area Fill
      g.append('path')
        .datum(milestones)
        .attr('fill', 'url(#progressionAreaGradient)')
        .attr('d', areaGenerator);

      // Trajectory Path
      const path = g
        .append('path')
        .datum(milestones)
        .attr('fill', 'none')
        .attr('stroke', '#4f46e5')
        .attr('stroke-width', 3.5)
        .attr('d', lineGenerator);

      // Path length animation
      const totalLength = path.node()?.getTotalLength() || 0;
      path
        .attr('stroke-dasharray', `${totalLength} ${totalLength}`)
        .attr('stroke-dashoffset', totalLength)
        .transition()
        .duration(1100)
        .ease(d3.easeCubicOut)
        .attr('stroke-dashoffset', 0);

      // Milestone Nodes
      milestones.forEach((m, idx) => {
        const cx = xScale(m.days);
        const cy = yScale(m.projectedScore);
        const isSelected = m.id === selectedMilestoneId;

        const nodeGroup = g
          .append('g')
          .attr('class', 'milestone-node cursor-pointer')
          .attr('transform', `translate(${cx}, ${cy})`)
          .on('mouseenter', (event) => {
            const rect = container.getBoundingClientRect();
            setActiveTooltip({
              visible: true,
              x: event.clientX - rect.left,
              y: event.clientY - rect.top - 12,
              title: m.stageName,
              score: m.projectedScore,
              delta: m.scoreDelta,
              details: m.focus,
              subDetails: m.deliverable,
              skills: m.keySkills,
            });
          })
          .on('mouseleave', () => {
            setActiveTooltip((prev) => ({ ...prev, visible: false }));
          })
          .on('click', () => {
            setSelectedMilestoneId(m.id);
          });

        // Pulsing Outer Halo for selected node
        if (isSelected) {
          nodeGroup
            .append('circle')
            .attr('r', 16)
            .attr('fill', '#6366f1')
            .attr('opacity', 0.22)
            .attr('class', 'animate-pulse');
        }

        // Outer Circle
        nodeGroup
          .append('circle')
          .attr('r', isSelected ? 9 : 7)
          .attr('fill', '#ffffff')
          .attr('stroke', m.projectedScore >= 80 ? '#10b981' : '#4f46e5')
          .attr('stroke-width', isSelected ? 3.5 : 2.5)
          .attr('filter', 'url(#glow)');

        // Inner Circle
        nodeGroup
          .append('circle')
          .attr('r', isSelected ? 4 : 3)
          .attr('fill', m.projectedScore >= 80 ? '#10b981' : '#4f46e5');

        // Score Badge Above Node
        const badgeY = idx === 0 ? 22 : -18;
        const badgeGroup = nodeGroup.append('g').attr('transform', `translate(0, ${badgeY})`);

        badgeGroup
          .append('rect')
          .attr('x', -24)
          .attr('y', -10)
          .attr('width', 48)
          .attr('height', 18)
          .attr('rx', 9)
          .attr('fill', isSelected ? '#1e1b4b' : '#ffffff')
          .attr('stroke', isSelected ? '#4f46e5' : '#cbd5e1')
          .attr('stroke-width', 1.5)
          .attr('shadow', '0 1px 3px rgba(0,0,0,0.1)');

        badgeGroup
          .append('text')
          .attr('x', 0)
          .attr('y', 2.5)
          .attr('text-anchor', 'middle')
          .attr('fill', isSelected ? '#ffffff' : '#1e293b')
          .attr('font-size', '10px')
          .attr('font-family', 'JetBrains Mono, monospace')
          .attr('font-weight', '700')
          .text(`${m.projectedScore}%`);
      });
    }

    // -------------------------------------------------------------
    // MODE 2: MULTI-SKILL PROGRESSION PATHS
    // -------------------------------------------------------------
    if (viewMode === 'skills') {
      skillPaths.forEach((sp) => {
        const points = [
          { day: 0, val: sp.baseline },
          { day: 30, val: sp.day30 },
          { day: 60, val: sp.day60 },
          { day: 90, val: sp.day90 },
        ];

        const skillLine = d3
          .line<{ day: number; val: number }>()
          .x((d) => xScale(d.day))
          .y((d) => yScale(d.val))
          .curve(d3.curveMonotoneX);

        const isHighlighted = hoveredSkill === null || hoveredSkill === sp.skill;

        // Path
        g.append('path')
          .datum(points)
          .attr('fill', 'none')
          .attr('stroke', sp.color)
          .attr('stroke-width', hoveredSkill === sp.skill ? 3.5 : isHighlighted ? 2.5 : 1)
          .attr('opacity', isHighlighted ? 1 : 0.2)
          .attr('d', skillLine);

        // Nodes along path
        points.forEach((pt) => {
          const cx = xScale(pt.day);
          const cy = yScale(pt.val);

          g.append('circle')
            .attr('cx', cx)
            .attr('cy', cy)
            .attr('r', hoveredSkill === sp.skill ? 5.5 : 4)
            .attr('fill', '#ffffff')
            .attr('stroke', sp.color)
            .attr('stroke-width', 2)
            .attr('opacity', isHighlighted ? 1 : 0.2)
            .attr('class', 'cursor-pointer')
            .on('mouseenter', (event) => {
              setHoveredSkill(sp.skill);
              const rect = container.getBoundingClientRect();
              setActiveTooltip({
                visible: true,
                x: event.clientX - rect.left,
                y: event.clientY - rect.top - 12,
                title: `${sp.skill} Proficiency Trajectory`,
                score: pt.val,
                details: `Timeframe: Day ${pt.day} • Target Roadmap: ${sp.roadmapStage}`,
                subDetails: `Priority: ${sp.priority} (${sp.category} Requirement)`,
              });
            })
            .on('mouseleave', () => {
              setHoveredSkill(null);
              setActiveTooltip((prev) => ({ ...prev, visible: false }));
            });
        });
      });
    }
  }, [viewMode, milestones, skillPaths, selectedMilestoneId, hoveredSkill]);

  return (
    <div className={`bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-xs space-y-6 ${className}`}>
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-2xs font-bold font-mono tracking-wider uppercase bg-indigo-50 text-indigo-700 border border-indigo-200">
              <TrendingUp className="w-3 h-3 text-indigo-600" />
              <span>D3.js Dynamic Trajectory</span>
            </span>
            <span className="text-2xs text-slate-400 font-mono">Calibrated to 30-60-90 Roadmap</span>
          </div>

          <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Skill Progression Path & Readiness Curve</span>
          </h3>

          <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
            Visualizing your projected competency climb from current baseline{' '}
            <strong className="text-slate-800 font-mono">({baselineScore}%)</strong> to target qualification{' '}
            <strong className="text-emerald-700 font-mono">
              ({milestones[milestones.length - 1].projectedScore}% / +
              {milestones[milestones.length - 1].scoreDelta} pts)
            </strong>{' '}
            for {targetRole || 'your target role'} at {targetCompany || 'target companies'}.
          </p>
        </div>

        {/* View Mode Toggle Strip */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl self-start sm:self-center border border-slate-200/60">
          <button
            type="button"
            onClick={() => setViewMode('trajectory')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'trajectory'
                ? 'bg-white text-indigo-700 shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Role Alignment Curve</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('skills')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'skills'
                ? 'bg-white text-indigo-700 shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Gap Skills Horizons</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70">
          <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
            Current Resume Baseline
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-slate-900 font-mono">{baselineScore}%</span>
            <span className="text-2xs text-slate-500 font-medium">Starting Point</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-indigo-200 bg-indigo-50/40">
          <span className="text-3xs font-bold uppercase tracking-wider text-indigo-700 block mb-0.5">
            30-Day Foundation Jump
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-indigo-700 font-mono">
              {milestones[1].projectedScore}%
            </span>
            <span className="text-2xs font-bold text-emerald-600 font-mono">+{milestones[1].scoreDelta} pts</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/40">
          <span className="text-3xs font-bold uppercase tracking-wider text-emerald-700 block mb-0.5">
            90-Day Target Readiness
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-emerald-700 font-mono">
              {milestones[3].projectedScore}%
            </span>
            <span className="text-2xs font-bold text-emerald-600 font-mono">+{milestones[3].scoreDelta} pts</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl border border-purple-200 bg-purple-50/40">
          <span className="text-3xs font-bold uppercase tracking-wider text-purple-700 block mb-0.5">
            Target Benchmark (80%)
          </span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl sm:text-2xl font-black text-purple-700 font-mono">~45 Days</span>
            <span className="text-2xs text-slate-600 font-medium">to qualification</span>
          </div>
        </div>
      </div>

      {/* Interactive Legend for Skill Horizons Mode */}
      {viewMode === 'skills' && (
        <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs">
          <span className="text-2xs font-bold uppercase tracking-wider text-slate-500">
            Hover to isolate competency path:
          </span>
          {skillPaths.map((sp) => (
            <button
              key={sp.skill}
              type="button"
              onMouseEnter={() => setHoveredSkill(sp.skill)}
              onMouseLeave={() => setHoveredSkill(null)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                hoveredSkill === sp.skill
                  ? 'bg-white border-slate-400 shadow-2xs font-bold'
                  : 'bg-white/80 border-slate-200 text-slate-700 hover:bg-white'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sp.color }} />
              <span className="font-semibold text-slate-800">{sp.skill}</span>
              <span className="text-3xs font-mono text-slate-400">({sp.category})</span>
            </button>
          ))}
        </div>
      )}

      {/* D3 SVG Container with Absolute HTML Tooltip */}
      <div ref={containerRef} className="relative w-full overflow-hidden bg-white rounded-xl border border-slate-100">
        <svg ref={svgRef} className="w-full select-none" />

        {/* Floating Tooltip */}
        {activeTooltip.visible && (
          <div
            className="absolute z-30 pointer-events-none transform -translate-x-1/2 -translate-y-full mb-2 bg-slate-900/95 backdrop-blur-md text-white p-3 rounded-xl shadow-xl border border-slate-700/80 text-xs w-64 space-y-1.5 transition-all duration-75"
            style={{
              left: `${activeTooltip.x}px`,
              top: `${activeTooltip.y}px`,
            }}
          >
            <div className="flex items-center justify-between border-b border-slate-700/70 pb-1">
              <span className="font-bold text-slate-200 text-2xs truncate max-w-[170px]">
                {activeTooltip.title}
              </span>
              <span className="font-mono font-bold text-emerald-400 text-xs">
                {activeTooltip.score}%
              </span>
            </div>

            {activeTooltip.delta !== undefined && activeTooltip.delta > 0 && (
              <div className="text-3xs font-mono text-indigo-300 font-semibold">
                ▲ +{activeTooltip.delta} points progression from baseline
              </div>
            )}

            <p className="text-3xs text-slate-300 leading-snug">{activeTooltip.details}</p>

            {activeTooltip.subDetails && (
              <div className="text-3xs text-amber-200/90 pt-1 border-t border-slate-800">
                <strong>Deliverable:</strong> {activeTooltip.subDetails}
              </div>
            )}

            {activeTooltip.skills && activeTooltip.skills.length > 0 && (
              <div className="flex flex-wrap gap-1 pt-1">
                {activeTooltip.skills.map((s, i) => (
                  <span
                    key={i}
                    className="text-3xs px-1.5 py-0.5 rounded bg-slate-800 text-indigo-300 font-mono border border-slate-700"
                  >
                    {s}
                  </span>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Selected Milestone Inspection Panel */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-50 via-indigo-50/20 to-slate-50 rounded-xl border border-indigo-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-950 font-mono">
              Selected Phase Focus: {selectedMilestone.stageName}
            </span>
            <span className="text-2xs font-mono font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
              Projected: {selectedMilestone.projectedScore}%
            </span>
          </div>

          <p className="text-xs text-slate-700 leading-relaxed max-w-3xl">
            {selectedMilestone.summary}
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-1 text-2xs">
            <span className="font-bold text-slate-600">Priority Competencies Targeted:</span>
            {selectedMilestone.keySkills.map((sk, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-indigo-900 font-medium font-mono"
              >
                {sk}
              </span>
            ))}
          </div>
        </div>

        {onExploreRoadmap && (
          <button
            type="button"
            onClick={onExploreRoadmap}
            className="px-4 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <span>Execute 30-60-90 Roadmap</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
