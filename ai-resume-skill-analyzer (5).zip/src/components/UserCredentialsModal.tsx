import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth, UserCredentials } from '../context/AuthContext';
import { POPULAR_ROLES, SENIORITY_LEVELS } from '../data/jobRoles';
import { TOP_COMPANIES } from '../data/companies';
import { AnalysisReport } from '../types/analyzer';
import {
  X,
  User,
  Mail,
  ShieldCheck,
  Briefcase,
  Building,
  Calendar,
  Link,
  Github,
  Linkedin,
  Globe,
  FileText,
  Save,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Database,
  Sparkles,
  LogIn,
  LogOut,
  Lock,
  AlertCircle,
  Loader2,
} from 'lucide-react';

interface UserCredentialsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadSavedReport?: (report: AnalysisReport) => void;
  onApplyCredentialsToForm?: (creds: {
    role: string;
    company: string;
    level: string;
  }) => void;
}

export const UserCredentialsModal: React.FC<UserCredentialsModalProps> = ({
  isOpen,
  onClose,
  onLoadSavedReport,
  onApplyCredentialsToForm,
}) => {
  const {
    currentUser,
    credentials,
    savedAnalyses,
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    signOut,
    saveCredentials,
    deleteAnalysisFromCloud,
  } = useAuth();

  const [authMode, setAuthMode] = useState<'signin' | 'register'>('signin');
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authDisplayName, setAuthDisplayName] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  const [activeTab, setActiveTab] = useState<'profile' | 'history'>('profile');
  const [role, setRole] = useState(credentials?.targetRole || 'Software Engineer');
  const [company, setCompany] = useState(credentials?.targetCompany || 'Google');
  const [seniority, setSeniority] = useState(credentials?.experienceLevel || '2–4 Years');
  const [linkedin, setLinkedin] = useState(credentials?.linkedinUrl || '');
  const [github, setGithub] = useState(credentials?.githubUrl || '');
  const [portfolio, setPortfolio] = useState(credentials?.portfolioUrl || '');
  const [summary, setSummary] = useState(credentials?.careerSummary || '');

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (credentials) {
      if (credentials.targetRole) setRole(credentials.targetRole);
      if (credentials.targetCompany) setCompany(credentials.targetCompany);
      if (credentials.experienceLevel) setSeniority(credentials.experienceLevel);
      if (credentials.linkedinUrl) setLinkedin(credentials.linkedinUrl);
      if (credentials.githubUrl) setGithub(credentials.githubUrl);
      if (credentials.portfolioUrl) setPortfolio(credentials.portfolioUrl);
      if (credentials.careerSummary) setSummary(credentials.careerSummary);
    }
  }, [credentials]);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setIsSaving(true);
    setErrorMsg('');
    try {
      const payload: UserCredentials = {
        targetRole: role,
        targetCompany: company,
        experienceLevel: seniority,
        linkedinUrl: linkedin,
        githubUrl: github,
        portfolioUrl: portfolio,
        careerSummary: summary,
      };
      const ok = await saveCredentials(payload);
      if (ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } else {
        setErrorMsg('Failed to persist credentials to Cloud SQL.');
      }
    } catch {
      setErrorMsg('Network error saving credentials.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleApplyToForm = () => {
    if (onApplyCredentialsToForm) {
      onApplyCredentialsToForm({
        role,
        company,
        level: seniority,
      });
      onClose();
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (!authEmail.trim() || !authPassword.trim()) {
      setAuthError('Please provide both email address and password.');
      return;
    }

    if (authPassword.length < 6) {
      setAuthError('Password must be at least 6 characters long.');
      return;
    }

    setAuthLoading(true);
    try {
      if (authMode === 'signin') {
        const res = await signInWithEmail(authEmail.trim(), authPassword);
        if (!res.success) {
          setAuthError(res.error || 'Failed to authenticate.');
        } else {
          setAuthPassword('');
          setAuthError('');
        }
      } else {
        const res = await signUpWithEmail(authEmail.trim(), authPassword, authDisplayName.trim());
        if (!res.success) {
          setAuthError(res.error || 'Failed to register account.');
        } else {
          setAuthPassword('');
          setAuthError('');
        }
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthError('');
    setAuthLoading(true);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      if (
        err?.code === 'auth/unauthorized-domain' ||
        err?.message?.includes('unauthorized domain')
      ) {
        setAuthError(
          'Google popup authentication is restricted on this domain. Please log in or register with your email and password above.'
        );
      } else if (err?.code === 'auth/popup-blocked') {
        setAuthError('Browser popup was blocked. Please log in using email and password above.');
      } else {
        setAuthError(err?.message || 'Google Sign-In failed. Please use email and password.');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xs">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-indigo-50/30">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                <Database className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span>Candidate Career Credentials & Cloud Vault</span>
                </h3>
                <p className="text-2xs text-slate-500">
                  Backed by Cloud SQL PostgreSQL and Secure User Authentication
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1">
            {!currentUser ? (
              /* Unauthenticated View: Email/Password & Social Auth */
              <div className="py-2 space-y-5 max-w-md mx-auto">
                <div className="text-center space-y-1.5">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 mx-auto flex items-center justify-center shadow-2xs">
                    <ShieldCheck className="w-7 h-7" />
                  </div>
                  <h4 className="text-base font-bold text-slate-900">
                    {authMode === 'signin' ? 'Sign In to Your Account' : 'Create Free Candidate Account'}
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    {authMode === 'signin'
                      ? 'Enter your credentials to access your saved resume evaluations, career targets, and Cloud SQL vault.'
                      : 'Register to store private target job profiles, resume evaluations, and career roadmaps.'}
                  </p>
                </div>

                {/* Auth Mode Toggle Pill */}
                <div className="flex bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('signin');
                      setAuthError('');
                    }}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      authMode === 'signin'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode('register');
                      setAuthError('');
                    }}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      authMode === 'register'
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Register
                  </button>
                </div>

                {authError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <span className="leading-relaxed">{authError}</span>
                  </div>
                )}

                <form onSubmit={handleAuthSubmit} className="space-y-3.5">
                  {authMode === 'register' && (
                    <div className="space-y-1">
                      <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                        Full Name (Optional)
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={authDisplayName}
                          onChange={(e) => setAuthDisplayName(e.target.value)}
                          placeholder="e.g. Alex Morgan"
                          className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-none"
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="email"
                        required
                        value={authEmail}
                        onChange={(e) => setAuthEmail(e.target.value)}
                        placeholder="candidate@example.com"
                        className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                        Password
                      </label>
                      {authMode === 'register' && (
                        <span className="text-3xs text-slate-400">Min. 6 characters</span>
                      )}
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="password"
                        required
                        minLength={6}
                        value={authPassword}
                        onChange={(e) => setAuthPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={authLoading}
                    className="w-full py-2.5 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-indigo-600 disabled:opacity-50 rounded-xl shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    {authLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Authenticating...</span>
                      </>
                    ) : (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>{authMode === 'signin' ? 'Sign In to Vault' : 'Create Free Account'}</span>
                      </>
                    )}
                  </button>
                </form>

                {/* Divider */}
                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-200"></div>
                  <span className="flex-shrink mx-3 text-2xs font-bold uppercase tracking-wider text-slate-400">
                    Or
                  </span>
                  <div className="flex-grow border-t border-slate-200"></div>
                </div>

                {/* Google Sign In Option */}
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={authLoading}
                  className="w-full inline-flex items-center justify-center gap-2.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-2xs transition-all cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>
              </div>
            ) : (
              /* Authenticated View */
              <div className="space-y-6">
                {/* User Info Bar */}
                <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200/80 rounded-2xl">
                  <div className="flex items-center gap-3">
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt={currentUser.displayName || 'User'}
                        className="w-10 h-10 rounded-full border border-slate-200"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                        {currentUser.displayName ? currentUser.displayName[0] : 'U'}
                      </div>
                    )}
                    <div>
                      <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <span>{currentUser.displayName || 'Logged-In User'}</span>
                        <span className="text-3xs font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                          Verified
                        </span>
                      </div>
                      <div className="text-2xs text-slate-500">{currentUser.email}</div>
                    </div>
                  </div>

                  <button
                    onClick={signOut}
                    className="px-3 py-1.5 text-2xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <button
                    onClick={() => setActiveTab('profile')}
                    className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                      activeTab === 'profile'
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    Target Career Credentials
                  </button>
                  <button
                    onClick={() => setActiveTab('history')}
                    className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'history'
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <span>Saved Cloud Reports</span>
                    <span className="text-2xs font-mono px-1.5 py-0.2 rounded-full bg-white/20">
                      {savedAnalyses.length}
                    </span>
                  </button>
                </div>

                {activeTab === 'profile' ? (
                  <form onSubmit={handleSave} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                          Target Role
                        </label>
                        <select
                          value={role}
                          onChange={(e) => setRole(e.target.value)}
                          className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                        >
                          {POPULAR_ROLES.map((r) => (
                            <option key={r} value={r}>
                              {r}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                          Target Company
                        </label>
                        <select
                          value={company}
                          onChange={(e) => setCompany(e.target.value)}
                          className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                        >
                          {TOP_COMPANIES.map((c) => (
                            <option key={c.name} value={c.name}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                          Seniority Level
                        </label>
                        <select
                          value={seniority}
                          onChange={(e) => setSeniority(e.target.value)}
                          className="w-full text-xs font-semibold text-slate-900 bg-slate-50 border border-slate-200 rounded-xl p-2.5 focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                        >
                          {SENIORITY_LEVELS.slice(1, 9).map((lvl) => (
                            <option key={lvl} value={lvl}>
                              {lvl}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Social & Portfolio Credentials */}
                    <div className="space-y-3 pt-2">
                      <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block">
                        Professional Profiles & Portfolios
                      </span>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="relative">
                          <Linkedin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="url"
                            value={linkedin}
                            onChange={(e) => setLinkedin(e.target.value)}
                            placeholder="https://linkedin.com/in/username"
                            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </div>

                        <div className="relative">
                          <Github className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="url"
                            value={github}
                            onChange={(e) => setGithub(e.target.value)}
                            placeholder="https://github.com/username"
                            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="relative">
                        <Globe className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="url"
                          value={portfolio}
                          onChange={(e) => setPortfolio(e.target.value)}
                          placeholder="Personal Portfolio / Website URL (e.g., https://janedoe.dev)"
                          className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Summary */}
                    <div className="space-y-1 pt-1">
                      <label className="text-2xs font-bold uppercase tracking-wider text-slate-500">
                        Candidate Elevator Pitch & Professional Focus
                      </label>
                      <textarea
                        rows={3}
                        value={summary}
                        onChange={(e) => setSummary(e.target.value)}
                        placeholder="e.g., Senior Full-Stack Engineer with 5+ years of experience in distributed TypeScript services, React, and cloud migrations..."
                        className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                      />
                    </div>

                    {errorMsg && (
                      <p className="text-xs text-rose-600 bg-rose-50 p-2.5 rounded-xl border border-rose-200">
                        {errorMsg}
                      </p>
                    )}

                    {saveSuccess && (
                      <p className="text-xs text-emerald-700 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Credentials saved to Cloud SQL PostgreSQL database!</span>
                      </p>
                    )}

                    {/* Actions */}
                    <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={handleApplyToForm}
                        className="px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Apply Credentials to Target Role Form</span>
                      </button>

                      <button
                        type="submit"
                        disabled={isSaving}
                        className="px-5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{isSaving ? 'Saving to Database...' : 'Save Credentials'}</span>
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Saved Analyses Tab */
                  <div className="space-y-3">
                    {savedAnalyses.length === 0 ? (
                      <div className="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200/60 p-4 space-y-2">
                        <FileText className="w-8 h-8 text-slate-300 mx-auto" />
                        <p className="text-xs font-bold text-slate-700">No Saved Reports Yet</p>
                        <p className="text-2xs text-slate-500 max-w-sm mx-auto">
                          Whenever you analyze a resume, you can click "Save to Cloud Database" to store the evaluation in your PostgreSQL database.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
                        {savedAnalyses.map((item) => (
                          <div
                            key={item.id}
                            className="p-3.5 bg-slate-50 hover:bg-slate-100/80 rounded-2xl border border-slate-200/80 flex items-center justify-between gap-3 transition-colors"
                          >
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-xs text-slate-900">
                                  {item.targetRole}
                                </span>
                                <span className="text-2xs text-slate-500">at {item.targetCompany}</span>
                              </div>
                              <div className="flex items-center gap-2 text-2xs text-slate-500">
                                <span className="font-mono font-bold text-indigo-600">
                                  {item.totalScore}/100
                                </span>
                                <span>·</span>
                                <span>{item.alignmentLevel}</span>
                                <span>·</span>
                                <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              {item.report && onLoadSavedReport && (
                                <button
                                  onClick={() => {
                                    onLoadSavedReport(item.report!);
                                    onClose();
                                  }}
                                  className="px-3 py-1.5 text-2xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors cursor-pointer"
                                >
                                  Load Report
                                </button>
                              )}
                              <button
                                onClick={() => deleteAnalysisFromCloud(item.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Delete from Cloud SQL"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
