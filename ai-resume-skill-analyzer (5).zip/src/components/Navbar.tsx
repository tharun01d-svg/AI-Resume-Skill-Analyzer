import React from 'react';
import { History, Sparkles, HelpCircle, User, ShieldCheck, Database } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  currentTab: 'landing' | 'analyzer' | 'results';
  onNavigate: (tab: 'landing' | 'analyzer' | 'results') => void;
  onOpenHistory: () => void;
  onOpenFormula: () => void;
  onLoadSample: () => void;
  onOpenCredentials: () => void;
  hasActiveReport: boolean;
  historyCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onNavigate,
  onOpenHistory,
  onOpenFormula,
  onLoadSample,
  onOpenCredentials,
  hasActiveReport,
  historyCount,
}) => {
  const { currentUser, signInWithGoogle, loading } = useAuth();
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Brand title, single text element wordmark */}
        <button
          onClick={() => onNavigate('landing')}
          className="text-left group flex items-center gap-2 cursor-pointer focus-visible:outline-none"
        >
          <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-tight shadow-sm group-hover:bg-indigo-600 transition-colors">
            RA
          </div>
          <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors">
            AI Resume Skill Analyzer
          </span>
        </button>

        {/* Zone 2: 4-6 nav links with smooth active indicator transition */}
        <nav className="hidden md:flex items-center gap-2 text-sm font-medium text-slate-600">
          <button
            onClick={() => onNavigate('landing')}
            className={`relative px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentTab === 'landing' ? 'text-slate-950 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {currentTab === 'landing' && (
              <motion.span
                layoutId="nav-active-pill"
                className="absolute inset-0 bg-slate-100 rounded-lg -z-10 shadow-2xs"
                transition={{ type: 'spring', stiffness: 420, damping: 32 }}
              />
            )}
            Overview
          </button>

          <button
            onClick={() => onNavigate('analyzer')}
            className={`relative px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
              currentTab === 'analyzer' ? 'text-slate-950 font-semibold' : 'hover:text-slate-900'
            }`}
          >
            {currentTab === 'analyzer' && (
              <motion.span
                layoutId="nav-active-pill"
                className="absolute inset-0 bg-slate-100 rounded-lg -z-10 shadow-2xs"
                transition={{ type: 'spring', stiffness: 420, damping: 32 }}
              />
            )}
            Analyzer Workspace
          </button>

          {hasActiveReport && (
            <button
              onClick={() => onNavigate('results')}
              className={`relative px-3.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                currentTab === 'results' ? 'text-indigo-700 font-semibold' : 'hover:text-slate-900'
              }`}
            >
              {currentTab === 'results' && (
                <motion.span
                  layoutId="nav-active-pill"
                  className="absolute inset-0 bg-indigo-50 border border-indigo-200/60 rounded-lg -z-10 shadow-2xs"
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                />
              )}
              Current Analysis
            </button>
          )}

          <button
            onClick={onOpenFormula}
            className="px-3 py-1.5 rounded-lg transition-colors hover:bg-slate-50 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-slate-400" />
            <span>Score Model</span>
          </button>

          <button
            onClick={onLoadSample}
            className="px-3 py-1.5 rounded-lg transition-colors hover:bg-slate-50 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Sample Roles</span>
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenCredentials}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 border ${
              currentUser
                ? 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
            }`}
            title="Candidate Credentials & Cloud Database"
          >
            {currentUser ? (
              <>
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.displayName || 'User'}
                    className="w-4 h-4 rounded-full"
                  />
                ) : (
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                )}
                <span className="max-w-[100px] truncate hidden sm:inline">
                  {currentUser.displayName?.split(' ')[0] || 'My Profile'}
                </span>
                <span className="text-3xs font-mono font-bold text-emerald-600 bg-emerald-100/60 px-1 rounded">
                  DB
                </span>
              </>
            ) : (
              <>
                <Database className="w-3.5 h-3.5 text-indigo-600" />
                <span>Credentials & Login</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenHistory}
            className="relative px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Past Analysis History"
          >
            <History className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline">History</span>
            {historyCount > 0 && (
              <span className="ml-0.5 text-xs text-slate-500 font-mono tabular-nums">
                ({historyCount})
              </span>
            )}
          </button>

          <button
            onClick={() => onNavigate('analyzer')}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-indigo-600 rounded-lg transition-colors shadow-sm cursor-pointer whitespace-nowrap"
          >
            Analyze Resume
          </button>
        </div>
      </div>
    </header>
  );
};
