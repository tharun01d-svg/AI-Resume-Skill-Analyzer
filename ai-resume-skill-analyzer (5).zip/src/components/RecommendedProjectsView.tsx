import React from 'react';
import { ProjectRecommendation } from '../types/analyzer';
import { Layers, CheckCircle2, ArrowUpRight, Code, Sparkles } from 'lucide-react';

interface RecommendedProjectsViewProps {
  projects: ProjectRecommendation[];
}

export const RecommendedProjectsView: React.FC<RecommendedProjectsViewProps> = ({ projects }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs space-y-6">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-indigo-600" />
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Gap-Closing Portfolio Projects
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Engineered specifically to supply demonstrable evidence for your highest-priority missing skills.
            </p>
          </div>
        </div>
      </div>

      {(!projects || projects.length === 0) ? (
        <p className="text-xs text-slate-500 italic p-6 text-center">
          No missing project requirements detected for this role.
        </p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((proj, idx) => (
            <div
              key={idx}
              className="p-5 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-white border border-slate-200 text-indigo-600 flex items-center justify-center text-xs font-mono font-bold shadow-2xs">
                      {idx + 1}
                    </span>
                    {proj.project}
                  </h4>
                  <span
                    className={`text-2xs font-semibold px-2 py-0.5 rounded border shrink-0 ${
                      proj.difficulty === 'Advanced'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : proj.difficulty === 'Intermediate'
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}
                  >
                    {proj.difficulty}
                  </span>
                </div>

                <div className="mb-3 text-2xs text-indigo-700 bg-indigo-50/70 px-2.5 py-1 rounded border border-indigo-100 font-medium">
                  <strong>Targets Requirement:</strong> {proj.target_requirement}
                </div>

                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  {proj.reason}
                </p>

                {/* Features to Build */}
                {proj.features && proj.features.length > 0 && (
                  <div className="mb-4 space-y-1.5 bg-white p-3 rounded-lg border border-slate-200/80">
                    <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block">
                      Core Implementation Deliverables:
                    </span>
                    <ul className="space-y-1 text-2xs text-slate-700">
                      {proj.features.map((feat, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Skills Demonstrated Footer */}
              <div className="pt-3 border-t border-slate-200/60 mt-2">
                <span className="text-2xs text-slate-500 block mb-1 font-medium">
                  Key Technologies & Skills Proven:
                </span>
                <div className="flex flex-wrap gap-1">
                  {proj.skills.map((skill, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-2xs bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-800 font-mono"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
