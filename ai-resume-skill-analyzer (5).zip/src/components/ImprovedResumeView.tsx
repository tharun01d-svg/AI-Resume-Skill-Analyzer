import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { fadeUpVariants } from '../utils/motion';
import { ResumeData, JobData, ImprovedResumeModel } from '../types/analyzer';
import {
  Sparkles,
  Download,
  Printer,
  Edit3,
  Check,
  RotateCcw,
  Eye,
  Columns,
  Layers,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';

interface ImprovedResumeViewProps {
  resume: ResumeData;
  job: JobData;
  targetCompany?: string;
  targetRole?: string;
}

export const ImprovedResumeView: React.FC<ImprovedResumeViewProps> = ({
  resume,
  job,
  targetCompany,
  targetRole,
}) => {
  const model = resume.improved_resume;
  const candidate = resume.candidate;

  // Working state initialized from model
  const [headerName, setHeaderName] = useState(model?.header.name || candidate.name || 'Candidate Name');
  const [headerTitle, setHeaderTitle] = useState(model?.header.title || candidate.professional_title || job.job_title || 'Software Engineer');
  const [headerEmail, setHeaderEmail] = useState(model?.header.email || candidate.email || 'candidate@example.com');
  const [headerPhone, setHeaderPhone] = useState(model?.header.phone || candidate.phone || '+1 (555) 019-2834');
  const [headerLocation, setHeaderLocation] = useState(model?.header.location || candidate.location || 'San Francisco, CA');
  const [headerLinkedin, setHeaderLinkedin] = useState(model?.header.linkedin || candidate.linkedin || '');
  const [headerGithub, setHeaderGithub] = useState(model?.header.github || candidate.github || '');
  const [summary, setSummary] = useState(
    model?.professional_summary ||
      resume.summary_analysis?.improved_summary ||
      resume.professional_summary ||
      ''
  );

  // Experience roles and bullets
  const [experience, setExperience] = useState(
    model?.experience && model.experience.length > 0
      ? model.experience
      : (resume.detailed_work_analysis || []).map((w) => ({
          role: w.role,
          company: w.company,
          duration: w.duration,
          location: 'San Francisco, CA',
          bullets: w.bullets.map((b) => b.improved_version),
        }))
  );

  // Projects
  const [projects, setProjects] = useState(
    model?.projects && model.projects.length > 0
      ? model.projects
      : (resume.projects || []).map((p) => ({
          name: p.name,
          technologies: p.technologies,
          problem_solved: p.problem_solved,
          bullets: [
            p.description,
            p.outcome ? `Outcome: ${p.outcome}` : `Integrated ${p.technologies.slice(0, 3).join(', ')} with automated unit test suites.`,
          ],
        }))
  );

  // Categorized Skills
  const [skillsGrouped, setSkillsGrouped] = useState<Record<string, string[]>>(
    model?.skills_categorized || {
      'Programming Languages': resume.categorized_skills?.programming_languages || ['Python', 'TypeScript', 'SQL'],
      'Frameworks & Libraries': resume.categorized_skills?.frameworks || ['React', 'Node.js', 'FastAPI'],
      'Databases & Storage': resume.categorized_skills?.databases || ['PostgreSQL', 'Redis'],
      'Cloud & DevOps': (resume.categorized_skills?.cloud || []).concat(resume.categorized_skills?.devops || []).slice(0, 6),
      'Tools & Methodologies': ['Docker', 'Git', 'CI/CD Automation', 'RESTful APIs', 'Agile / Scrum'],
    }
  );

  // View mode: 'improved' | 'diff' | 'original'
  const [viewMode, setViewMode] = useState<'improved' | 'diff' | 'original'>('improved');
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [pdfStage, setPdfStage] = useState<'idle' | 'formatting' | 'generating' | 'finalizing' | 'ready'>('idle');
  const [isEditing, setIsEditing] = useState(false);

  const resumePrintRef = useRef<HTMLDivElement>(null);

  // PDF Generation using html2canvas-pro & jsPDF with multi-stage progress (Requirement #24)
  const handleDownloadPDF = async () => {
    if (!resumePrintRef.current) return;
    setIsDownloading(true);
    setDownloadSuccess(false);
    setPdfStage('formatting');

    try {
      const element = resumePrintRef.current;
      const canvas = await html2canvas(element, {
        scale: 2, // High resolution
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      setPdfStage('generating');
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'letter',
      });

      const pageWidth = 612; // Letter width in pt
      const pageHeight = 792; // Letter height in pt
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      if (imgHeight <= pageHeight) {
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
      } else {
        let heightLeft = imgHeight;
        let position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft > 0) {
          position -= pageHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
      }

      setPdfStage('finalizing');
      const sanitizedName = (headerName || 'Candidate').replace(/[^a-zA-Z0-9_-]/g, '_');
      pdf.save(`${sanitizedName}_Improved_Resume.pdf`);

      setPdfStage('ready');
      setDownloadSuccess(true);
      setTimeout(() => {
        setDownloadSuccess(false);
        setPdfStage('idle');
      }, 3000);
    } catch (err) {
      console.error('PDF export error:', err);
      // Fallback: browser print dialog
      window.print();
      setPdfStage('idle');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-6 pb-8">
      {/* 1. Header Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-indigo-600">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Resume Intelligence & Rewrite Engine</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 mt-1">
            Generated Improved Resume & Live Preview
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Strictly grounded in your actual experience. Formatted with executive typography and universal ATS compliance.
          </p>
        </div>

        {/* View Switcher & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* View Mode Toggle */}
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('improved')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'improved'
                  ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Improved</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('diff')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'diff'
                  ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>Review Changes</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('original')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'original'
                  ? 'bg-white text-indigo-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Original</span>
            </button>
          </div>

          {/* Edit Mode Toggle */}
          <button
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors flex items-center gap-1.5 cursor-pointer ${
              isEditing
                ? 'bg-amber-50 text-amber-900 border-amber-300'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>{isEditing ? 'Editing Mode Active' : 'Tweak Text'}</span>
          </button>

          {/* Download PDF Button */}
          <button
            type="button"
            onClick={handleDownloadPDF}
            disabled={isDownloading}
            className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isDownloading ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span className="font-mono">
                  {pdfStage === 'formatting' && 'Formatting resume...'}
                  {pdfStage === 'generating' && 'Generating PDF...'}
                  {pdfStage === 'finalizing' && 'Finalizing document...'}
                  {pdfStage === 'ready' && 'Ready!'}
                  {pdfStage === 'idle' && 'Preparing PDF...'}
                </span>
              </>
            ) : downloadSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-300" />
                <span>PDF Downloaded!</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download PDF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. Review Changes Diff View (if active) */}
      {viewMode === 'diff' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h4 className="text-base font-bold text-slate-900">
                Side-by-Side Review of Enhancements
              </h4>
              <p className="text-xs text-slate-500">
                Compare original candidate phrasing with optimized action-oriented wording.
              </p>
            </div>
            <span className="text-2xs font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-100">
              Grounded Improvements
            </span>
          </div>

          {/* Summary Diff */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Professional Summary Transformation
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-rose-50/40 border border-rose-200 rounded-xl">
                <span className="text-3xs font-bold uppercase text-rose-700 block mb-1">ORIGINAL SUMMARY</span>
                <p className="italic text-slate-700 leading-relaxed">
                  "{resume.professional_summary || 'Generic overview without explicit cloud specialization.'}"
                </p>
              </div>
              <div className="p-4 bg-emerald-50/50 border border-emerald-300 rounded-xl">
                <span className="text-3xs font-bold uppercase text-emerald-800 block mb-1">IMPROVED SUMMARY (ATS-OPTIMIZED)</span>
                <p className="font-medium text-slate-900 leading-relaxed">
                  "{summary}"
                </p>
              </div>
            </div>
          </div>

          {/* Bullet Diffs */}
          <div className="space-y-3 pt-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Work Experience Bullet Transformations
            </span>
            {(resume.detailed_work_analysis?.[0]?.bullets || []).map((b, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs p-3.5 bg-slate-50/50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-3xs font-bold uppercase text-rose-700 block mb-1">CURRENT PHRASING</span>
                  <p className="text-slate-700 italic">"{b.current}"</p>
                  <p className="text-2xs text-rose-600 mt-2"><strong>Critique:</strong> {b.problem}</p>
                </div>
                <div>
                  <span className="text-3xs font-bold uppercase text-emerald-800 block mb-1">GOOGLE X-Y-Z UPGRADE</span>
                  <p className="text-slate-900 font-medium">"{b.improved_version}"</p>
                  <p className="text-2xs text-emerald-700 mt-2"><strong>Advantage:</strong> Eliminates passive verbs; highlights architectural depth.</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Original View (if active) */}
      {viewMode === 'original' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h4 className="text-base font-bold text-slate-900">
              Original Extracted Resume Text
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              Raw Extracted Content
            </span>
          </div>
          <pre className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed max-h-96 overflow-y-auto">
            {resume.responsibilities?.length
              ? `${candidate.name}\n${candidate.email} · ${candidate.phone} · ${candidate.location}\n\nSUMMARY\n${resume.professional_summary}\n\nEXPERIENCE\n${resume.work_experience?.map((w) => `${w.role} at ${w.company} (${w.duration})\n${w.responsibilities.map((r) => `• ${r}`).join('\n')}`).join('\n\n')}\n\nSKILLS\n${resume.technical_skills.join(', ')}`
              : 'Original resume content.'}
          </pre>
        </div>
      )}

      {/* 4. Live Interactive Resume Preview (Primary Canvas) */}
      <div className="bg-slate-200/70 p-4 sm:p-8 rounded-2xl shadow-inner flex justify-center">
        <div
          ref={resumePrintRef}
          className="bg-white text-slate-900 w-full max-w-[800px] min-h-[1050px] p-8 sm:p-12 shadow-xl rounded-sm border border-slate-200 print:border-none print:shadow-none print:p-0"
          style={{ fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}
        >
          {/* Resume Header */}
          <header className="border-b-2 border-slate-900 pb-5 mb-5 text-center sm:text-left flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              {isEditing ? (
                <input
                  type="text"
                  value={headerName}
                  onChange={(e) => setHeaderName(e.target.value)}
                  className="text-2xl font-black text-slate-900 border-b border-indigo-500 focus:outline-none w-full"
                />
              ) : (
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 uppercase">
                  {headerName}
                </h1>
              )}

              {isEditing ? (
                <input
                  type="text"
                  value={headerTitle}
                  onChange={(e) => setHeaderTitle(e.target.value)}
                  className="text-sm font-bold text-indigo-600 border-b border-indigo-400 focus:outline-none mt-1 w-full"
                />
              ) : (
                <p className="text-sm font-bold text-indigo-700 tracking-wide mt-1 uppercase">
                  {headerTitle}
                </p>
              )}
            </div>

            {/* Contact Metadata */}
            <div className="text-xs text-slate-600 space-y-1 sm:text-right">
              <p>{headerEmail} · {headerPhone}</p>
              <p>{headerLocation}</p>
              <div className="flex items-center sm:justify-end gap-2 text-indigo-600 font-mono text-2xs">
                {headerLinkedin && <span>{headerLinkedin.replace(/^https?:\/\//, '')}</span>}
                {headerGithub && <span>· {headerGithub.replace(/^https?:\/\//, '')}</span>}
              </div>
            </div>
          </header>

          {/* Resume Body */}
          <div className="space-y-5 text-xs text-slate-800 leading-relaxed">
            {/* Section 1: Professional Summary */}
            <section>
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-widest border-b border-slate-300 pb-1 mb-2">
                Professional Summary
              </h2>
              {isEditing ? (
                <textarea
                  rows={3}
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  className="w-full text-xs p-2 border border-indigo-300 rounded font-sans focus:outline-none"
                />
              ) : (
                <p className="text-slate-700 leading-relaxed text-justify">
                  {summary}
                </p>
              )}
            </section>

            {/* Section 2: Technical Skills & Core Competencies */}
            <section>
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-widest border-b border-slate-300 pb-1 mb-2">
                Technical Skills & Competencies
              </h2>
              <div className="space-y-1.5">
                {Object.entries(skillsGrouped).map(([categoryName, skillList]) => (
                  <div key={categoryName} className="flex items-baseline gap-2">
                    <span className="font-bold text-slate-900 shrink-0 w-44">
                      {categoryName}:
                    </span>
                    <span className="text-slate-700">
                      {skillList.join(', ')}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* Section 3: Professional Experience */}
            <section>
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-widest border-b border-slate-300 pb-1 mb-3">
                Professional Experience
              </h2>
              <div className="space-y-4">
                {experience.map((role, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between font-bold text-slate-900">
                      <div className="text-xs">
                        <span>{role.role}</span>
                        <span className="text-indigo-700 font-semibold"> · {role.company}</span>
                      </div>
                      <span className="text-2xs font-mono text-slate-500 font-normal">
                        {role.duration}
                      </span>
                    </div>

                    <ul className="space-y-1 pl-4 list-disc text-slate-700 marker:text-slate-400">
                      {role.bullets.map((bulletText, bIdx) => (
                        <li key={bIdx} className="leading-snug pl-1">
                          {isEditing ? (
                            <textarea
                              rows={2}
                              value={bulletText}
                              onChange={(e) => {
                                const updatedExp = [...experience];
                                updatedExp[idx].bullets[bIdx] = e.target.value;
                                setExperience(updatedExp);
                              }}
                              className="w-full text-xs p-1 border border-indigo-200 rounded font-sans focus:outline-none"
                            />
                          ) : (
                            <span>{bulletText}</span>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>

            {/* Section 4: Key Technical Projects */}
            <section>
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-widest border-b border-slate-300 pb-1 mb-3">
                Technical Projects
              </h2>
              <div className="space-y-3">
                {projects.map((proj, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between font-bold text-slate-900">
                      <span className="text-xs">{proj.name}</span>
                      <span className="text-2xs font-mono text-slate-500 font-normal">
                        {proj.technologies.slice(0, 4).join(', ')}
                      </span>
                    </div>

                    <ul className="space-y-0.5 pl-4 list-disc text-slate-700 marker:text-slate-400">
                      {proj.bullets.map((b, bIdx) => (
                        <li key={bIdx} className="leading-snug pl-1">
                          {b}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>

            {/* Section 5: Education & Certifications */}
            <section>
              <h2 className="text-xs font-black text-slate-900 uppercase tracking-widest border-b border-slate-300 pb-1 mb-2">
                Education & Certifications
              </h2>
              <div className="space-y-2">
                {(resume.education || []).map((e, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-900">{e.degree} {e.field ? `in ${e.field}` : ''}</span>
                      <span className="text-slate-600"> — {e.institution}</span>
                    </div>
                    <span className="text-2xs font-mono text-slate-500">{e.graduation_year || '2021'}</span>
                  </div>
                ))}

                {resume.certifications && resume.certifications.length > 0 && (
                  <div className="pt-1 text-2xs text-slate-600">
                    <strong className="text-slate-900">Certifications:</strong> {resume.certifications.join(' · ')}
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};
