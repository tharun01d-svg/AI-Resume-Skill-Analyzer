import React from 'react';
import { RecommendationData } from '../types/analyzer';
import { Calendar, Target, CheckCircle2, ArrowRight, Lightbulb, Compass, Award } from 'lucide-react';

interface LearningRoadmapViewProps {
  recommendations: RecommendationData;
}

export const LearningRoadmapView: React.FC<LearningRoadmapViewProps> = ({ recommendations }) => {
  const { top_priorities, learning_roadmap, career_stage_advice } = recommendations;

  return (
    <div className="space-y-6">
      {/* 1. Top Strategic Priorities (Ranked) */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-5">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Top Priority Skill Objectives
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Ranked by requirement frequency, mandatory status, and direct return-on-effort for this job.
              </p>
            </div>
          </div>
        </div>

        {(!top_priorities || top_priorities.length === 0) ? (
          <p className="text-xs text-slate-500 italic p-4 text-center">
            No severe skill gaps detected. Focus on deepening existing competencies.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {top_priorities.map((item, idx) => (
              <div
                key={idx}
                className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="font-bold text-sm text-slate-900">
                      {idx + 1}. {item.skill}
                    </span>
                    <span
                      className={`text-2xs font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                        item.priority === 'HIGH'
                          ? 'bg-rose-50 text-rose-700 border-rose-200'
                          : item.priority === 'MEDIUM'
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {item.priority}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 mb-3 leading-relaxed">
                    {item.reason}
                  </p>

                  {item.learning_topics && item.learning_topics.length > 0 && (
                    <div className="mb-3">
                      <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block mb-1">
                        Core Learning Syllabus:
                      </span>
                      <ul className="space-y-1 text-2xs text-slate-700">
                        {item.learning_topics.map((topic, tIdx) => (
                          <li key={tIdx} className="flex items-center gap-1.5">
                            <span className="w-1 h-1 rounded-full bg-indigo-500" />
                            <span>{topic}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-200/60 space-y-2 mt-2">
                  <div className="text-2xs text-indigo-950 bg-indigo-50/70 p-2 rounded border border-indigo-100">
                    <strong>Evidence Goal:</strong> {item.evidence_goal}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 2. Week-by-Week Learning Roadmap Timeline */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-6">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Personalized Week-by-Week Learning Roadmap
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Structured progressive curriculum customized to your target role and identified gaps.
              </p>
            </div>
          </div>
        </div>

        {(!learning_roadmap || learning_roadmap.length === 0) ? (
          <p className="text-xs text-slate-500 italic p-4 text-center">
            Standard 4-week roadmap generated on request.
          </p>
        ) : (
          <div className="space-y-4">
            {learning_roadmap.map((weekItem, idx) => (
              <div
                key={idx}
                className="flex flex-col md:flex-row items-start gap-4 p-4 rounded-lg bg-slate-50 border border-slate-200"
              >
                {/* Week Indicator Badge */}
                <div className="shrink-0 flex items-center md:flex-col justify-center gap-1 bg-white border border-slate-200 w-full md:w-24 p-2.5 rounded-md text-center shadow-2xs">
                  <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                    Stage
                  </span>
                  <span className="text-lg font-bold font-mono text-indigo-600 tabular-nums">
                    Week {weekItem.week || idx + 1}
                  </span>
                </div>

                {/* Main Content */}
                <div className="grow space-y-2">
                  <h4 className="font-bold text-sm text-slate-900">
                    {weekItem.focus}
                  </h4>

                  {weekItem.topics && weekItem.topics.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {weekItem.topics.map((topic, tIdx) => (
                        <span
                          key={tIdx}
                          className="text-2xs bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-700 font-medium"
                        >
                          {topic}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="text-xs text-slate-700 bg-white p-2.5 rounded border border-slate-200/80">
                      <span className="text-2xs font-bold uppercase tracking-wider text-slate-500 block mb-0.5">
                        Practice Assignment:
                      </span>
                      {weekItem.practice}
                    </div>

                    <div className="text-xs text-emerald-900 bg-emerald-50/70 p-2.5 rounded border border-emerald-100 flex items-start gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="text-2xs font-bold uppercase tracking-wider text-emerald-800 block mb-0.5">
                          Milestone Outcome:
                        </span>
                        {weekItem.milestone}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 3. Career Stage Advice Card */}
      {career_stage_advice && (
        <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-xl flex items-start gap-3">
          <Compass className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-bold text-xs text-indigo-950 uppercase tracking-wider">
              Strategic Career Stage Advisory
            </h4>
            <p className="text-xs text-indigo-900 mt-1 leading-relaxed">
              {career_stage_advice}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
