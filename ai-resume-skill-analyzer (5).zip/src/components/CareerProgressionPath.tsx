import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { AnalysisReport, SkillMatch, PriorityLevel } from '../types/analyzer';
import {
  TrendingUp,
  Target,
  Sparkles,
  Layers,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Award,
  Lock,
  Unlock,
  RotateCcw,
  Zap,
  Sliders,
  Compass,
  Briefcase,
  ChevronRight,
  Info,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CareerProgressionPathProps {
  report: AnalysisReport;
  onNavigateToRoadmap?: () => void;
  onNavigateToSkills?: () => void;
  className?: string;
}

type ProgressionViewMode = 'ladder' | 'radar' | 'impact_matrix';

interface CareerMilestone {
  id: string;
  levelTitle: string;
  roleTitle: string;
  targetCompany?: string;
  minScoreThreshold: number;
  stageOrder: number;
  description: string;
  unlockedGapsNeeded: string[];
  salaryTierEstimate: string;
  readinessState: 'CURRENT' | 'IN_PROGRESS' | 'UNLOCKED' | 'NEXT_LEAP';
}

interface SimulatedSkillGap {
  id: string;
  name: string;
  category: string;
  priority: PriorityLevel;
  isRequired: boolean;
  scoreContribution: number;
  reason: string;
  explanation: string;
  roadmapPhase: 'Phase 1 (30 Days)' | 'Phase 2 (60 Days)' | 'Phase 3 (90 Days)';
  timeEstimate: string;
  unlockedMilestoneId: string;
  status: 'MISSING' | 'PARTIAL';
}

const CATEGORY_COLORS: Record<string, string> = {
  Architecture: '#4f46e5', // indigo
  Backend: '#0284c7', // sky
  DevOps: '#0d9488', // teal
  Cloud: '#059669', // emerald
  Frontend: '#ea580c', // orange
  Testing: '#8b5cf6', // purple
  Data: '#d97706', // amber
  Other: '#64748b', // slate
};

export const CareerProgressionPath: React.FC<CareerProgressionPathProps> = ({
  report,
  onNavigateToRoadmap,
  onNavigateToSkills,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const [viewMode, setViewMode] = useState<ProgressionViewMode>('ladder');
  const [selectedGapId, setSelectedGapId] = useState<string | null>(null);
  const [simulatedAcquiredGaps, setSimulatedAcquiredGaps] = useState<Set<string>>(new Set());
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const {
    scoreResult,
    targetRole,
    targetCompany,
    experienceLevel,
    resumeData,
    skillMatches,
    recommendations,
  } = report;

  const baselineScore = scoreResult.totalScore;
  const candidateYears = resumeData.total_experience_years || 2;
  const candidateTitle =
    resumeData.candidate.professional_title ||
    resumeData.work_experience[0]?.role ||
    'Software Engineer';

  // Inferred Gap List from report's skill matches (MISSING & PARTIAL)
  const identifiedGaps: SimulatedSkillGap[] = useMemo(() => {
    const rawGaps = skillMatches.filter(
      (m) => m.status === 'MISSING' || m.status === 'PARTIAL'
    );

    // If report has very few gaps (e.g. perfect score), fallback to top priorities
    const sourceGaps: SkillMatch[] =
      rawGaps.length > 0
        ? rawGaps
        : recommendations.top_priorities.map((p) => ({
            skill: p.skill,
            jobRequirement: p.reason,
            isRequired: p.priority === 'HIGH',
            status: 'PARTIAL',
            priority: p.priority,
            resumeEvidence: 'Limited evidence found in resume',
            explanation: p.reason,
          }));

    return sourceGaps.map((gap, index) => {
      // Inferred category
      const skillLower = gap.skill.toLowerCase();
      let category = 'Other';
      if (/system|architect|microservice|distributed|scalab/i.test(skillLower)) {
        category = 'Architecture';
      } else if (/cloud|aws|gcp|azure|terraform/i.test(skillLower)) {
        category = 'Cloud';
      } else if (/docker|k8s|kubernetes|ci\/cd|pipeline|jenkins/i.test(skillLower)) {
        category = 'DevOps';
      } else if (/react|vue|angular|frontend|css|next/i.test(skillLower)) {
        category = 'Frontend';
      } else if (/node|express|fastapi|java|spring|golang|python|c\+\+|c#/i.test(skillLower)) {
        category = 'Backend';
      } else if (/test|jest|cypress|qa|tdd|unit test/i.test(skillLower)) {
        category = 'Testing';
      } else if (/sql|postgres|mongo|redis|database|kafka/i.test(skillLower)) {
        category = 'Data';
      }

      // Point weighting
      const isMissing = gap.status === 'MISSING';
      const isHigh = gap.priority === 'HIGH' || gap.isRequired;
      const scoreContribution = isHigh ? (isMissing ? 8 : 5) : isMissing ? 4 : 2;

      // Roadmap Phase
      const roadmapPhase: 'Phase 1 (30 Days)' | 'Phase 2 (60 Days)' | 'Phase 3 (90 Days)' =
        index < 3
          ? 'Phase 1 (30 Days)'
          : index < 6
          ? 'Phase 2 (60 Days)'
          : 'Phase 3 (90 Days)';

      const timeEstimate = isHigh ? '2–3 weeks' : '1–2 weeks';

      return {
        id: `gap-${index}-${gap.skill.replace(/[^a-zA-Z0-9]/g, '_')}`,
        name: gap.skill,
        category,
        priority: gap.priority,
        isRequired: gap.isRequired,
        scoreContribution,
        reason: gap.jobRequirement || 'Key requirement specified in job specifications',
        explanation: gap.explanation || gap.resumeEvidence,
        roadmapPhase,
        timeEstimate,
        unlockedMilestoneId: index < 4 ? 'milestone-target' : 'milestone-senior',
        status: gap.status as 'MISSING' | 'PARTIAL',
      };
    });
  }, [skillMatches, recommendations.top_priorities]);

  // Set default selected gap on mount
  useEffect(() => {
    if (identifiedGaps.length > 0 && !selectedGapId) {
      setSelectedGapId(identifiedGaps[0].id);
    }
  }, [identifiedGaps, selectedGapId]);

  // Calculate simulated score based on checked gaps
  const { simulatedScore, scoreDelta } = useMemo(() => {
    let delta = 0;
    identifiedGaps.forEach((g) => {
      if (simulatedAcquiredGaps.has(g.id)) {
        delta += g.scoreContribution;
      }
    });
    const finalScore = Math.min(100, baselineScore + delta);
    return {
      simulatedScore: finalScore,
      scoreDelta: finalScore - baselineScore,
    };
  }, [baselineScore, identifiedGaps, simulatedAcquiredGaps]);

  // Define Career Ladder Milestones dynamically
  const careerMilestones: CareerMilestone[] = useMemo(() => {
    const role = targetRole || 'Target Role';
    const comp = targetCompany || 'Target Tier-1 Tech';

    // Inferred baseline career level
    let baseLevel = 'Junior Engineer (L3)';
    if (candidateYears >= 6) baseLevel = 'Senior Engineer (L5)';
    else if (candidateYears >= 3) baseLevel = 'Mid-Level Engineer (L4)';

    const isTargetUnlocked = simulatedScore >= 80;
    const isSeniorUnlocked = simulatedScore >= 90;
    const isStaffUnlocked = simulatedScore >= 96;

    return [
      {
        id: 'milestone-base',
        levelTitle: 'Step 1: Current Baseline',
        roleTitle: candidateTitle,
        minScoreThreshold: baselineScore,
        stageOrder: 1,
        description: `Verified baseline candidate credentials (${candidateYears} yrs verified experience).`,
        unlockedGapsNeeded: [],
        salaryTierEstimate: 'Current Baseline Market Tier',
        readinessState: 'CURRENT',
      },
      {
        id: 'milestone-target',
        levelTitle: `Step 2: Target Qualification (80%)`,
        roleTitle: `${role} at ${comp}`,
        targetCompany: comp,
        minScoreThreshold: 80,
        stageOrder: 2,
        description: `Qualify directly for ${role} interviews by eliminating high-priority skill disqualifiers.`,
        unlockedGapsNeeded: identifiedGaps.slice(0, 3).map((g) => g.name),
        salaryTierEstimate: '+25% to +45% Compensation Uplift',
        readinessState: isTargetUnlocked ? 'UNLOCKED' : 'IN_PROGRESS',
      },
      {
        id: 'milestone-senior',
        levelTitle: 'Step 3: Senior Domain Mastery (90%)',
        roleTitle: `Senior ${role.replace(/junior|entry level|mid level/gi, '').trim() || 'Software Engineer'}`,
        targetCompany: comp,
        minScoreThreshold: 90,
        stageOrder: 3,
        description: `Expand architectural autonomy, end-to-end cloud pipeline, and technical leadership.`,
        unlockedGapsNeeded: identifiedGaps.slice(3, 6).map((g) => g.name),
        salaryTierEstimate: '+50% to +75% Senior Band Uplift',
        readinessState: isSeniorUnlocked ? 'UNLOCKED' : isTargetUnlocked ? 'IN_PROGRESS' : 'NEXT_LEAP',
      },
      {
        id: 'milestone-staff',
        levelTitle: 'Step 4: Staff / Technical Lead (95%+)',
        roleTitle: `Staff / Lead ${role.replace(/junior|entry level|mid level|senior/gi, '').trim() || 'Architect'}`,
        targetCompany: comp,
        minScoreThreshold: 95,
        stageOrder: 4,
        description: `Cross-team systems architecture, org-wide standards, and high-concurrency scalability.`,
        unlockedGapsNeeded: identifiedGaps.slice(6, 9).map((g) => g.name),
        salaryTierEstimate: 'Top Tier Executive & Staff Band',
        readinessState: isStaffUnlocked ? 'UNLOCKED' : 'NEXT_LEAP',
      },
    ];
  }, [candidateTitle, candidateYears, baselineScore, targetRole, targetCompany, simulatedScore, identifiedGaps]);

  const activeSelectedGap = identifiedGaps.find((g) => g.id === selectedGapId) || identifiedGaps[0];

  // Helper toggle simulated gap
  const handleToggleGapSimulation = (gapId: string) => {
    setSimulatedAcquiredGaps((prev) => {
      const next = new Set(prev);
      if (next.has(gapId)) {
        next.delete(gapId);
      } else {
        next.add(gapId);
      }
      return next;
    });
  };

  const handleSimulateAllCritical = () => {
    const criticalIds = identifiedGaps
      .filter((g) => g.priority === 'HIGH' || g.isRequired)
      .map((g) => g.id);
    setSimulatedAcquiredGaps(new Set(criticalIds));
  };

  const handleResetSimulation = () => {
    setSimulatedAcquiredGaps(new Set());
  };

  // -------------------------------------------------------------
  // D3 RENDERING ENGINE
  // -------------------------------------------------------------
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth || 840;
    const height = viewMode === 'radar' ? 380 : 340;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('width', '100%')
      .attr('height', height);

    const defs = svg.append('defs');

    // Glow filter
    const filter = defs
      .append('filter')
      .attr('id', 'careerGlow')
      .attr('x', '-30%')
      .attr('y', '-30%')
      .attr('width', '160%')
      .attr('height', '160%');
    filter.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    // Path Gradients
    const ladderGradient = defs
      .append('linearGradient')
      .attr('id', 'careerLadderGrad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '100%')
      .attr('y2', '0%');
    ladderGradient.append('stop').attr('offset', '0%').attr('stop-color', '#6366f1');
    ladderGradient.append('stop').attr('offset', '50%').attr('stop-color', '#0284c7');
    ladderGradient.append('stop').attr('offset', '100%').attr('stop-color', '#10b981');

    // -----------------------------------------------------------------
    // MODE 1: CAREER LADDER & DIRECTED SKILL GAP PATH (D3)
    // -----------------------------------------------------------------
    if (viewMode === 'ladder') {
      const margin = { top: 40, right: 40, bottom: 50, left: 40 };
      const innerWidth = width - margin.left - margin.right;
      const innerHeight = height - margin.top - margin.bottom;

      const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

      // 4 Milestone positions across horizontal flow
      const numMilestones = careerMilestones.length;
      const stepX = innerWidth / (numMilestones - 1);

      const milestoneCoords = careerMilestones.map((m, idx) => ({
        ...m,
        x: idx * stepX,
        y: innerHeight / 2,
      }));

      // Draw Main Backbone Highway Track
      g.append('path')
        .attr(
          'd',
          d3.line<{ x: number; y: number }>()
            .x((d) => d.x)
            .y((d) => d.y)(milestoneCoords)
        )
        .attr('fill', 'none')
        .attr('stroke', '#e2e8f0')
        .attr('stroke-width', 8)
        .attr('stroke-linecap', 'round');

      // Draw Active Simulated Progress Curve
      const currentProgressRatio = Math.min(1, Math.max(0, (simulatedScore - baselineScore) / (100 - baselineScore)));
      const activeX = milestoneCoords[0].x + currentProgressRatio * (milestoneCoords[milestoneCoords.length - 1].x - milestoneCoords[0].x);

      g.append('line')
        .attr('x1', milestoneCoords[0].x)
        .attr('y1', innerHeight / 2)
        .attr('x2', activeX)
        .attr('y2', innerHeight / 2)
        .attr('stroke', 'url(#careerLadderGrad)')
        .attr('stroke-width', 8)
        .attr('stroke-linecap', 'round')
        .attr('filter', 'url(#careerGlow)');

      // Draw Skill Gap Bridges between Milestone 0 -> 1 and 1 -> 2
      // Render interactive skill gap stepping stones along arcs
      const gapNodes = identifiedGaps.slice(0, 6);
      const bridgeSegments = [
        { startIdx: 0, endIdx: 1, gaps: gapNodes.slice(0, 3), direction: -1 }, // upper arc
        { startIdx: 1, endIdx: 2, gaps: gapNodes.slice(3, 6), direction: 1 },  // lower arc
      ];

      bridgeSegments.forEach((seg) => {
        const p1 = milestoneCoords[seg.startIdx];
        const p2 = milestoneCoords[seg.endIdx];
        const midX = (p1.x + p2.x) / 2;
        const arcY = p1.y + seg.direction * 65;

        // Draw curved stepping path
        const curvePath = d3.path();
        curvePath.moveTo(p1.x, p1.y);
        curvePath.quadraticCurveTo(midX, arcY, p2.x, p2.y);

        g.append('path')
          .attr('d', curvePath.toString())
          .attr('fill', 'none')
          .attr('stroke', '#cbd5e1')
          .attr('stroke-width', 2)
          .attr('stroke-dasharray', '4,4');

        // Draw Gap stepping stone nodes along curve
        seg.gaps.forEach((gap, gIdx) => {
          const t = (gIdx + 1) / (seg.gaps.length + 1);
          // Quadratic bezier formula: B(t) = (1-t)^2 P0 + 2(1-t)t P1 + t^2 P2
          const nodeX = (1 - t) * (1 - t) * p1.x + 2 * (1 - t) * t * midX + t * t * p2.x;
          const nodeY = (1 - t) * (1 - t) * p1.y + 2 * (1 - t) * t * arcY + t * t * p2.y;

          const isAcquired = simulatedAcquiredGaps.has(gap.id);
          const isSelected = selectedGapId === gap.id;
          const catColor = CATEGORY_COLORS[gap.category] || '#6366f1';

          const gapGroup = g
            .append('g')
            .attr('class', 'cursor-pointer transition-transform')
            .attr('transform', `translate(${nodeX}, ${nodeY})`)
            .on('click', () => setSelectedGapId(gap.id))
            .on('mouseenter', () => setHoveredNode(gap.id))
            .on('mouseleave', () => setHoveredNode(null));

          // Outer ring
          gapGroup
            .append('circle')
            .attr('r', isSelected ? 17 : 13)
            .attr('fill', isAcquired ? '#ecfdf5' : isSelected ? '#eef2ff' : '#ffffff')
            .attr('stroke', isAcquired ? '#10b981' : isSelected ? catColor : '#94a3b8')
            .attr('stroke-width', isSelected ? 3 : 2)
            .attr('filter', isSelected ? 'url(#careerGlow)' : null);

          // Center Icon Indicator
          if (isAcquired) {
            gapGroup
              .append('circle')
              .attr('r', 5)
              .attr('fill', '#10b981');
          } else {
            gapGroup
              .append('circle')
              .attr('r', gap.priority === 'HIGH' ? 5 : 3.5)
              .attr('fill', gap.priority === 'HIGH' ? '#f43f5e' : '#f59e0b');
          }

          // Label text above or below
          const textY = seg.direction < 0 ? -18 : 22;
          const textGroup = gapGroup.append('g').attr('transform', `translate(0, ${textY})`);

          textGroup
            .append('rect')
            .attr('x', -35)
            .attr('y', -8)
            .attr('width', 70)
            .attr('height', 16)
            .attr('rx', 4)
            .attr('fill', isSelected ? '#1e293b' : '#f8fafc')
            .attr('stroke', isSelected ? '#0f172a' : '#e2e8f0')
            .attr('stroke-width', 1);

          textGroup
            .append('text')
            .attr('text-anchor', 'middle')
            .attr('y', 4)
            .attr('font-size', '9px')
            .attr('font-family', 'JetBrains Mono, monospace')
            .attr('font-weight', '700')
            .attr('fill', isSelected ? '#ffffff' : '#334155')
            .text(gap.name.length > 9 ? `${gap.name.slice(0, 8)}…` : gap.name);
        });
      });

      // Draw Main Career Milestone Hubs
      milestoneCoords.forEach((m) => {
        const isUnlocked = m.readinessState === 'UNLOCKED' || m.readinessState === 'CURRENT';
        const isCurrent = m.readinessState === 'CURRENT';

        const hubGroup = g
          .append('g')
          .attr('transform', `translate(${m.x}, ${m.y})`)
          .attr('class', 'cursor-pointer');

        // Pulsing outer halo for active unlocked milestones
        if (isUnlocked && !isCurrent) {
          hubGroup
            .append('circle')
            .attr('r', 28)
            .attr('fill', '#10b981')
            .attr('opacity', 0.18)
            .attr('class', 'animate-pulse');
        }

        // Hub Outer Circle
        hubGroup
          .append('circle')
          .attr('r', 20)
          .attr('fill', isUnlocked ? '#ffffff' : '#f8fafc')
          .attr('stroke', isCurrent ? '#6366f1' : isUnlocked ? '#10b981' : '#94a3b8')
          .attr('stroke-width', isUnlocked ? 3.5 : 2)
          .attr('filter', isUnlocked ? 'url(#careerGlow)' : null);

        // Hub Inner Core
        hubGroup
          .append('circle')
          .attr('r', 8)
          .attr('fill', isCurrent ? '#6366f1' : isUnlocked ? '#10b981' : '#cbd5e1');

        // Step Label & Milestone Badge Above
        const topLabel = hubGroup.append('g').attr('transform', 'translate(0, -32)');
        topLabel
          .append('rect')
          .attr('x', -48)
          .attr('y', -10)
          .attr('width', 96)
          .attr('height', 18)
          .attr('rx', 9)
          .attr('fill', isCurrent ? '#eef2ff' : isUnlocked ? '#ecfdf5' : '#f1f5f9')
          .attr('stroke', isCurrent ? '#c7d2fe' : isUnlocked ? '#a7f3d0' : '#e2e8f0');

        topLabel
          .append('text')
          .attr('text-anchor', 'middle')
          .attr('y', 3)
          .attr('font-size', '9.5px')
          .attr('font-weight', '700')
          .attr('font-family', 'Plus Jakarta Sans, sans-serif')
          .attr('fill', isCurrent ? '#4338ca' : isUnlocked ? '#047857' : '#64748b')
          .text(isCurrent ? 'Baseline' : isUnlocked ? `Unlocked! (${m.minScoreThreshold}%)` : `Req: ${m.minScoreThreshold}%`);

        // Role Title Below
        const bottomLabel = hubGroup.append('g').attr('transform', 'translate(0, 32)');
        bottomLabel
          .append('text')
          .attr('text-anchor', 'middle')
          .attr('y', 0)
          .attr('font-size', '11px')
          .attr('font-weight', '800')
          .attr('fill', '#0f172a')
          .text(m.roleTitle.length > 20 ? `${m.roleTitle.slice(0, 18)}…` : m.roleTitle);

        bottomLabel
          .append('text')
          .attr('text-anchor', 'middle')
          .attr('y', 14)
          .attr('font-size', '9px')
          .attr('font-family', 'JetBrains Mono, monospace')
          .attr('fill', '#64748b')
          .text(m.levelTitle.split(':')[0]);
      });
    }

    // -----------------------------------------------------------------
    // MODE 2: RADAR GAP POLAR CHART (D3)
    // -----------------------------------------------------------------
    if (viewMode === 'radar') {
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = Math.min(centerX, centerY) - 50;

      const categories = [
        { name: 'Core Language', current: 82, target: 95 },
        { name: 'Architecture', current: Math.max(30, baselineScore - 15), target: 90 },
        { name: 'Cloud & DevOps', current: Math.max(25, baselineScore - 20), target: 85 },
        { name: 'Testing & QA', current: 60, target: 80 },
        { name: 'System Scalability', current: Math.max(20, baselineScore - 25), target: 90 },
        { name: 'Collaboration/Agile', current: 85, target: 90 },
      ];

      const angleSlice = (Math.PI * 2) / categories.length;
      const rScale = d3.scaleLinear().domain([0, 100]).range([0, radius]);

      const g = svg.append('g').attr('transform', `translate(${centerX},${centerY})`);

      // Circular Grid
      const levels = [25, 50, 75, 100];
      levels.forEach((lvl) => {
        g.append('circle')
          .attr('r', rScale(lvl))
          .attr('fill', 'none')
          .attr('stroke', '#e2e8f0')
          .attr('stroke-dasharray', '2,2');

        g.append('text')
          .attr('x', 4)
          .attr('y', -rScale(lvl))
          .attr('font-size', '9px')
          .attr('fill', '#94a3b8')
          .text(`${lvl}%`);
      });

      // Axis Lines & Labels
      categories.forEach((cat, i) => {
        const angle = angleSlice * i - Math.PI / 2;
        const x = rScale(100) * Math.cos(angle);
        const y = rScale(100) * Math.sin(angle);

        g.append('line')
          .attr('x1', 0)
          .attr('y1', 0)
          .attr('x2', x)
          .attr('y2', y)
          .attr('stroke', '#cbd5e1')
          .attr('stroke-width', 1);

        // Label
        const labelX = (radius + 24) * Math.cos(angle);
        const labelY = (radius + 18) * Math.sin(angle);

        g.append('text')
          .attr('x', labelX)
          .attr('y', labelY)
          .attr('text-anchor', 'middle')
          .attr('font-size', '10.5px')
          .attr('font-weight', '700')
          .attr('fill', '#334155')
          .text(cat.name);
      });

      // Target Benchmark Polygon
      const targetRadarLine = d3
        .lineRadial<{ current: number; target: number }>()
        .radius((d) => rScale(d.target))
        .angle((_, i) => i * angleSlice)
        .curve(d3.curveLinearClosed);

      g.append('path')
        .datum(categories)
        .attr('d', targetRadarLine as any)
        .attr('fill', '#10b981')
        .attr('fill-opacity', 0.1)
        .attr('stroke', '#10b981')
        .attr('stroke-width', 2)
        .attr('stroke-dasharray', '4,4');

      // Candidate Current Polygon (adjusted dynamically by simulation)
      const currentValues = categories.map((cat, i) => {
        const bonus = (scoreDelta / 100) * 15;
        return {
          ...cat,
          simulatedCurrent: Math.min(100, cat.current + (i % 2 === 1 ? bonus * 1.5 : bonus)),
        };
      });

      const currentRadarLine = d3
        .lineRadial<{ simulatedCurrent: number }>()
        .radius((d) => rScale(d.simulatedCurrent))
        .angle((_, i) => i * angleSlice)
        .curve(d3.curveLinearClosed);

      g.append('path')
        .datum(currentValues)
        .attr('d', currentRadarLine as any)
        .attr('fill', '#4f46e5')
        .attr('fill-opacity', 0.25)
        .attr('stroke', '#4f46e5')
        .attr('stroke-width', 2.5);

      // Radar Legend
      const legend = svg.append('g').attr('transform', 'translate(20, 20)');
      legend
        .append('rect')
        .attr('width', 12)
        .attr('height', 12)
        .attr('fill', '#4f46e5')
        .attr('rx', 2);
      legend
        .append('text')
        .attr('x', 18)
        .attr('y', 10)
        .attr('font-size', '10px')
        .attr('font-weight', '600')
        .attr('fill', '#334155')
        .text('Candidate Score Profile');

      legend
        .append('rect')
        .attr('y', 18)
        .attr('width', 12)
        .attr('height', 12)
        .attr('fill', '#10b981')
        .attr('rx', 2);
      legend
        .append('text')
        .attr('x', 18)
        .attr('y', 28)
        .attr('font-size', '10px')
        .attr('font-weight', '600')
        .attr('fill', '#334155')
        .text('Target Role Benchmark');
    }

    // -----------------------------------------------------------------
    // MODE 3: IMPACT VS EFFORT MATRIX (D3)
    // -----------------------------------------------------------------
    if (viewMode === 'impact_matrix') {
      const margin = { top: 30, right: 30, bottom: 40, left: 50 };
      const innerWidth = width - margin.left - margin.right;
      const innerHeight = height - margin.top - margin.bottom;

      const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

      const xScale = d3.scaleLinear().domain([0, 100]).range([0, innerWidth]);
      const yScale = d3.scaleLinear().domain([0, 100]).range([innerHeight, 0]);

      // Quadrant Backgrounds
      // Q1 (Top-Left): Quick Wins (Low Effort, High Impact)
      g.append('rect')
        .attr('x', 0)
        .attr('y', 0)
        .attr('width', innerWidth / 2)
        .attr('height', innerHeight / 2)
        .attr('fill', '#ecfdf5')
        .attr('opacity', 0.5);

      // Q2 (Top-Right): Strategic Investments (High Effort, High Impact)
      g.append('rect')
        .attr('x', innerWidth / 2)
        .attr('y', 0)
        .attr('width', innerWidth / 2)
        .attr('height', innerHeight / 2)
        .attr('fill', '#eef2ff')
        .attr('opacity', 0.5);

      // Quadrant Labels
      g.append('text')
        .attr('x', 15)
        .attr('y', 20)
        .attr('font-size', '11px')
        .attr('font-weight', '800')
        .attr('fill', '#059669')
        .text('⚡ HIGH IMPACT / QUICK WINS');

      g.append('text')
        .attr('x', innerWidth / 2 + 15)
        .attr('y', 20)
        .attr('font-size', '11px')
        .attr('font-weight', '800')
        .attr('fill', '#4338ca')
        .text('🏆 STRATEGIC FOUNDATIONS');

      // Center Divider Lines
      g.append('line')
        .attr('x1', innerWidth / 2)
        .attr('y1', 0)
        .attr('x2', innerWidth / 2)
        .attr('y2', innerHeight)
        .attr('stroke', '#cbd5e1')
        .attr('stroke-dasharray', '4,4');

      g.append('line')
        .attr('x1', 0)
        .attr('y1', innerHeight / 2)
        .attr('x2', innerWidth)
        .attr('y2', innerHeight / 2)
        .attr('stroke', '#cbd5e1')
        .attr('stroke-dasharray', '4,4');

      // Plot Bubbles for each identified gap
      identifiedGaps.forEach((gap, i) => {
        // Effort (X): 20 to 80 based on index & priority
        const effort = gap.priority === 'HIGH' ? 65 : 35 + (i * 7) % 30;
        // Impact (Y): 30 to 90
        const impact = (gap.scoreContribution / 8) * 75 + 15;

        const cx = xScale(effort);
        const cy = yScale(impact);
        const isAcquired = simulatedAcquiredGaps.has(gap.id);
        const isSelected = selectedGapId === gap.id;

        const bubbleGroup = g
          .append('g')
          .attr('transform', `translate(${cx}, ${cy})`)
          .attr('class', 'cursor-pointer')
          .on('click', () => setSelectedGapId(gap.id));

        bubbleGroup
          .append('circle')
          .attr('r', isSelected ? 18 : 14)
          .attr('fill', isAcquired ? '#10b981' : '#ffffff')
          .attr('stroke', isAcquired ? '#059669' : isSelected ? '#4f46e5' : '#64748b')
          .attr('stroke-width', isSelected ? 3 : 2)
          .attr('filter', isSelected ? 'url(#careerGlow)' : null);

        bubbleGroup
          .append('text')
          .attr('text-anchor', 'middle')
          .attr('y', 3.5)
          .attr('font-size', '9px')
          .attr('font-weight', '700')
          .attr('fill', isAcquired ? '#ffffff' : '#0f172a')
          .text(gap.name.slice(0, 5));
      });
    }
  }, [viewMode, careerMilestones, identifiedGaps, simulatedAcquiredGaps, selectedGapId, baselineScore, simulatedScore, scoreDelta]);

  return (
    <div className={`bg-white border border-slate-200/90 rounded-2xl p-6 sm:p-7 shadow-xs space-y-6 ${className}`}>
      {/* 1. Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-2xs font-bold font-mono tracking-wider uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Zap className="w-3 h-3 text-emerald-600" />
              <span>D3.js Career Progression Path</span>
            </span>
            <span className="text-2xs text-slate-400 font-mono">Calibrated to Identified Skill Gaps</span>
          </div>

          <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Career Advancement Ladder & Skill Gap Bridges</span>
          </h3>

          <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
            See how closing your <strong className="text-rose-600 font-mono">{identifiedGaps.length} identified skill gaps</strong> unlocks 
            each career milestone—from current baseline to <strong className="text-indigo-600 font-mono">{targetRole}</strong> and beyond.
          </p>
        </div>

        {/* View Switcher Toggle */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100/90 rounded-xl self-start sm:self-center border border-slate-200/60">
          <button
            type="button"
            onClick={() => setViewMode('ladder')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'ladder'
                ? 'bg-white text-indigo-700 shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Milestone Ladder</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('radar')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'radar'
                ? 'bg-white text-indigo-700 shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Competency Radar</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('impact_matrix')}
            className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'impact_matrix'
                ? 'bg-white text-indigo-700 shadow-2xs font-black'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Impact vs Effort</span>
          </button>
        </div>
      </div>

      {/* 2. Interactive Sandbox Simulator Banner */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 font-mono">
              Live Gap-Closure Simulator
            </span>
          </div>
          <p className="text-xs text-slate-300 max-w-xl">
            Simulate acquiring missing competencies. Toggle skills below to witness the progression ladder advance and unlock career benchmarks in real-time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Score Delta Counter */}
          <div className="px-4 py-2 rounded-xl bg-white/10 border border-white/15 backdrop-blur-xs flex items-center gap-3">
            <div>
              <span className="text-3xs text-slate-400 uppercase tracking-wider block font-mono">
                Alignment Score
              </span>
              <div className="flex items-baseline gap-1.5">
                <span className="text-xl font-black font-mono text-emerald-400">
                  {simulatedScore}%
                </span>
                {scoreDelta > 0 && (
                  <span className="text-2xs font-bold text-emerald-300 font-mono">
                    (+{scoreDelta} pts)
                  </span>
                )}
              </div>
            </div>
            {simulatedScore >= 80 ? (
              <span className="px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 text-2xs font-bold border border-emerald-500/30 flex items-center gap-1">
                <Unlock className="w-3 h-3" />
                Target Unlocked
              </span>
            ) : (
              <span className="px-2 py-1 rounded bg-amber-500/20 text-amber-300 text-2xs font-bold border border-amber-500/30 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                {80 - simulatedScore} pts to Target
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleSimulateAllCritical}
              className="px-3 py-2 text-2xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors cursor-pointer"
            >
              Close Top Gaps
            </button>
            {simulatedAcquiredGaps.size > 0 && (
              <button
                type="button"
                onClick={handleResetSimulation}
                className="p-2 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                title="Reset simulation"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 3. D3 SVG Canvas */}
      <div ref={containerRef} className="relative w-full overflow-hidden bg-slate-50/50 rounded-xl border border-slate-200/80">
        <svg ref={svgRef} className="w-full select-none" />
      </div>

      {/* 4. Skill Gap Stepping Stones & Inspector Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-2">
        {/* Left Column: Skill Gap Interactive List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <span>Skill Gaps to Bridge</span>
              <span className="px-1.5 py-0.5 rounded-full text-3xs font-mono bg-rose-100 text-rose-800">
                {identifiedGaps.length} Total
              </span>
            </h4>
            <span className="text-2xs text-slate-400">Click to inspect</span>
          </div>

          <div className="max-h-[360px] overflow-y-auto space-y-2 pr-1">
            {identifiedGaps.map((gap) => {
              const isSelected = selectedGapId === gap.id;
              const isAcquired = simulatedAcquiredGaps.has(gap.id);
              const isMissing = gap.status === 'MISSING';

              return (
                <div
                  key={gap.id}
                  onClick={() => setSelectedGapId(gap.id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/40 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleGapSimulation(gap.id);
                      }}
                      className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                        isAcquired
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 hover:border-indigo-500 bg-white'
                      }`}
                      title={isAcquired ? 'Marked as acquired' : 'Simulate acquiring skill'}
                    >
                      {isAcquired && <CheckCircle2 className="w-3.5 h-3.5" />}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className={`text-xs font-bold truncate ${isAcquired ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                          {gap.name}
                        </span>
                        <span
                          className={`text-3xs font-mono px-1 rounded ${
                            gap.priority === 'HIGH'
                              ? 'bg-rose-100 text-rose-800 font-bold'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {gap.priority}
                        </span>
                      </div>
                      <span className="text-3xs text-slate-400 block truncate">
                        {gap.category} · {gap.timeEstimate}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-2xs font-mono font-bold text-emerald-600 block">
                      +{gap.scoreContribution} pts
                    </span>
                    <span className="text-3xs text-slate-400">{gap.roadmapPhase.split(' ')[0]}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Selected Skill Gap Inspector */}
        <div className="lg:col-span-7 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider font-mono">
                  Competency Gap Deep Dive
                </span>
                <span className="px-2 py-0.5 rounded text-3xs font-bold font-mono bg-indigo-100 text-indigo-800">
                  {activeSelectedGap.category}
                </span>
              </div>
              <h4 className="text-base font-black text-slate-900 mt-0.5">
                {activeSelectedGap.name}
              </h4>
            </div>

            <button
              type="button"
              onClick={() => handleToggleGapSimulation(activeSelectedGap.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                simulatedAcquiredGaps.has(activeSelectedGap.id)
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white border border-slate-300 text-slate-700 hover:border-indigo-500'
              }`}
            >
              {simulatedAcquiredGaps.has(activeSelectedGap.id) ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Simulated: Acquired</span>
                </>
              ) : (
                <>
                  <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Test Acquiring (+{activeSelectedGap.scoreContribution} pts)</span>
                </>
              )}
            </button>
          </div>

          {/* Job Requirement Context */}
          <div className="space-y-1">
            <span className="text-3xs font-bold uppercase tracking-wider text-slate-400">
              Role Expectation & Requirement
            </span>
            <p className="text-xs text-slate-700 bg-white p-3 rounded-lg border border-slate-200 leading-relaxed font-sans">
              "{activeSelectedGap.reason}"
            </p>
          </div>

          {/* Career Impact & Promotion Value */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-white rounded-lg border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                Career Milestone Unlocked
              </span>
              <span className="font-bold text-slate-800 text-xs">
                {activeSelectedGap.unlockedMilestoneId === 'milestone-target'
                  ? `Qualifies for ${targetRole || 'Target Role'}`
                  : `Propels to Senior / Staff Tier`}
              </span>
            </div>

            <div className="p-3 bg-white rounded-lg border border-slate-200">
              <span className="text-3xs font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                Roadmap Phase & Timeline
              </span>
              <span className="font-bold text-indigo-700 text-xs font-mono">
                {activeSelectedGap.roadmapPhase} (~{activeSelectedGap.timeEstimate})
              </span>
            </div>
          </div>

          {/* Call to action: Direct to Learning Roadmap */}
          {onNavigateToRoadmap && (
            <div className="pt-1 flex items-center justify-between">
              <span className="text-2xs text-slate-500">
                Official documentation, video courses, and project tutorials available in Learning Hub.
              </span>
              <button
                type="button"
                onClick={onNavigateToRoadmap}
                className="px-3.5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <span>Open in Roadmap</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
