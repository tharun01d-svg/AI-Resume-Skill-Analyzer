import React from 'react';
import { X, Calculator, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { modalOverlayVariants, modalDialogVariants } from '../utils/motion';

interface ScoreFormulaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScoreFormulaModal: React.FC<ScoreFormulaModalProps> = ({ isOpen, onClose }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="formula-modal-overlay"
          variants={modalOverlayVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
        >
          <motion.div
            key="formula-modal-dialog"
            variants={modalDialogVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-3xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
          >
        {/* Modal Header */}
        <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calculator className="w-5 h-5 text-indigo-600" />
              How Is the Resume Alignment Score Calculated?
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              10-Category transparent, explainable scoring engine. Grounded strictly in verified facts.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="px-6 py-6 overflow-y-auto space-y-6 text-sm text-slate-700 leading-relaxed">
          {/* Core Principle */}
          <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-lg">
            <h3 className="font-semibold text-indigo-950 flex items-center gap-1.5 mb-1">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              Core Principle: Mathematical Engine, Not Arbitrary AI Guesswork
            </h3>
            <p className="text-xs text-indigo-900 leading-relaxed">
              The platform extracts structured semantic representations of the resume and job criteria.
              However, <strong>the numerical score /100 is computed deterministically</strong> by application code across 10 weighted dimensions.
              The AI never fabricates a random grade. This score reflects resume quality and alignment with target role criteria, not a probability of getting hired.
            </p>
          </div>

          {/* Scoring Category Table */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              10-Category Weighted Rubric (100 Points Total)
            </h3>
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="px-4 py-2.5 font-semibold">Category</th>
                    <th className="px-4 py-2.5 font-semibold">Max Weight</th>
                    <th className="px-4 py-2.5 font-semibold">Evaluation Criteria</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-normal text-slate-700">
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">1. Required Skills</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">20 pts</td>
                    <td className="px-4 py-2">Matched (1.0), Partial (0.5), Missing (0.0) across mandatory qualifications</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">2. Preferred Skills</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">10 pts</td>
                    <td className="px-4 py-2">Secondary competencies, bonus tools, and domain specializations</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">3. Experience Alignment</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">15 pts</td>
                    <td className="px-4 py-2">Years of experience, trajectory, career progression, and seniority calibration</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">4. Project Relevance</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">10 pts</td>
                    <td className="px-4 py-2">Demonstrated practical projects, architectural complexity, and problem solving</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">5. Education</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">10 pts</td>
                    <td className="px-4 py-2">Relevant degrees, academic honors, and coursework (no unfair penalties)</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">6. Certifications</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">5 pts</td>
                    <td className="px-4 py-2">Active professional credentials (neutralized without penalty if role doesn't require)</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">7. Resume Quality</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">10 pts</td>
                    <td className="px-4 py-2">Visual layout, structure, clarity of sections, and typography</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">8. ATS Readiness</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">10 pts</td>
                    <td className="px-4 py-2">Headings, parsable contact metadata, single-layer OCR readability</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">9. Content Clarity</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">5 pts</td>
                    <td className="px-4 py-2">Action verb strength, conciseness, elimination of passive voice & buzzwords</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-2 font-medium text-slate-900">10. Achievement Strength</td>
                    <td className="px-4 py-2 font-mono tabular-nums font-bold text-indigo-600">5 pts</td>
                    <td className="px-4 py-2">Quantified business outcomes, ownership scope, and measurable results</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Formula */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Final Normalization Formula
            </h4>
            <code className="text-xs font-mono text-indigo-700 block bg-white p-2.5 rounded border border-slate-200 overflow-x-auto">
              Score = [ Sum(Earned Applicable Category Points) / Total Applicable Weight (100) ] × 100
            </code>
            <p className="text-2xs text-slate-500 mt-2">
              If an optional category is not applicable for a role (e.g. no certifications requested), its weight is neutralized and redistributed proportionally so candidates are never penalized.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
