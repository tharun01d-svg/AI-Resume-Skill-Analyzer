import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { fadeUpVariants } from '../utils/motion';
import { AnalysisReport } from '../types/analyzer';
import { ScoreRing } from './ScoreRing';
import { SkillMatrix } from './SkillMatrix';
import { ExperienceAndProjects } from './ExperienceAndProjects';
import { DeepResumeAnalysis } from './DeepResumeAnalysis';
import { ImprovedResumeView } from './ImprovedResumeView';
import { LearningRoadmapView } from './LearningRoadmapView';
import { LearningAndCareerHub } from './LearningAndCareerHub';
import { ApplicationReadinessCard } from './ApplicationReadinessCard';
import { CompanyLogo } from './CompanyLogo';
import { SkillProgressionChart } from './SkillProgressionChart';
import { CareerProgressionPath } from './CareerProgressionPath';
import { DualRoleComparisonView } from './DualRoleComparisonView';
import { useAuth } from '../context/AuthContext';
import {
  Printer,
  HelpCircle,
  RotateCcw,
  Sparkles,
  Layers,
  FileCheck,
  Calendar,
  Briefcase,
  Target,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  FileText,
  Download,
  Info,
  Compass,
  Scale,
  Database,
  TrendingUp,
} from 'lucide-react';

interface ResultsDashboardProps {
  report: AnalysisReport;
  onOpenReportModal: () => void;
  onOpenFormulaModal: () => void;
  onReset: () => void;
  onOpenCredentials?: () => void;
}

export type DashboardTab =
  | 'overview'
  | 'career-path'
  | 'compare'
  | 'deep'
  | 'rewrite'
  | 'skills'
  | 'experience'
  | 'roadmap';

export const ResultsDashboard: React.FC<ResultsDashboardProps> = ({
  report,
  onOpenReportModal,
  onOpenFormulaModal,
  onReset,
  onOpenCredentials,
}) => {
  const { currentUser, saveAnalysisToCloud, isSavingAnalysis } = useAuth();
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [deepSubSection, setDeepSubSection] = useState<string>('profile');
  const [cloudSaved, setCloudSaved] = useState<boolean>(false);
  const [overviewVizTab, setOverviewVizTab] = useState<'ladder' | 'trajectory'>('ladder');

  const handleSaveToCloud = async () => {
    if (!currentUser) {
      if (onOpenCredentials) onOpenCredentials();
      return;
    }
    const success = await saveAnalysisToCloud(report);
    if (success) {
      setCloudSaved(true);
      setTimeout(() => setCloudSaved(false), 4000);
    }
  };

  const {
    resumeFileName,
    targetGoal,
    resumeData,
    jobData,
    skillMatches,
    scoreResult,
    recommendations,
    targetCompany,
    targetRole,
    experienceLevel,
    isJobDescriptionSupplied,
    applicationReadiness,
  } = report;

  const candidateDisplayName =
    resumeData?.candidate?.name && resumeData.candidate.name !== 'Candidate'
      ? resumeData.candidate.name
      : 'Candidate Profile';

  const companyDisplayName = targetCompany || jobData.company_inferred || 'Target Organization';
  const roleDisplayName = targetRole || jobData.job_title || 'Target Role';
  const seniorityDisplayName = experienceLevel || jobData.seniority_level || '2–4 Years';

  const strongMatchesCount = skillMatches.filter((m) => m.status === 'MATCHED').length;
  const partialMatchesCount = skillMatches.filter((m) => m.status === 'PARTIAL').length;
  const gapsCount = skillMatches.filter((m) => m.status === 'MISSING').length;

  const handleDeepJump = (tabKey: string) => {
    setDeepSubSection(tabKey);
    setActiveTab('deep');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Completion Banner (Prompt Spec #5) */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/40 rounded-2xl p-6 text-white shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-bold tracking-wide uppercase">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Analysis Complete</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-1">
            Your Resume Intelligence Report is Ready
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            We analyzed your resume across skills, experience, projects, ATS structure, career alignment, and content quality.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('career-path')}
            className="px-3.5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 text-indigo-200" />
            <span>Career Progression Path (D3)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('compare')}
            className="px-3.5 py-2.5 text-xs font-bold text-indigo-100 bg-slate-800 hover:bg-slate-700 border border-indigo-800/60 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Scale className="w-3.5 h-3.5 text-indigo-300" />
            <span>Compare 2 Roles</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('rewrite')}
            className="px-4 py-2.5 text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-slate-900" />
            <span>Generate Improved Resume →</span>
          </button>
        </div>
      </div>

      {/* 2. Header Banner & Target Metadata (Prompt Spec #6) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-2xs font-bold uppercase tracking-wider text-slate-400">
            <span>Target Evaluation</span>
            <span>·</span>
            <span className="text-indigo-600 font-semibold">{seniorityDisplayName}</span>
          </div>

          <div className="flex items-center gap-3.5">
            <CompanyLogo name={companyDisplayName} size="lg" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Target Company:
                </span>
                <span className="text-sm font-bold text-slate-900">{companyDisplayName}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {roleDisplayName}
              </h2>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 pt-1">
            <span>Candidate: <strong>{candidateDisplayName}</strong></span>
            <span>·</span>
            <span>File: <strong className="font-mono text-slate-700">{resumeFileName}</strong></span>
            {targetGoal && (
              <>
                <span>·</span>
                <span className="text-indigo-600 font-medium">Goal: "{targetGoal}"</span>
              </>
            )}
          </div>

          {/* Source Indicator */}
          <div className="pt-1">
            {isJobDescriptionSupplied ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                Analysis based on supplied job description
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-semibold bg-indigo-50 text-indigo-800 border border-indigo-200">
                <Info className="w-3 h-3 text-indigo-600" />
                Analysis based on selected company, role, and experience level
              </span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 self-start md:self-center">
          <button
            onClick={handleSaveToCloud}
            disabled={isSavingAnalysis}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
              cloudSaved
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200'
            }`}
            title="Save this analysis report to Cloud SQL PostgreSQL database"
          >
            {cloudSaved ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                <span>Saved to Cloud!</span>
              </>
            ) : (
              <>
                <Database className="w-3.5 h-3.5 text-indigo-600" />
                <span>{isSavingAnalysis ? 'Saving...' : 'Save to Cloud SQL'}</span>
              </>
            )}
          </button>

          <button
            onClick={onOpenReportModal}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-indigo-600 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Full Report</span>
          </button>

          <button
            onClick={onOpenFormulaModal}
            className="px-3 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
            <span>Formula</span>
          </button>

          <button
            onClick={onReset}
            className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>New Analysis</span>
          </button>
        </div>
      </div>

      {/* 3. Primary Tab Navigation Strip */}
      <div className="border-b border-slate-200 flex items-center gap-1 overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: '10-Category Breakdown', icon: Target },
          { id: 'career-path', label: 'Career Progression Path', icon: TrendingUp, badge: 'D3 Path' },
          { id: 'compare', label: 'Dual Role Comparison', icon: Scale, badge: 'Side-by-Side' },
          { id: 'deep', label: 'Deep Resume Analysis (A–K)', icon: Compass, badge: '11 Dimensions' },
          { id: 'rewrite', label: '✨ Improved Resume & PDF', icon: Sparkles, badge: 'ATS-Ready' },
          { id: 'skills', label: 'Skill Matrix & Matching', icon: FileCheck, badge: `${skillMatches.length}` },
          { id: 'experience', label: 'Experience & Projects', icon: Briefcase },
          { id: 'roadmap', label: '🚀 What To Learn Next', icon: Calendar, badge: 'Career Hub' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as DashboardTab)}
              className={`relative px-4 py-3 text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
                isActive
                  ? 'text-indigo-600 bg-indigo-50/30'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="active-dashboard-tab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600"
                  transition={{ type: 'spring', stiffness: 450, damping: 35 }}
                />
              )}
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`text-2xs px-1.5 py-0.5 rounded font-mono ${
                    isActive ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 4. Active Tab Workspace */}
      <div className="pt-2">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            variants={fadeUpVariants}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            {/* TAB 1: OVERVIEW & 10-CATEGORY SCORE BREAKDOWN */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* 10-Category Interactive Score Ring Card */}
            <ScoreRing
              scoreResult={scoreResult}
              onOpenFormula={onOpenFormulaModal}
              onSelectDeepTab={handleDeepJump}
            />

            {/* Match Statistics Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-emerald-950">Strong Matches</p>
                    <p className="text-2xs text-emerald-700">Verified resume evidence</p>
                  </div>
                </div>
                <span className="text-xl font-black text-emerald-700 font-mono">
                  {strongMatchesCount}
                </span>
              </div>

              <div className="p-4 rounded-xl border border-amber-200 bg-amber-50/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-amber-950">Partial Matches</p>
                    <p className="text-2xs text-amber-700">Mentioned or related</p>
                  </div>
                </div>
                <span className="text-xl font-black text-amber-700 font-mono">
                  {partialMatchesCount}
                </span>
              </div>

              <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                    <XCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-rose-950">Skill Gaps</p>
                    <p className="text-2xs text-rose-700">Target requirements to build</p>
                  </div>
                </div>
                <span className="text-xl font-black text-rose-700 font-mono">
                  {gapsCount}
                </span>
              </div>
            </div>

            {/* Application Readiness Section */}
            <ApplicationReadinessCard
              readiness={applicationReadiness}
              companyName={companyDisplayName}
              roleTitle={roleDisplayName}
            />

            {/* D3.js Career Progression Path & Skill Progression Trajectory */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Career Progression Intelligence (D3)
                    </h4>
                    <p className="text-3xs text-slate-500">
                      Visualizing career advancement milestones and readiness based on identified skill gaps
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs self-start sm:self-center">
                  <button
                    type="button"
                    onClick={() => setOverviewVizTab('ladder')}
                    className={`px-3 py-1.5 rounded-md font-bold text-2xs transition-all cursor-pointer flex items-center gap-1.5 ${
                      overviewVizTab === 'ladder'
                        ? 'bg-white text-indigo-700 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <TrendingUp className="w-3 h-3 text-indigo-600" />
                    <span>Career Ladder & Skill Gaps</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setOverviewVizTab('trajectory')}
                    className={`px-3 py-1.5 rounded-md font-bold text-2xs transition-all cursor-pointer flex items-center gap-1.5 ${
                      overviewVizTab === 'trajectory'
                        ? 'bg-white text-indigo-700 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Calendar className="w-3 h-3 text-slate-500" />
                    <span>30-60-90 Trajectory Curve</span>
                  </button>
                </div>
              </div>

              {overviewVizTab === 'ladder' ? (
                <CareerProgressionPath
                  report={report}
                  onNavigateToRoadmap={() => setActiveTab('roadmap')}
                  onNavigateToSkills={() => setActiveTab('skills')}
                />
              ) : (
                <SkillProgressionChart
                  report={report}
                  onExploreRoadmap={() => setActiveTab('roadmap')}
                />
              )}
            </div>

            {/* Quick Link to AI Rewrite */}
            <div className="p-5 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-indigo-950 uppercase tracking-wider">
                    Next Step: Review & Download Your Improved Resume
                  </h4>
                  <p className="text-xs text-indigo-900 mt-0.5">
                    We transformed your weak bullet points using the Google X-Y-Z formula without inventing fake numbers or employers.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('rewrite')}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                Review Improved Resume →
              </button>
            </div>

            {/* Quick Link to Personalized Learning & Career Hub */}
            <div className="p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/80 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-white shadow-xs">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs text-indigo-200 uppercase tracking-wider">
                    🚀 Next Step: What Should You Learn Next?
                  </h4>
                  <p className="text-xs text-slate-300 mt-0.5 max-w-2xl leading-relaxed">
                    Access your Personalized Learning & Career Hub: 30-60-90 day progressive roadmap, verified YouTube learning, official documentation, certificate courses, and gap-closing projects tailored to {roleDisplayName} at {companyDisplayName}.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('roadmap')}
                className="px-4 py-2 text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                Explore Learning Hub →
              </button>
            </div>
          </div>
        )}

        {/* TAB: CAREER PROGRESSION PATH (D3) */}
        {activeTab === 'career-path' && (
          <div className="space-y-6">
            <CareerProgressionPath
              report={report}
              onNavigateToRoadmap={() => setActiveTab('roadmap')}
              onNavigateToSkills={() => setActiveTab('skills')}
            />
          </div>
        )}

        {/* TAB: DUAL ROLE COMPARISON (SIDE-BY-SIDE) */}
        {activeTab === 'compare' && (
          <DualRoleComparisonView
            report={report}
            onNavigateToRoadmap={() => setActiveTab('roadmap')}
          />
        )}

        {/* TAB 2: DEEP RESUME ANALYSIS (A-K) */}
        {activeTab === 'deep' && (
          <DeepResumeAnalysis
            resume={resumeData}
            job={jobData}
            targetCompany={companyDisplayName}
            targetRole={roleDisplayName}
            initialSubSection={deepSubSection}
          />
        )}

        {/* TAB 3: IMPROVED RESUME & PDF BUILDER */}
        {activeTab === 'rewrite' && (
          <ImprovedResumeView
            resume={resumeData}
            job={jobData}
            targetCompany={companyDisplayName}
            targetRole={roleDisplayName}
          />
        )}

        {/* TAB 4: SKILL MATRIX */}
        {activeTab === 'skills' && (
          <SkillMatrix
            matches={skillMatches}
            onNavigateToLearningHub={() => setActiveTab('roadmap')}
          />
        )}

        {/* TAB 5: EXPERIENCE & PROJECTS */}
        {activeTab === 'experience' && (
          <ExperienceAndProjects resume={resumeData} job={jobData} />
        )}

        {/* TAB 6: PERSONALIZED LEARNING & CAREER HUB */}
        {activeTab === 'roadmap' && (
          <LearningAndCareerHub
            report={report}
            onSelectTab={(tab) => setActiveTab(tab)}
          />
        )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* 5. Final Action Plan Footer Card */}
      {recommendations.final_action_plan && recommendations.final_action_plan.length > 0 && (
        <div className="bg-slate-900 rounded-2xl p-6 text-white space-y-4 shadow-lg">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-100">
              Immediate Action Checklist for {roleDisplayName} at {companyDisplayName}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
            {recommendations.final_action_plan.map((step, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-800/80 border border-slate-700/80 rounded-xl flex items-start gap-3 text-xs text-slate-200"
              >
                <span className="font-mono font-bold text-indigo-400 bg-slate-900 px-2 py-0.5 rounded text-2xs shrink-0">
                  Step {idx + 1}
                </span>
                <p className="leading-snug">{step}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
