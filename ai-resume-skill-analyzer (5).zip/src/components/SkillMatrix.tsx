import React, { useState, useMemo } from 'react';
import { SkillMatch, MatchStatus } from '../types/analyzer';
import { CheckCircle2, AlertCircle, XCircle, HelpCircle, Search, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { listItemVariants } from '../utils/motion';

interface SkillMatrixProps {
  matches: SkillMatch[];
  onNavigateToLearningHub?: () => void;
}

export const SkillMatrix: React.FC<SkillMatrixProps> = ({ matches, onNavigateToLearningHub }) => {
  const [activeFilter, setActiveFilter] = useState<'ALL' | MatchStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const counts = useMemo(() => {
    return {
      all: matches.length,
      matched: matches.filter((m) => m.status === 'MATCHED').length,
      partial: matches.filter((m) => m.status === 'PARTIAL').length,
      missing: matches.filter((m) => m.status === 'MISSING').length,
      unclear: matches.filter((m) => m.status === 'UNCLEAR').length,
    };
  }, [matches]);

  const filteredMatches = useMemo(() => {
    return matches.filter((m) => {
      const matchesStatus = activeFilter === 'ALL' || m.status === activeFilter;
      const matchesSearch =
        searchQuery === '' ||
        m.skill.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.jobRequirement.toLowerCase().includes(searchQuery.toLowerCase()) ||
        m.resumeEvidence.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [matches, activeFilter, searchQuery]);

  const renderStatusBadge = (status: MatchStatus) => {
    switch (status) {
      case 'MATCHED':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            MATCHED
          </span>
        );
      case 'PARTIAL':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
            PARTIAL
          </span>
        );
      case 'MISSING':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            MISSING
          </span>
        );
      case 'UNCLEAR':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-slate-700 bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded">
            <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
            UNCLEAR
          </span>
        );
    }
  };

  const renderPriorityBadge = (priority: string, isRequired: boolean) => {
    if (priority === 'HIGH') {
      return (
        <span className="text-2xs font-bold uppercase tracking-wider text-rose-700 bg-rose-100/70 border border-rose-200 px-1.5 py-0.5 rounded">
          High Priority
        </span>
      );
    }
    if (priority === 'MEDIUM') {
      return (
        <span className="text-2xs font-bold uppercase tracking-wider text-amber-700 bg-amber-100/70 border border-amber-200 px-1.5 py-0.5 rounded">
          Medium Priority
        </span>
      );
    }
    return (
      <span className="text-2xs font-medium uppercase tracking-wider text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
        Low / Secondary
      </span>
    );
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
      {/* Header & Filter Controls */}
      <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-slate-900">
            Requirement & Skill Alignment Matrix
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Transparent breakdown of mandatory and secondary job requirements against documented resume evidence.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Filter by skill or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
          </input>
        </div>
      </div>

      {/* Segmented Filter Bar */}
      <div className="px-5 py-3 border-b border-slate-200 bg-white flex flex-wrap items-center gap-2">
        <button
          onClick={() => setActiveFilter('ALL')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeFilter === 'ALL'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          All Requirements ({counts.all})
        </button>
        <button
          onClick={() => setActiveFilter('MATCHED')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeFilter === 'MATCHED'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          Strong Matches ({counts.matched})
        </button>
        <button
          onClick={() => setActiveFilter('PARTIAL')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeFilter === 'PARTIAL'
              ? 'bg-amber-600 text-white'
              : 'text-slate-600 hover:text-amber-700 hover:bg-amber-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-amber-500" />
          Partial / Related ({counts.partial})
        </button>
        <button
          onClick={() => setActiveFilter('MISSING')}
          className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
            activeFilter === 'MISSING'
              ? 'bg-rose-600 text-white'
              : 'text-slate-600 hover:text-rose-700 hover:bg-rose-50'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-rose-500" />
          Skill Gaps ({counts.missing})
        </button>
        {counts.unclear > 0 && (
          <button
            onClick={() => setActiveFilter('UNCLEAR')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeFilter === 'UNCLEAR'
                ? 'bg-slate-700 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Unclear / Ambiguous ({counts.unclear})
          </button>
        )}
      </div>

      {/* Table / Responsive Card View */}
      {filteredMatches.length === 0 ? (
        <div className="p-12 text-center text-slate-500 text-xs">
          No requirements found matching current filter criteria.
        </div>
      ) : (
        <div className="divide-y divide-slate-100 overflow-x-auto">
          {filteredMatches.map((item, idx) => {
            const isMissing = item.status === 'MISSING';
            return (
              <motion.div
                key={`${item.skill}-${idx}`}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.28,
                  delay: Math.min(idx * 0.04, 0.4),
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`p-4 transition-colors grid grid-cols-1 md:grid-cols-12 gap-3 items-start ${
                  isMissing
                    ? 'bg-rose-50/20 hover:bg-rose-50/40'
                    : 'hover:bg-slate-50/70'
                }`}
              >
                {/* Col 1: Skill & Requirement Type */}
                <div className="md:col-span-3 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-900">
                      {item.skill}
                    </span>
                    {item.isRequired ? (
                      <span className="text-2xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 px-1.5 py-0.2 rounded">
                        Required
                      </span>
                    ) : (
                      <span className="text-2xs font-normal text-slate-500">
                        Preferred
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {renderStatusBadge(item.status)}
                    {item.status !== 'MATCHED' && renderPriorityBadge(item.priority, item.isRequired)}
                  </div>
                </div>

                {/* Col 2: Resume Evidence & Job Context */}
                <div className="md:col-span-5 space-y-1">
                  <div className="text-xs text-slate-500 font-medium">
                    {item.jobRequirement}
                  </div>
                  <p className="text-xs text-slate-700 bg-slate-50 p-2.5 rounded border border-slate-200/60 leading-relaxed font-mono">
                    {item.resumeEvidence}
                  </p>
                </div>

                {/* Col 3: Analysis & What Is Missing */}
                <div className="md:col-span-4 space-y-1">
                  <p className="text-xs text-slate-600">
                    {item.explanation}
                  </p>
                  {item.missingComponent && (
                    <div className="text-2xs text-rose-800 bg-rose-50/80 border border-rose-200/80 p-2.5 rounded-lg space-y-1">
                      <p className="font-bold text-rose-900">Why it matters & Target expectation:</p>
                      <p>{item.missingComponent}</p>
                      <div className="pt-1 border-t border-rose-200/60 mt-1 flex flex-col gap-0.5">
                        <span className="font-semibold text-rose-950">How to demonstrate:</span>
                        <span className="text-rose-800">
                          Include a targeted project bullet or certification highlighting production implementation of {item.skill}.
                        </span>
                      </div>
                    </div>
                  )}
                  {item.candidateEquivalentSkill && (
                    <div className="text-2xs text-amber-800 bg-amber-50/80 border border-amber-200/80 p-2.5 rounded-lg space-y-1">
                      <p className="font-bold text-amber-900">Bridge from existing skill:</p>
                      <p>
                        You have <strong>{item.candidateEquivalentSkill}</strong>. Frame your experience to emphasize how concepts transfer to <strong>{item.skill}</strong>.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Bridge to Personalized Learning & Career Hub */}
      {onNavigateToLearningHub && (
        <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 border-t border-indigo-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-2xs font-bold uppercase tracking-wider text-indigo-900 block">
              Skill Gaps Identified?
            </span>
            <p className="text-xs text-indigo-950 font-medium">
              Explore your Personalized Learning & Career Hub to close these gaps with verified courses, documentation, and a 30-60-90 day roadmap.
            </p>
          </div>
          <button
            type="button"
            onClick={onNavigateToLearningHub}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-colors shrink-0 shadow-2xs cursor-pointer flex items-center gap-1.5"
          >
            <span>🚀 What Should You Learn Next? →</span>
          </button>
        </div>
      )}
    </div>
  );
};
