import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

// Registered users table linked to Firebase Auth UID or email/password account
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Auth UID
  email: text('email').notNull(),
  passwordHash: text('password_hash'),
  displayName: text('display_name'),
  photoUrl: text('photo_url'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Candidate professional profile & career credentials
export const userCredentials = pgTable('user_credentials', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  targetRole: text('target_role'),
  targetCompany: text('target_company'),
  experienceLevel: text('experience_level'),
  portfolioUrl: text('portfolio_url'),
  githubUrl: text('github_url'),
  linkedinUrl: text('linkedin_url'),
  careerSummary: text('career_summary'),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Saved resume evaluations & comparison history
export const savedAnalyses = pgTable('saved_analyses', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  candidateName: text('candidate_name'),
  targetRole: text('target_role').notNull(),
  targetCompany: text('target_company'),
  totalScore: integer('total_score').notNull(),
  alignmentLevel: text('alignment_level').notNull(),
  reportData: text('report_data').notNull(), // JSON string
  createdAt: timestamp('created_at').defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  credentials: one(userCredentials, {
    fields: [users.id],
    references: [userCredentials.userId],
  }),
  savedAnalyses: many(savedAnalyses),
}));

export const userCredentialsRelations = relations(userCredentials, ({ one }) => ({
  user: one(users, {
    fields: [userCredentials.userId],
    references: [users.id],
  }),
}));

export const savedAnalysesRelations = relations(savedAnalyses, ({ one }) => ({
  user: one(users, {
    fields: [savedAnalyses.userId],
    references: [users.id],
  }),
}));
