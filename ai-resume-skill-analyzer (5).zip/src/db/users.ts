import { db } from './index.ts';
import { users, userCredentials, savedAnalyses } from './schema.ts';
import { eq, and, desc } from 'drizzle-orm';

export interface UserRecord {
  id: number;
  uid: string;
  email: string;
  displayName: string | null;
  photoUrl: string | null;
  passwordHash?: string | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

export interface UserCredentialData {
  targetRole?: string;
  targetCompany?: string;
  experienceLevel?: string;
  portfolioUrl?: string;
  githubUrl?: string;
  linkedinUrl?: string;
  careerSummary?: string;
}

export async function getOrCreateUser(
  uid: string,
  email: string,
  displayName?: string,
  photoUrl?: string
): Promise<UserRecord> {
  try {
    const normalizedEmail = (email || '').trim().toLowerCase();
    const result = await db
      .insert(users)
      .values({
        uid,
        email: normalizedEmail,
        displayName: displayName || null,
        photoUrl: photoUrl || null,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: normalizedEmail,
          displayName: displayName || null,
          photoUrl: photoUrl || null,
          updatedAt: new Date(),
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Failed to get or create user:', error);
    throw new Error('Database operation failed. Unable to authenticate user.', { cause: error });
  }
}

export async function getUserByUid(uid: string): Promise<UserRecord | null> {
  try {
    const rows = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
    return rows[0] || null;
  } catch (error) {
    console.error('Failed to get user by uid:', error);
    throw new Error('Database query failed. Unable to fetch user profile.', { cause: error });
  }
}

export async function getUserByEmail(email: string): Promise<UserRecord | null> {
  try {
    const normalized = (email || '').trim().toLowerCase();
    const rows = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
    return rows[0] || null;
  } catch (error) {
    console.error('Failed to get user by email:', error);
    throw new Error('Database query failed. Unable to fetch user by email.', { cause: error });
  }
}

export async function createUserWithCredentials(
  email: string,
  passwordHash: string,
  displayName?: string
): Promise<UserRecord> {
  try {
    const normalized = email.trim().toLowerCase();
    const uid = 'usr_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
    const result = await db
      .insert(users)
      .values({
        uid,
        email: normalized,
        passwordHash,
        displayName: displayName || normalized.split('@')[0],
        photoUrl: null,
        updatedAt: new Date(),
      })
      .returning();
    return result[0];
  } catch (error) {
    console.error('Failed to create user with credentials:', error);
    throw new Error('Database operation failed. Unable to register user.', { cause: error });
  }
}

export async function setUserPassword(userId: number, passwordHash: string): Promise<UserRecord> {
  try {
    const updated = await db
      .update(users)
      .set({ passwordHash, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updated[0];
  } catch (error) {
    console.error('Failed to set user password:', error);
    throw new Error('Database operation failed. Unable to set password.', { cause: error });
  }
}

export async function getUserCredentials(userId: number) {
  try {
    const rows = await db
      .select()
      .from(userCredentials)
      .where(eq(userCredentials.userId, userId))
      .limit(1);
    return rows[0] || null;
  } catch (error) {
    console.error('Failed to fetch user credentials:', error);
    throw new Error('Database query failed. Unable to retrieve credentials.', { cause: error });
  }
}

export async function upsertUserCredentials(userId: number, data: UserCredentialData) {
  try {
    const existing = await getUserCredentials(userId);
    if (existing) {
      const updated = await db
        .update(userCredentials)
        .set({
          ...data,
          updatedAt: new Date(),
        })
        .where(eq(userCredentials.id, existing.id))
        .returning();
      return updated[0];
    } else {
      const created = await db
        .insert(userCredentials)
        .values({
          userId,
          targetRole: data.targetRole || null,
          targetCompany: data.targetCompany || null,
          experienceLevel: data.experienceLevel || null,
          portfolioUrl: data.portfolioUrl || null,
          githubUrl: data.githubUrl || null,
          linkedinUrl: data.linkedinUrl || null,
          careerSummary: data.careerSummary || null,
        })
        .returning();
      return created[0];
    }
  } catch (error) {
    console.error('Failed to upsert credentials:', error);
    throw new Error('Database operation failed. Unable to update credentials.', { cause: error });
  }
}

export async function getUserSavedAnalyses(userId: number) {
  try {
    return await db
      .select()
      .from(savedAnalyses)
      .where(eq(savedAnalyses.userId, userId))
      .orderBy(desc(savedAnalyses.createdAt));
  } catch (error) {
    console.error('Failed to fetch user saved analyses:', error);
    throw new Error('Database query failed. Unable to fetch saved reports.', { cause: error });
  }
}

export async function saveAnalysisReport(
  userId: number,
  data: {
    candidateName?: string;
    targetRole: string;
    targetCompany?: string;
    totalScore: number;
    alignmentLevel: string;
    reportData: any;
  }
) {
  try {
    const serializedReport = typeof data.reportData === 'string'
      ? data.reportData
      : JSON.stringify(data.reportData);

    const inserted = await db
      .insert(savedAnalyses)
      .values({
        userId,
        candidateName: data.candidateName || 'Candidate',
        targetRole: data.targetRole,
        targetCompany: data.targetCompany || 'Target Company',
        totalScore: Math.round(data.totalScore),
        alignmentLevel: data.alignmentLevel,
        reportData: serializedReport,
      })
      .returning();

    return inserted[0];
  } catch (error) {
    console.error('Failed to save analysis report:', error);
    throw new Error('Database operation failed. Unable to save analysis report.', { cause: error });
  }
}

export async function deleteSavedAnalysis(userId: number, analysisId: number) {
  try {
    const deleted = await db
      .delete(savedAnalyses)
      .where(and(eq(savedAnalyses.id, analysisId), eq(savedAnalyses.userId, userId)))
      .returning();
    return deleted.length > 0;
  } catch (error) {
    console.error('Failed to delete saved analysis:', error);
    throw new Error('Database operation failed. Unable to remove analysis.', { cause: error });
  }
}
