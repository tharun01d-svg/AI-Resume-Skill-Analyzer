export interface RoleCompetencies {
  industry: string;
  department: string;
  requiredSkills: string[];
  preferredSkills: string[];
  responsibilities: string[];
  minYears: number;
}

export function getCompetenciesForRole(roleTitle: string, seniority: string = '2–4 Years'): RoleCompetencies {
  const norm = roleTitle.toLowerCase();

  let minYears = 2;
  if (seniority.includes('Intern')) minYears = 0;
  else if (seniority.includes('Entry') || seniority.includes('0–2') || seniority.includes('Junior')) minYears = 1;
  else if (seniority.includes('4–7')) minYears = 4;
  else if (seniority.includes('7–10') || seniority.includes('Lead')) minYears = 7;
  else if (seniority.includes('10+') || seniority.includes('Director') || seniority.includes('Executive')) minYears = 10;
  else if (seniority.includes('Manager')) minYears = 6;

  // 1. Data Scientist / ML / AI
  if (norm.includes('data scientist') || norm.includes('machine learning') || norm.includes('ai engineer') || norm.includes('nlp') || norm.includes('computer vision')) {
    return {
      industry: 'Artificial Intelligence & Advanced Analytics',
      department: 'Data & AI',
      requiredSkills: ['Python', 'SQL', 'Machine Learning', 'Data Analysis', 'Statistics'],
      preferredSkills: ['PyTorch', 'TensorFlow', 'Scikit-Learn', 'Data Pipelines', 'Pandas', 'Cloud Platforms'],
      responsibilities: [
        'Formulate predictive models and conduct deep exploratory data analysis.',
        'Collaborate with product and engineering teams to deploy models to production.',
        'Design experimentation frameworks, A/B testing methodologies, and metrics dashboards.',
      ],
      minYears,
    };
  }

  // 2. Data Analyst / BI / Analytics Engineer
  if (norm.includes('data analyst') || norm.includes('business intelligence') || norm.includes('analytics engineer')) {
    return {
      industry: 'Business Analytics & Data Operations',
      department: 'Analytics',
      requiredSkills: ['SQL', 'Data Analysis', 'Tableau', 'Power BI', 'Excel'],
      preferredSkills: ['Python', 'Data Warehousing', 'ETL / Data Pipelines', 'Business Analysis', 'Metrics Design'],
      responsibilities: [
        'Deliver business insights and automated reporting dashboards for stakeholders.',
        'Extract, clean, and validate complex relational data schemas.',
        'Identify operational bottlenecks and recommend metric-driven interventions.',
      ],
      minYears,
    };
  }

  // 3. Product Manager / Program Manager
  if (norm.includes('product manager') || norm.includes('product owner') || norm.includes('program manager')) {
    return {
      industry: 'Product Strategy & Technology Management',
      department: 'Product Management',
      requiredSkills: ['Product Strategy', 'User Research', 'Product Analytics', 'Roadmapping', 'Stakeholder Management'],
      preferredSkills: ['Agile / Scrum', 'A/B Testing', 'PRD Documentation', 'Cross-functional Leadership', 'Jira'],
      responsibilities: [
        'Define product vision, customer journey personas, and outcome-oriented roadmaps.',
        'Lead sprint prioritizations, write functional PRDs, and partner with engineering leads.',
        'Analyze user engagement data and telemetry to optimize feature retention.',
      ],
      minYears,
    };
  }

  // 4. Frontend Developer / UI Engineer
  if (norm.includes('frontend') || norm.includes('web developer')) {
    return {
      industry: 'Web & Client Applications',
      department: 'Engineering',
      requiredSkills: ['JavaScript', 'TypeScript', 'React', 'HTML', 'CSS'],
      preferredSkills: ['Next.js', 'Tailwind CSS', 'Redux', 'REST APIs', 'Unit Testing', 'Web Performance'],
      responsibilities: [
        'Architect responsive, accessible user interfaces with clean state management.',
        'Collaborate with UX designers to translate wireframes into interactive prototypes.',
        'Profile web vital benchmarks and eliminate client-side render bottlenecks.',
      ],
      minYears,
    };
  }

  // 5. Backend Developer / Systems Engineer
  if (norm.includes('backend') || norm.includes('software developer') || norm.includes('software engineer') || norm.includes('full stack')) {
    const isFullStack = norm.includes('full stack');
    return {
      industry: 'Software Engineering & Cloud Platforms',
      department: 'Engineering',
      requiredSkills: isFullStack
        ? ['Python', 'JavaScript', 'React', 'SQL', 'Git']
        : ['Python', 'SQL', 'REST APIs', 'System Design', 'Git'],
      preferredSkills: isFullStack
        ? ['Node.js', 'Docker', 'AWS', 'PostgreSQL', 'CI/CD', 'TypeScript']
        : ['Docker', 'AWS', 'PostgreSQL', 'Microservices', 'CI/CD', 'Linux'],
      responsibilities: [
        'Design and deploy resilient APIs and scalable backend microservices.',
        'Ensure database normalization, transactional integrity, and query optimization.',
        'Maintain automated unit and integration tests with continuous deployment pipelines.',
      ],
      minYears,
    };
  }

  // 6. DevOps / SRE / Cloud Engineer / Infrastructure
  if (norm.includes('devops') || norm.includes('site reliability') || norm.includes('cloud') || norm.includes('infrastructure')) {
    return {
      industry: 'Cloud Infrastructure & Reliability',
      department: 'Infrastructure',
      requiredSkills: ['Docker', 'Kubernetes', 'CI/CD', 'Linux', 'AWS'],
      preferredSkills: ['Terraform', 'Bash', 'GCP', 'Python', 'Monitoring & Alerting', 'Git'],
      responsibilities: [
        'Automate deployment pipelines and manage multi-region cloud clusters.',
        'Implement Infrastructure as Code (IaC) and container orchestration with Kubernetes.',
        'Monitor service-level indicators (SLIs) and conduct root-cause blameless postmortems.',
      ],
      minYears,
    };
  }

  // 7. Security / Cybersecurity
  if (norm.includes('security') || norm.includes('penetration') || norm.includes('cyber')) {
    return {
      industry: 'Information Security & Risk Management',
      department: 'Security Operations',
      requiredSkills: ['Cybersecurity', 'Vulnerability Assessment', 'Network Security', 'Incident Response', 'Linux'],
      preferredSkills: ['SIEM', 'Cloud Security', 'Penetration Testing', 'Python', 'Identity & Access Management (IAM)'],
      responsibilities: [
        'Conduct threat modeling, vulnerability scans, and security risk assessments.',
        'Monitor SIEM telemetry for intrusion events and lead incident response actions.',
        'Audit access controls and verify regulatory compliance across technical infrastructure.',
      ],
      minYears,
    };
  }

  // 8. Marketing Manager / Digital Marketing
  if (norm.includes('marketing') || norm.includes('seo') || norm.includes('growth')) {
    return {
      industry: 'Digital Marketing & Growth Strategy',
      department: 'Marketing',
      requiredSkills: ['Digital Marketing', 'Marketing Analytics', 'Content Strategy', 'SEO / SEM', 'Campaign Management'],
      preferredSkills: ['Google Analytics', 'A/B Testing', 'Social Media Strategy', 'Email Marketing', 'Brand Management'],
      responsibilities: [
        'Design multi-channel customer acquisition funnels and track conversion attribution.',
        'Execute content and search optimization initiatives to drive organic traffic.',
        'Analyze campaign ROI and present quarterly growth performance to leadership.',
      ],
      minYears,
    };
  }

  // 9. Finance / Accounting / Investment
  if (norm.includes('finance') || norm.includes('accountant') || norm.includes('investment') || norm.includes('banking')) {
    return {
      industry: 'Corporate Finance & Capital Markets',
      department: 'Finance',
      requiredSkills: ['Financial Modeling', 'Financial Analysis', 'Excel', 'Accounting', 'Forecasting'],
      preferredSkills: ['Valuation', 'Variance Analysis', 'ERP Systems', 'SQL', 'Power BI'],
      responsibilities: [
        'Construct multi-scenario financial forecasts, budget reconciliations, and cash flow models.',
        'Conduct variance analysis against executive targets and present quarterly forecasts.',
        'Audit regulatory reporting schedules and verify accounting compliance.',
      ],
      minYears,
    };
  }

  // 10. UI/UX Designer / Product Designer
  if (norm.includes('designer') || norm.includes('ux') || norm.includes('ui')) {
    return {
      industry: 'Design & Human-Computer Interaction',
      department: 'Design',
      requiredSkills: ['Figma', 'UI/UX Design', 'User Research', 'Wireframing', 'Prototyping'],
      preferredSkills: ['Design Systems', 'Usability Testing', 'Interaction Design', 'Visual Design', 'Information Architecture'],
      responsibilities: [
        'Produce intuitive end-to-end user journeys, wireframes, and interactive mockups.',
        'Maintain and extend shared component design systems in Figma.',
        'Facilitate usability studies with target customers and iterate based on qualitative insights.',
      ],
      minYears,
    };
  }

  // 11. Human Resources / Talent Acquisition / Recruiter
  if (norm.includes('hr') || norm.includes('recruiter') || norm.includes('talent') || norm.includes('people')) {
    return {
      industry: 'Human Capital & Talent Operations',
      department: 'People Operations',
      requiredSkills: ['Talent Acquisition', 'Candidate Sourcing', 'Interviewing', 'HR Operations', 'Communication'],
      preferredSkills: ['Applicant Tracking Systems (ATS)', 'Stakeholder Management', 'Compensation Analysis', 'Employee Relations'],
      responsibilities: [
        'Manage full-lifecycle recruitment pipelines across multiple departments.',
        'Partner with hiring managers to calibrate candidate scorecards and compensation bands.',
        'Drive employer branding initiatives and foster inclusive workplace culture.',
      ],
      minYears,
    };
  }

  // Default fallback for general professional positions
  return {
    industry: 'Professional Technology & Business Operations',
    department: 'Operations & Strategy',
    requiredSkills: ['Project Management', 'Problem Solving', 'Communication', 'Data Analysis', 'Cross-functional Collaboration'],
    preferredSkills: ['Stakeholder Management', 'Process Optimization', 'Reporting', 'Strategic Planning'],
    responsibilities: [
      'Execute strategic workflows aligned with organizational milestones.',
      'Coordinate cross-functional deliverables and track key performance indicators.',
      'Document best practices and communicate progress updates to leadership.',
    ],
    minYears,
  };
}
