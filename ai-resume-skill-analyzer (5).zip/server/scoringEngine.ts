import {
  ResumeData,
  JobData,
  SkillMatch,
  ScoreResult,
  CategoryScore,
} from '../src/types/analyzer';

export function calculateExplainableScore(
  resume: ResumeData,
  job: JobData,
  matches: SkillMatch[]
): ScoreResult {
  // 1. Separate Required vs Preferred matches
  const reqMatches = matches.filter((m) => m.isRequired);
  const prefMatches = matches.filter((m) => !m.isRequired);

  const matchedCount = matches.filter((m) => m.status === 'MATCHED').length;
  const partialCount = matches.filter((m) => m.status === 'PARTIAL').length;
  const missingCount = matches.filter((m) => m.status === 'MISSING').length;

  // 10-CATEGORY WEIGHT MODEL (Sum = 100)
  const defaultWeights = {
    required_skills: 20,
    preferred_skills: 10,
    experience: 15,
    projects: 10,
    education: 10,
    certifications: 5,
    resume_quality: 10,
    ats_readiness: 10,
    content_clarity: 5,
    achievement_strength: 5,
  };

  // --- Category 1: Required Skills (20 pts) ---
  let reqEarned = 0;
  const reqMax = defaultWeights.required_skills;
  let reqExplanation = '';
  let reqDetails = '';

  if (reqMatches.length > 0) {
    let reqFactorSum = 0;
    for (const m of reqMatches) {
      if (m.status === 'MATCHED') reqFactorSum += 1.0;
      else if (m.status === 'PARTIAL') reqFactorSum += 0.5;
      else if (m.status === 'UNCLEAR') reqFactorSum += 0.25;
    }
    const ratio = reqFactorSum / reqMatches.length;
    reqEarned = Math.round(ratio * reqMax * 10) / 10;
    const matchedReqs = reqMatches.filter((m) => m.status === 'MATCHED');
    const missingReqs = reqMatches.filter((m) => m.status === 'MISSING');
    reqDetails = `${matchedReqs.length} verified matched, ${reqMatches.filter((m) => m.status === 'PARTIAL').length} partial out of ${reqMatches.length} mandatory qualifications.`;

    if (missingReqs.length === 0 && ratio >= 0.85) {
      reqExplanation = 'All core mandatory technical requirements are solidly demonstrated with verified resume evidence.';
    } else if (missingReqs.length > 0) {
      const topMissing = missingReqs.slice(0, 2).map((m) => m.skill).join(' and ');
      reqExplanation = `Most required core competencies are demonstrated, but ${topMissing} evidence should be strengthened.`;
    } else {
      reqExplanation = 'Core mandatory qualifications are partially demonstrated with opportunities to provide more production evidence.';
    }
  } else {
    reqEarned = Math.min(reqMax, Math.round(((resume.technical_skills?.length || 0) / 6) * reqMax * 10) / 10);
    reqExplanation = 'Core mandatory technical foundations match standard expectations for this target profile.';
    reqDetails = `${resume.technical_skills?.length || 0} core technical skills detected across candidate profile.`;
  }
  const reqPct = Math.min(100, Math.round((reqEarned / reqMax) * 100));

  // --- Category 2: Preferred Skills (10 pts) ---
  let prefEarned = 0;
  let prefMax = defaultWeights.preferred_skills;
  let prefApplicable = true;
  let prefExplanation = '';
  let prefDetails = '';

  if (prefMatches.length > 0) {
    let prefFactorSum = 0;
    for (const m of prefMatches) {
      if (m.status === 'MATCHED') prefFactorSum += 1.0;
      else if (m.status === 'PARTIAL') prefFactorSum += 0.5;
      else if (m.status === 'UNCLEAR') prefFactorSum += 0.25;
    }
    const ratio = prefFactorSum / prefMatches.length;
    prefEarned = Math.round(ratio * prefMax * 10) / 10;
    const prefMatched = prefMatches.filter((m) => m.status === 'MATCHED');
    prefDetails = `${prefMatched.length} demonstrated out of ${prefMatches.length} secondary/preferred capabilities.`;
    prefExplanation = prefMatched.length >= Math.ceil(prefMatches.length / 2)
      ? 'Strong bonus alignment with nice-to-have tools and specialized domain competencies.'
      : 'Several preferred tools or bonus skills are missing, though not strictly disqualifying.';
  } else {
    prefApplicable = false;
    prefEarned = 0;
    prefMax = 0;
    prefExplanation = 'Target role does not specify separate preferred qualifications; weight neutralized.';
    prefDetails = 'Role criteria focus exclusively on mandatory standards.';
  }
  const prefPct = prefApplicable && prefMax > 0 ? Math.min(100, Math.round((prefEarned / prefMax) * 100)) : 100;

  // --- Category 3: Experience Alignment (15 pts) ---
  const candYears = resume.total_experience_years || 0;
  const reqMinYears = job.experience_requirements?.min_years ?? 0;
  let expEarned = 0;
  const expMax = defaultWeights.experience;
  let expExplanation = '';
  let expDetails = '';

  if (reqMinYears <= 0) {
    if (candYears >= 1 || (resume.work_experience && resume.work_experience.length > 0)) {
      expEarned = expMax;
      expExplanation = `Experience matches target level: Candidate holds ${candYears} year(s) of relevant experience.`;
      expDetails = `Candidate career trajectory demonstrates readiness for entry/early career responsibilities.`;
    } else {
      expEarned = 12;
      expExplanation = 'Candidate is assessed primarily on academic, practical project, and foundational readiness.';
      expDetails = 'Early-career profile with active portfolio development.';
    }
  } else {
    const ratio = candYears / reqMinYears;
    if (ratio >= 1.0) {
      expEarned = expMax;
      expExplanation = `Experience depth meets target expectations (${candYears} yrs vs ${reqMinYears}+ yrs target).`;
      expDetails = `Candidate exceeds minimum professional duration requirement with full seniority alignment.`;
    } else if (ratio >= 0.7) {
      expEarned = 11;
      expExplanation = `Close experience alignment (${candYears} yrs against ${reqMinYears} yrs requested). High trajectory.`;
      expDetails = `Candidate is near the experience threshold and can bridge the gap via verified project complexity.`;
    } else if (ratio >= 0.4) {
      expEarned = 7;
      expExplanation = `Moderate experience gap: Candidate has ${candYears} yrs, while target role requests ${reqMinYears}+ yrs.`;
      expDetails = `Seniority level may be challenging without strong leadership and architecture evidence.`;
    } else {
      expEarned = 4;
      expExplanation = `Significant experience gap: ${candYears} yrs vs ${reqMinYears}+ yrs target requirement.`;
      expDetails = `Candidate will need extensive portfolio demonstration to satisfy level expectations.`;
    }
  }
  const expPct = Math.min(100, Math.round((expEarned / expMax) * 100));

  // --- Category 4: Project Relevance (10 pts) ---
  const projCount = resume.projects?.length || 0;
  let projEarned = 0;
  const projMax = defaultWeights.projects;
  let projExplanation = '';
  let projDetails = '';

  const demonstratedProjects = (resume.projects || []).filter(
    (p) =>
      p.evidence_strength === 'Strongly demonstrated' ||
      p.evidence_strength === 'Demonstrated' ||
      p.evidence_strength === 'Explicit'
  ).length;

  if (demonstratedProjects >= 2 || projCount >= 3) {
    projEarned = 10;
    projExplanation = 'Projects show practical architectural depth, end-to-end ownership, and relevant technologies.';
    projDetails = `${demonstratedProjects} project(s) demonstrate direct technical and domain alignment.`;
  } else if (demonstratedProjects === 1 || projCount >= 1) {
    projEarned = 7;
    projExplanation = 'Projects demonstrate functional fundamentals, but could showcase higher scale and measurable outcomes.';
    projDetails = `${projCount} project(s) documented with partial architectural depth.`;
  } else {
    projEarned = 3;
    projExplanation = 'Limited practical project evidence; building domain-specific portfolio projects is strongly advised.';
    projDetails = 'Recommend adding 1-2 production-grade projects demonstrating target stack.';
  }
  const projPct = Math.min(100, Math.round((projEarned / projMax) * 100));

  // --- Category 5: Education (10 pts) ---
  const eduCount = resume.education?.length || 0;
  let eduEarned = 0;
  const eduMax = defaultWeights.education;
  let eduExplanation = '';
  let eduDetails = '';

  const eduReqs = job.education_requirements || [];
  if (eduReqs.length === 0) {
    if (eduCount > 0) {
      eduEarned = 10;
      eduExplanation = 'Educational background satisfies standard expectations without rigid degree gating.';
      eduDetails = `Degree: ${resume.education[0]?.degree || 'Degree'} from ${resume.education[0]?.institution || 'Institution'}.`;
    } else {
      eduEarned = 8.5;
      eduExplanation = 'Role evaluates skills and practical experience; education is not a gating factor.';
      eduDetails = 'Industry experience and portfolio outweigh formal degree requirements.';
    }
  } else {
    const candDegree = (resume.education?.[0]?.degree || '').toLowerCase();
    const candField = (resume.education?.[0]?.field || '').toLowerCase();
    const matchesEdu = eduReqs.some(
      (r) =>
        candDegree.includes(r.toLowerCase()) ||
        candField.includes(r.toLowerCase()) ||
        r.toLowerCase().includes(candDegree)
    );

    if (matchesEdu || candField.includes('computer') || candField.includes('engineer') || candField.includes('science')) {
      eduEarned = 10;
      eduExplanation = 'Formal education directly aligns with target technical qualification criteria.';
      eduDetails = `${resume.education[0]?.degree} in ${resume.education[0]?.field || 'Technical Field'}.`;
    } else if (eduCount > 0) {
      eduEarned = 8;
      eduExplanation = `Candidate holds recognized degree in ${resume.education[0]?.field || 'related discipline'}.`;
      eduDetails = 'Interdisciplinary background with transferable analytical foundations.';
    } else {
      eduEarned = 6;
      eduExplanation = 'Formal university credential not explicitly detailed on resume.';
      eduDetails = 'Candidate assessed on verified hands-on engineering competencies.';
    }
  }
  const eduPct = Math.min(100, Math.round((eduEarned / eduMax) * 100));

  // --- Category 6: Certifications (5 pts) ---
  const certReqs = job.certifications || [];
  const candCerts = resume.certifications || [];
  let certEarned = 0;
  let certMax = defaultWeights.certifications;
  let certApplicable = true;
  let certExplanation = '';
  let certDetails = '';

  if (certReqs.length > 0) {
    const hasMatch = candCerts.some((cc) =>
      certReqs.some((cr) => cc.toLowerCase().includes(cr.toLowerCase()) || cr.toLowerCase().includes(cc.toLowerCase()))
    );
    if (hasMatch) {
      certEarned = 5;
      certExplanation = 'Candidate possesses target-certified credentials matching role standards.';
      certDetails = `Matched certification: ${candCerts[0]}.`;
    } else if (candCerts.length > 0) {
      certEarned = 3.5;
      certExplanation = 'Candidate has professional certifications, though not the exact ones requested by the job.';
      certDetails = `${candCerts.length} active credential(s) demonstrated.`;
    } else {
      certEarned = 1;
      certExplanation = `Target role specifically highlights certifications (${certReqs.slice(0, 2).join(', ')}).`;
      certDetails = 'Completing a recognized cloud/domain certification will enhance profile strength.';
    }
  } else {
    if (candCerts.length > 0) {
      certEarned = 5;
      certExplanation = `Strong bonus: Candidate holds ${candCerts.length} verified credential(s) (${candCerts.slice(0, 2).join(', ')}).`;
      certDetails = 'Demonstrates continuous self-directed learning and professional development.';
    } else {
      certApplicable = false;
      certMax = 0;
      certEarned = 0;
      certExplanation = 'Role does not mandate formal certifications. Category neutralized without penalty.';
      certDetails = 'Evaluated on core engineering and architecture skills.';
    }
  }
  const certPct = certApplicable && certMax > 0 ? Math.min(100, Math.round((certEarned / certMax) * 100)) : 100;

  // --- Category 7: Resume Quality (10 pts) ---
  const qualityScore = resume.resume_quality?.overall_score || 3.8;
  const qualEarned = Math.round(Math.min(10, Math.max(2, (qualityScore / 5) * defaultWeights.resume_quality)) * 10) / 10;
  const qualMax = defaultWeights.resume_quality;
  const qualPct = Math.min(100, Math.round((qualEarned / qualMax) * 100));
  const qualExplanation = qualityScore >= 4.0
    ? 'Clear visual hierarchy, strong action verbs, and clean section demarcation throughout.'
    : 'Good overall layout; converting generic responsibilities into high-impact accomplishment bullets will lift quality.';
  const qualDetails = `Structure: ${resume.resume_quality?.structure_score || 4}/5 · Action Verbs: ${resume.resume_quality?.action_verbs_score || 4}/5 · ATS Readability: ${resume.resume_quality?.ats_readability || 'High'}.`;

  // --- Category 8: ATS Readiness (10 pts) ---
  const atsReadability = resume.resume_quality?.ats_readability || 'High';
  let atsEarned = 8.5;
  if (atsReadability === 'High') atsEarned = 9.5;
  else if (atsReadability === 'Low') atsEarned = 5.0;
  else atsEarned = 7.5;
  const atsMax = defaultWeights.ats_readiness;
  const atsPct = Math.min(100, Math.round((atsEarned / atsMax) * 100));
  const atsExplanation = atsReadability === 'High'
    ? 'Standard headings, parseable contact metadata, and clean linear layout ensure seamless applicant tracking parsing.'
    : 'Ensure standard section labels (Experience, Education, Skills) and avoid multi-column graphic tables.';
  const atsDetails = `Scannable section titles, chronological organization, and standard font parsing verified.`;

  // --- Category 9: Content Clarity (5 pts) ---
  const bulletScore = resume.resume_quality?.bullet_quality_score || 3.5;
  const clarityEarned = Math.round(Math.min(5, Math.max(1, (bulletScore / 5) * defaultWeights.content_clarity)) * 10) / 10;
  const clarityMax = defaultWeights.content_clarity;
  const clarityPct = Math.min(100, Math.round((clarityEarned / clarityMax) * 100));
  const clarityExplanation = bulletScore >= 4.0
    ? 'Concise sentences, strong active voice, and minimal filler buzzwords or passive constructions.'
    : 'Some bullet points are slightly wordy or passive; trimming filler words will sharpen narrative impact.';
  const clarityDetails = `Evaluated on sentence conciseness, professional vocabulary, and elimination of generic clichés.`;

  // --- Category 10: Achievement Strength (5 pts) ---
  const impactScore = resume.resume_quality?.quantified_impact_score || 3.0;
  const achEarned = Math.round(Math.min(5, Math.max(1, (impactScore / 5) * defaultWeights.achievement_strength)) * 10) / 10;
  const achMax = defaultWeights.achievement_strength;
  const achPct = Math.min(100, Math.round((achEarned / achMax) * 100));
  const achExplanation = impactScore >= 4.0
    ? 'Robust quantifiable outcomes (percentages, performance benchmarks, throughput) demonstrate verified business value.'
    : 'Several bullets describe duties rather than measurable results. Consider adding metrics where you have them.';
  const achDetails = `${resume.quantified_impact?.length || 0} quantified metrics/outcomes detected across work experience and projects.`;

  // --- Normalization across applicable categories ---
  const totalApplicableWeight =
    reqMax +
    (prefApplicable ? defaultWeights.preferred_skills : 0) +
    expMax +
    projMax +
    eduMax +
    (certApplicable ? defaultWeights.certifications : 0) +
    qualMax +
    atsMax +
    clarityMax +
    achMax;

  const totalRawEarned =
    reqEarned +
    prefEarned +
    expEarned +
    projEarned +
    eduEarned +
    certEarned +
    qualEarned +
    atsEarned +
    clarityEarned +
    achEarned;

  const finalScore = Math.min(
    100,
    Math.max(0, Math.round((totalRawEarned / totalApplicableWeight) * 100))
  );

  let alignmentLevel: 'Strong Alignment' | 'Moderate Alignment' | 'Needs Improvement' =
    'Moderate Alignment';
  if (finalScore >= 75) {
    alignmentLevel = 'Strong Alignment';
  } else if (finalScore < 55) {
    alignmentLevel = 'Needs Improvement';
  }

  const categories: ScoreResult['categories'] = {
    required_skills: {
      name: 'Required Skills',
      earned: reqEarned,
      max: reqMax,
      weight_percent: defaultWeights.required_skills,
      normalized_earned: reqEarned,
      score_percentage: reqPct,
      explanation: reqExplanation,
      details: reqDetails,
      is_applicable: true,
      deep_analysis_key: 'skills',
    },
    preferred_skills: {
      name: 'Preferred Skills',
      earned: prefEarned,
      max: prefMax,
      weight_percent: defaultWeights.preferred_skills,
      normalized_earned: prefEarned,
      score_percentage: prefPct,
      explanation: prefExplanation,
      details: prefDetails,
      is_applicable: prefApplicable,
      deep_analysis_key: 'skills',
    },
    experience: {
      name: 'Experience Alignment',
      earned: expEarned,
      max: expMax,
      weight_percent: defaultWeights.experience,
      normalized_earned: expEarned,
      score_percentage: expPct,
      explanation: expExplanation,
      details: expDetails,
      is_applicable: true,
      deep_analysis_key: 'experience',
    },
    projects: {
      name: 'Project Relevance',
      earned: projEarned,
      max: projMax,
      weight_percent: defaultWeights.projects,
      normalized_earned: projEarned,
      score_percentage: projPct,
      explanation: projExplanation,
      details: projDetails,
      is_applicable: true,
      deep_analysis_key: 'projects',
    },
    education: {
      name: 'Education',
      earned: eduEarned,
      max: eduMax,
      weight_percent: defaultWeights.education,
      normalized_earned: eduEarned,
      score_percentage: eduPct,
      explanation: eduExplanation,
      details: eduDetails,
      is_applicable: true,
      deep_analysis_key: 'education',
    },
    certifications: {
      name: 'Certifications',
      earned: certEarned,
      max: certMax,
      weight_percent: defaultWeights.certifications,
      normalized_earned: certEarned,
      score_percentage: certPct,
      explanation: certExplanation,
      details: certDetails,
      is_applicable: certApplicable,
      deep_analysis_key: 'certifications',
    },
    resume_quality: {
      name: 'Resume Quality',
      earned: qualEarned,
      max: qualMax,
      weight_percent: defaultWeights.resume_quality,
      normalized_earned: qualEarned,
      score_percentage: qualPct,
      explanation: qualExplanation,
      details: qualDetails,
      is_applicable: true,
      deep_analysis_key: 'quality',
    },
    ats_readiness: {
      name: 'ATS Readiness',
      earned: atsEarned,
      max: atsMax,
      weight_percent: defaultWeights.ats_readiness,
      normalized_earned: atsEarned,
      score_percentage: atsPct,
      explanation: atsExplanation,
      details: atsDetails,
      is_applicable: true,
      deep_analysis_key: 'ats',
    },
    content_clarity: {
      name: 'Content Clarity',
      earned: clarityEarned,
      max: clarityMax,
      weight_percent: defaultWeights.content_clarity,
      normalized_earned: clarityEarned,
      score_percentage: clarityPct,
      explanation: clarityExplanation,
      details: clarityDetails,
      is_applicable: true,
      deep_analysis_key: 'language',
    },
    achievement_strength: {
      name: 'Achievement Strength',
      earned: achEarned,
      max: achMax,
      weight_percent: defaultWeights.achievement_strength,
      normalized_earned: achEarned,
      score_percentage: achPct,
      explanation: achExplanation,
      details: achDetails,
      is_applicable: true,
      deep_analysis_key: 'achievements',
    },
  };

  const formulaExplanation = `10-Category Weighted Deterministic Formula: [Earned Points (${totalRawEarned.toFixed(1)}) / Total Applicable Weight (${totalApplicableWeight})] × 100 = ${finalScore}/100. Evaluated against ${matches.length} target requirement benchmarks.`;

  return {
    totalScore: finalScore,
    alignmentLevel,
    summary: `Your resume demonstrates an alignment score of ${finalScore}/100 for ${job.job_title}. Identified ${matchedCount} verified match(es), ${partialCount} partial match(es), and ${missingCount} strategic capability gap(s).`,
    categories,
    matched_count: matchedCount,
    partial_count: partialCount,
    missing_count: missingCount,
    total_requirements_count: matches.length,
    formula_explanation: formulaExplanation,
  };
}
