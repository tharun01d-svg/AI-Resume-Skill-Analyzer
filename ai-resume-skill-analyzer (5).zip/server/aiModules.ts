import { generateContentWithRetry, safeJsonParse } from './gemini';
import {
  ResumeData,
  JobData,
  SkillMatch,
  ScoreResult,
  RecommendationData,
} from '../src/types/analyzer';
import {
  buildHeuristicResumeData,
  buildHeuristicJobData,
  buildHeuristicRecommendations,
} from './fallbackParser';

/**
 * AI MODULE 1: Deep Resume Analyzer
 * Extracts strictly verified semantic data and evidence levels from resume text.
 */
export async function analyzeResumeWithAI(resumeText: string): Promise<ResumeData> {
  const heuristic = buildHeuristicResumeData(resumeText);

  const prompt = `You are a high-level senior technical recruiter, career coach, and executive resume auditor analyzing a candidate's resume.
CRITICAL HALLUCINATION RULES:
1. NEVER invent, assume, or fabricate any skill, employer, project, metric, or credential not explicitly stated in the resume text.
2. If total experience years or education is not stated, calculate or extract only what is actually written.
3. For bullet rewrites: Use the Google X-Y-Z formula ("Accomplished [X] as measured by [Y], by doing [Z]"). NEVER invent fake metrics or numbers. If lacking metrics, advise the candidate to add a measured result if they have one.
4. Categorize skills without incorrectly merging unrelated technologies (Java ≠ JavaScript, Python ≠ Django, SQL ≠ PostgreSQL, AWS ≠ Azure, HTML ≠ React).
5. ATS analysis: Do NOT claim guaranteed ATS pass. Focus on objective structural best practices.

Return a STRICT JSON object matching this schema:
{
  "candidate": {
    "name": "string",
    "email": "string",
    "phone": "string",
    "location": "string",
    "linkedin": "string",
    "github": "string",
    "portfolio": "string",
    "professional_title": "string",
    "career_level": "string",
    "years_of_experience": number,
    "career_direction": "string",
    "identity_clarity": "string",
    "identity_evaluation": "string"
  },
  "professional_summary": "string",
  "career_level": "string",
  "total_experience_years": number,
  "education": [
    {
      "degree": "string",
      "field": "string",
      "institution": "string",
      "graduation_year": "string",
      "relevant_coursework": ["string"],
      "academic_achievements": ["string"],
      "relevance_to_role": "string"
    }
  ],
  "technical_skills": ["string"],
  "programming_languages": ["string"],
  "frameworks": ["string"],
  "libraries": ["string"],
  "databases": ["string"],
  "cloud_platforms": ["string"],
  "devops_tools": ["string"],
  "ai_ml_tools": ["string"],
  "data_tools": ["string"],
  "design_tools": ["string"],
  "business_tools": ["string"],
  "soft_skills": ["string"],
  "domain_skills": ["string"],
  "certifications": ["string"],
  "work_experience": [
    {
      "role": "string",
      "company": "string",
      "duration": "string",
      "years": number,
      "responsibilities": ["string"],
      "quantified_achievements": ["string"],
      "technologies_used": ["string"],
      "title_clarity": "string",
      "progression_note": "string",
      "technical_depth": "string",
      "business_impact": "string",
      "role_relevance": "string"
    }
  ],
  "projects": [
    {
      "name": "string",
      "description": "string",
      "technologies": ["string"],
      "problem_solved": "string",
      "candidate_contribution": "string",
      "complexity": "string",
      "relevance_to_role": "string",
      "technical_depth": "string",
      "outcome": "string",
      "clarity": "string",
      "evidence_strength": "Explicit" | "Strongly demonstrated" | "Demonstrated" | "Mentioned only" | "Weak evidence",
      "recommendations_to_strengthen": ["string"]
    }
  ],
  "achievements": ["string"],
  "responsibilities": ["string"],
  "quantified_impact": ["string"],
  "keywords": ["string"],
  "skills_with_evidence": [
    {
      "name": "string",
      "category": "programming_language" | "framework" | "library" | "database" | "cloud" | "devops" | "ai_ml" | "data" | "design" | "business" | "soft" | "domain",
      "evidence_level": "Explicit" | "Strongly demonstrated" | "Demonstrated" | "Mentioned only" | "Weak evidence",
      "context_evidence": "string"
    }
  ],
  "resume_quality": {
    "overall_score": number (1.0 to 5.0),
    "structure_score": number (1 to 5),
    "formatting_score": number (1 to 5),
    "bullet_quality_score": number (1 to 5),
    "action_verbs_score": number (1 to 5),
    "quantified_impact_score": number (1 to 5),
    "ats_readability": "High" | "Medium" | "Low",
    "strengths": ["string"],
    "weaknesses": ["string"]
  },
  "summary_analysis": {
    "current_summary": "string",
    "clarity_score": number (1 to 10),
    "relevance_score": number (1 to 10),
    "specificity_score": number (1 to 10),
    "career_positioning": "string",
    "keywords_present": ["string"],
    "generic_language_detected": ["string"],
    "evidence_evaluation": "string",
    "length_evaluation": "string",
    "impact_evaluation": "string",
    "problems": ["string"],
    "improved_summary": "string"
  },
  "detailed_work_analysis": [
    {
      "role": "string",
      "company": "string",
      "duration": "string",
      "title_clarity": "string",
      "career_progression": "string",
      "technical_depth": "string",
      "business_impact": "string",
      "role_relevance": "string",
      "seniority_alignment": "string",
      "bullets": [
        {
          "current": "string",
          "problem": "string",
          "why_it_matters": "string",
          "improved_version": "string",
          "rule_applied": "string",
          "metrics_guidance": "string"
        }
      ]
    }
  ],
  "achievement_analysis": {
    "overall_evaluation": "string",
    "impact_score": number,
    "scale_score": number,
    "ownership_score": number,
    "results_score": number,
    "leadership_score": number,
    "technical_contribution_score": number,
    "business_value_score": number,
    "weak_achievements": [
      {
        "original": "string",
        "critique": "string",
        "recommendation_to_strengthen": "string"
      }
    ]
  },
  "education_analysis": {
    "degree_evaluation": "string",
    "institution_evaluation": "string",
    "coursework_evaluation": "string",
    "relevance_to_role": "string",
    "penalty_note": "string",
    "key_highlights": ["string"]
  },
  "certification_analysis": {
    "relevance_evaluation": "string",
    "clarity_evaluation": "string",
    "duplication_detected": boolean,
    "duplication_notes": "string",
    "recommendations": ["string"]
  },
  "ats_analysis": {
    "overall_rating": "High" | "Medium" | "Needs Attention",
    "score_percentage": number,
    "disclaimer": "string",
    "section_headings": { "name": "Section Headings", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "formatting_simplicity": { "name": "Formatting Simplicity", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "text_extractability": { "name": "Text Extractability", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "contact_info_placement": { "name": "Contact Information Placement", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "date_consistency": { "name": "Date Consistency", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "job_title_clarity": { "name": "Job Title Clarity", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "keyword_placement": { "name": "Keyword Distribution", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "skills_readability": { "name": "Skills Readability", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "tables_columns_graphics": { "name": "Tables / Columns / Graphics", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "bullet_structure": { "name": "Bullet Structure", "status": "PASS" | "WARNING" | "FAIL", "detail": "string" },
    "actionable_recommendations": ["string"]
  },
  "language_writing_analysis": {
    "overall_score": number,
    "grammar_spelling": { "status": "Clean" | "Minor Issues" | "Needs Review", "examples": ["string"], "notes": "string" },
    "professional_tone": { "evaluation": "string", "style": "string" },
    "sentence_structure": { "evaluation": "string", "variety": "string" },
    "verb_strength": { "strong_verbs_used": ["string"], "weak_verbs_detected": ["string"], "advice": "string" },
    "redundancy_and_wordiness": { "detected_phrases": ["string"], "recommended_cuts": ["string"] },
    "passive_voice": { "count": number, "examples": ["string"] },
    "buzzwords_and_cliches": { "detected": ["string"], "replacement_advice": "string" }
  },
  "career_level_analysis": {
    "target_level": "string",
    "detected_level": "string",
    "match_assessment": "Strong Fit" | "Borderline / Stretch" | "Under-Leveled" | "Over-Qualified",
    "years_gap_analysis": "string",
    "scope_and_ownership_evaluation": "string",
    "expectations_met": ["string"],
    "areas_to_elevate": ["string"]
  },
  "improved_resume": {
    "header": {
      "name": "string",
      "title": "string",
      "email": "string",
      "phone": "string",
      "location": "string",
      "linkedin": "string",
      "github": "string",
      "portfolio": "string"
    },
    "professional_summary": "string",
    "skills_categorized": {
      "Category Name": ["string"]
    },
    "experience": [
      {
        "role": "string",
        "company": "string",
        "duration": "string",
        "location": "string",
        "bullets": ["string"]
      }
    ],
    "projects": [
      {
        "name": "string",
        "technologies": ["string"],
        "problem_solved": "string",
        "bullets": ["string"]
      }
    ],
    "education": [
      {
        "degree": "string",
        "institution": "string",
        "year": "string",
        "details": "string"
      }
    ],
    "certifications": ["string"]
  }
}

RESUME TEXT TO EVALUATE:
"""
${resumeText}
"""

Output ONLY a valid JSON object matching the schema above.
`;

  try {
    const response = await generateContentWithRetry({
      contents: prompt,
    });

    if (response?.text) {
      const parsed = safeJsonParse<ResumeData | null>(response.text, null);
      if (parsed && parsed.candidate && parsed.technical_skills) {
        // Merge with heuristic data to guarantee all required deep analysis fields exist
        return {
          ...heuristic,
          ...parsed,
          candidate: { ...heuristic.candidate, ...parsed.candidate },
          resume_quality: { ...heuristic.resume_quality, ...(parsed.resume_quality || {}) },
          summary_analysis: parsed.summary_analysis || heuristic.summary_analysis,
          detailed_work_analysis: (parsed.detailed_work_analysis && parsed.detailed_work_analysis.length > 0)
            ? parsed.detailed_work_analysis
            : heuristic.detailed_work_analysis,
          detailed_project_analysis: (parsed.projects && parsed.projects.length > 0)
            ? parsed.projects
            : heuristic.projects,
          categorized_skills: heuristic.categorized_skills,
          achievement_analysis: parsed.achievement_analysis || heuristic.achievement_analysis,
          education_analysis: parsed.education_analysis || heuristic.education_analysis,
          certification_analysis: parsed.certification_analysis || heuristic.certification_analysis,
          ats_analysis: parsed.ats_analysis || heuristic.ats_analysis,
          language_writing_analysis: parsed.language_writing_analysis || heuristic.language_writing_analysis,
          career_level_analysis: parsed.career_level_analysis || heuristic.career_level_analysis,
          improved_resume: parsed.improved_resume || heuristic.improved_resume,
        };
      }
    }
  } catch {
    // Intentionally suppressed for graceful fallback
  }

  return heuristic;
}

/**
 * AI MODULE 2: Deep Job Description Analyzer
 */
export async function analyzeJobWithAI(
  jobText: string,
  optionalMeta?: { title?: string; company?: string; level?: string }
): Promise<JobData> {
  const prompt = `You are an expert talent acquisition consultant analyzing a job description.
CRITICAL INSTRUCTIONS:
1. Deeply understand the job description and extract explicit and semantic requirements.
2. Distinguish strictly between:
   - "required_skills": Mandatory skills / non-negotiables explicitly mentioned as required/must-have.
   - "preferred_skills": Secondary skills mentioned as preferred/plus/bonus.
   - "nice_to_have": Optional or supplementary capabilities.
3. Automatically determine the seniority level (Intern, Entry Level, Junior, Mid Level, Senior, Lead, Manager, Senior Manager, Director, Executive).
4. Support any profession (Tech, Business, Marketing, Design, Sales, Healthcare, Finance, Operations, Legal, Management).

${optionalMeta?.title ? `User indicated Title: ${optionalMeta.title}` : ''}
${optionalMeta?.company ? `User indicated Company: ${optionalMeta.company}` : ''}
${optionalMeta?.level ? `User indicated Level: ${optionalMeta.level}` : ''}

JOB DESCRIPTION TEXT:
"""
${jobText}
"""

Return a STRICT JSON object with this exact schema:
{
  "job_title": "string",
  "company_inferred": "string",
  "seniority_level": "Intern" | "Entry Level" | "Junior" | "Mid Level" | "Senior" | "Lead" | "Manager" | "Senior Manager" | "Director" | "Executive",
  "department": "string",
  "industry": "string",
  "required_skills": ["string"],
  "preferred_skills": ["string"],
  "nice_to_have": ["string"],
  "technical_skills": ["string"],
  "programming_languages": ["string"],
  "frameworks": ["string"],
  "libraries": ["string"],
  "databases": ["string"],
  "cloud_platforms": ["string"],
  "tools": ["string"],
  "methodologies": ["string"],
  "soft_skills": ["string"],
  "domain_knowledge": ["string"],
  "certifications": ["string"],
  "education_requirements": ["string"],
  "experience_requirements": {
    "min_years": number,
    "preferred_years": number,
    "description": "string"
  },
  "responsibilities": ["string"],
  "role_expectations": ["string"],
  "leadership_requirements": ["string"],
  "communication_requirements": ["string"],
  "management_requirements": ["string"],
  "keywords": ["string"]
}

Output ONLY a valid JSON object matching the schema above.
`;

  try {
    const response = await generateContentWithRetry({
      contents: prompt,
    });

    if (response?.text) {
      const parsed = safeJsonParse<JobData | null>(response.text, null);
      if (parsed && parsed.job_title && (parsed.required_skills || parsed.technical_skills)) {
        return parsed;
      }
    }
  } catch {
    // Intentionally suppressed for graceful fallback
  }

  return buildHeuristicJobData(jobText, optionalMeta);
}

/**
 * AI MODULE 3: Recommendation Engine & Learning Roadmap
 */
export async function generateRecommendationsWithAI(
  resume: ResumeData,
  job: JobData,
  matches: SkillMatch[],
  scoreResult: ScoreResult,
  targetGoal?: string
): Promise<RecommendationData> {
  const missingSkills = matches.filter((m) => m.status === 'MISSING').map((m) => m.skill);
  const partialSkills = matches.filter((m) => m.status === 'PARTIAL').map((m) => m.skill);

  const prompt = `You are a high-level technical career coach and resume strategist.
A candidate just had their resume evaluated against a target job description with a deterministic scoring engine.
Current Alignment Score: ${scoreResult.totalScore}/100 (${scoreResult.alignmentLevel}).

TARGET JOB: ${job.job_title} (${job.seniority_level}) in ${job.industry || 'the industry'}
${targetGoal ? `CANDIDATE TARGET CAREER GOAL: "${targetGoal}"` : ''}

CANDIDATE EXPERIENCE: ${resume.total_experience_years || 0} years. Current level: ${resume.career_level}
IDENTIFIED SKILL GAPS (MISSING): ${JSON.stringify(missingSkills.slice(0, 10))}
PARTIAL / UNPROVEN SKILLS: ${JSON.stringify(partialSkills.slice(0, 10))}

EXISTING RESUME BULLET POINTS TO IMPROVE:
${JSON.stringify((resume.work_experience?.[0]?.responsibilities || []).slice(0, 3))}
${JSON.stringify((resume.projects?.[0]?.description ? [resume.projects[0].description] : []))}

INSTRUCTIONS:
1. Provide TOP 3-5 learning priorities. For each, give:
   - skill name
   - priority ("HIGH" for mandatory gaps, "MEDIUM" for preferred/partial, "LOW" for nice-to-have)
   - why it matters for this specific role
   - 4-6 concrete learning topics
   - a practical practice project idea
   - demonstrable evidence goal (what to put on GitHub/portfolio)
2. Provide 3-4 specific RESUME BULLET IMPROVEMENTS:
   - Choose actual weak bullets from candidate's resume
   - Rewrite them using the Google X-Y-Z formula ("Accomplished [X] as measured by [Y], by doing [Z]")
   - NEVER fabricate fake companies, fake dates, or imaginary technologies. Ground strictly in candidate's facts.
   - If lacking numbers, provide metrics guidance: "Consider adding a measurable result if you have one."
3. Build a personalized, week-by-week LEARNING ROADMAP (4 to 6 weeks) customized to the role.
4. Recommend 2-3 PORTFOLIO PROJECTS that close the candidate's biggest skill gaps.
5. Provide actionable career stage advice for someone at their current level targeting this role.

Return a STRICT JSON object with this exact schema:
{
  "top_priorities": [
    {
      "skill": "string",
      "priority": "HIGH" | "MEDIUM" | "LOW",
      "reason": "string",
      "learning_topics": ["string"],
      "practice_project": "string",
      "evidence_goal": "string"
    }
  ],
  "resume_improvements": [
    {
      "section": "string",
      "original_bullet": "string",
      "improved_bullet": "string",
      "reason": "string",
      "rule_applied": "string",
      "metrics_guidance": "string"
    }
  ],
  "learning_roadmap": [
    {
      "week": 1,
      "focus": "string",
      "topics": ["string"],
      "practice": "string",
      "milestone": "string"
    }
  ],
  "project_recommendations": [
    {
      "project": "string",
      "difficulty": "Beginner" | "Intermediate" | "Advanced",
      "skills": ["string"],
      "reason": "string",
      "features": ["string"],
      "target_requirement": "string"
    }
  ],
  "career_stage_advice": "string",
  "final_action_plan": ["string"]
}

Output ONLY a valid JSON object matching the schema above.
`;

  try {
    const response = await generateContentWithRetry({
      contents: prompt,
    });

    if (response?.text) {
      const parsed = safeJsonParse<RecommendationData | null>(response.text, null);
      if (parsed && parsed.top_priorities && parsed.learning_roadmap) {
        return parsed;
      }
    }
  } catch {
    // Intentionally suppressed for graceful fallback
  }

  return buildHeuristicRecommendations(resume, job, matches, scoreResult, targetGoal);
}
