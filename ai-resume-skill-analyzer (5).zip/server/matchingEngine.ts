import {
  ResumeData,
  JobData,
  SkillMatch,
  MatchStatus,
  PriorityLevel,
} from '../src/types/analyzer';
import { normalizeSkill, isExactMatch, getPartialRelation } from './skillNormalizer';

export function runSkillMatching(resume: ResumeData, job: JobData): SkillMatch[] {
  const matches: SkillMatch[] = [];
  const processedSkills = new Set<string>();

  // Gather all candidate skills from resume
  const candidateSkills = [
    ...(resume.technical_skills || []),
    ...(resume.programming_languages || []),
    ...(resume.frameworks || []),
    ...(resume.libraries || []),
    ...(resume.databases || []),
    ...(resume.cloud_platforms || []),
    ...(resume.devops_tools || []),
    ...(resume.ai_ml_tools || []),
    ...(resume.data_tools || []),
    ...(resume.design_tools || []),
    ...(resume.business_tools || []),
    ...(resume.soft_skills || []),
    ...(resume.domain_skills || []),
    ...(resume.skills_with_evidence?.map((s) => s.name) || []),
  ];

  // Helper: find resume evidence for a skill
  const findEvidence = (skillName: string): { evidence: string; strength: string } => {
    // Check skills_with_evidence first
    const recorded = resume.skills_with_evidence?.find(
      (s) => isExactMatch(s.name, skillName)
    );
    if (recorded && recorded.context_evidence) {
      return {
        evidence: recorded.context_evidence,
        strength: recorded.evidence_level,
      };
    }

    // Check projects
    for (const proj of resume.projects || []) {
      const usesTech = proj.technologies?.some((t) => isExactMatch(t, skillName));
      const mentionsDesc = proj.description?.toLowerCase().includes(skillName.toLowerCase());
      if (usesTech || mentionsDesc) {
        return {
          evidence: `Demonstrated in project "${proj.name}": ${proj.description?.slice(0, 140)}...`,
          strength: proj.evidence_strength || 'Demonstrated',
        };
      }
    }

    // Check work experience
    for (const exp of resume.work_experience || []) {
      const usesTech = exp.technologies_used?.some((t) => isExactMatch(t, skillName));
      const respMatch = exp.responsibilities?.find((r) =>
        r.toLowerCase().includes(skillName.toLowerCase())
      );
      const achMatch = exp.quantified_achievements?.find((a) =>
        a.toLowerCase().includes(skillName.toLowerCase())
      );
      if (usesTech || respMatch || achMatch) {
        return {
          evidence: `${exp.role} at ${exp.company}: "${(achMatch || respMatch || exp.responsibilities?.[0] || '').slice(0, 140)}..."`,
          strength: 'Strongly demonstrated',
        };
      }
    }

    // Check certifications
    for (const cert of resume.certifications || []) {
      if (cert.toLowerCase().includes(skillName.toLowerCase())) {
        return {
          evidence: `Certified credential: ${cert}`,
          strength: 'Explicit',
        };
      }
    }

    // Check candidate skills list
    const foundInList = candidateSkills.find((s) => isExactMatch(s, skillName));
    if (foundInList) {
      return {
        evidence: `Listed in resume skill section as "${foundInList}".`,
        strength: 'Mentioned only',
      };
    }

    return { evidence: '', strength: 'No evidence' };
  };

  // Compile job requirements: Required skills list + preferred + tools
  const requirementPool: { skill: string; isRequired: boolean }[] = [];

  for (const s of job.required_skills || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: true });
    }
  }

  for (const s of job.technical_skills || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: true });
    }
  }

  for (const s of job.tools || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: false });
    }
  }

  for (const s of job.preferred_skills || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: false });
    }
  }

  for (const s of job.nice_to_have || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: false });
    }
  }

  for (const s of job.domain_knowledge || []) {
    if (s && !processedSkills.has(normalizeSkill(s))) {
      processedSkills.add(normalizeSkill(s));
      requirementPool.push({ skill: s, isRequired: false });
    }
  }

  // Fallback: If job analyzer didn't produce any skills, pull from keywords
  if (requirementPool.length === 0 && job.keywords?.length) {
    for (const kw of job.keywords) {
      if (kw && !processedSkills.has(normalizeSkill(kw))) {
        processedSkills.add(normalizeSkill(kw));
        requirementPool.push({ skill: kw, isRequired: true });
      }
    }
  }

  // Now process each requirement against candidate resume
  for (const req of requirementPool) {
    const { skill, isRequired } = req;
    let status: MatchStatus = 'MISSING';
    let priority: PriorityLevel = isRequired ? 'HIGH' : 'LOW';
    let resumeEvidence = '';
    let explanation = '';
    let missingComponent: string | undefined = undefined;
    let candidateEquivalentSkill: string | undefined = undefined;

    // 1. Direct or strong match check
    const exactCandidateSkill = candidateSkills.find((cs) => isExactMatch(cs, skill));
    const evidenceLookup = findEvidence(skill);

    if (exactCandidateSkill || evidenceLookup.evidence) {
      if (
        evidenceLookup.strength === 'Strongly demonstrated' ||
        evidenceLookup.strength === 'Demonstrated' ||
        evidenceLookup.strength === 'Explicit'
      ) {
        status = 'MATCHED';
        priority = 'LOW'; // already satisfied
        resumeEvidence = evidenceLookup.evidence;
        explanation = `Strong evidence found in candidate profile with demonstrated usage.`;
      } else if (evidenceLookup.strength === 'Mentioned only') {
        // Mentioned in skill list but no project or work bullet backs it up
        status = 'PARTIAL';
        priority = isRequired ? 'MEDIUM' : 'LOW';
        resumeEvidence = evidenceLookup.evidence;
        explanation = `Skill is listed on resume, but practical execution or project evidence is minimal.`;
        missingComponent = `Quantified work experience or portfolio project demonstrating ${skill}.`;
      } else {
        status = 'UNCLEAR';
        priority = isRequired ? 'MEDIUM' : 'LOW';
        resumeEvidence = evidenceLookup.evidence || 'Vague mention in resume text.';
        explanation = `Evidence is ambiguous or insufficient to confirm practical proficiency.`;
      }
    } else {
      // 2. Check partial / related technology
      let foundRelation: { candidateSkill: string; reason: string } | null = null;
      for (const cs of candidateSkills) {
        const rel = getPartialRelation(cs, skill);
        if (rel) {
          foundRelation = { candidateSkill: cs, reason: rel };
          break;
        }
      }

      if (foundRelation) {
        status = 'PARTIAL';
        priority = isRequired ? 'MEDIUM' : 'LOW';
        candidateEquivalentSkill = foundRelation.candidateSkill;
        resumeEvidence = `Candidate possesses ${foundRelation.candidateSkill} (${foundRelation.reason}).`;
        explanation = `Foundational knowledge exists, but specific hands-on experience with ${skill} is not demonstrated.`;
        missingComponent = `Direct experience with ${skill} and its specific ecosystem.`;
      } else {
        // 3. Completely missing
        status = 'MISSING';
        priority = isRequired ? 'HIGH' : 'LOW';
        resumeEvidence = `No meaningful evidence or related technology found in the supplied resume.`;
        explanation = `${skill} is an unmet ${isRequired ? 'required' : 'preferred'} job requirement.`;
        missingComponent = `Complete lack of demonstrable ${skill} knowledge or projects.`;
      }
    }

    matches.push({
      skill,
      jobRequirement: `${isRequired ? 'Required' : 'Preferred'} skill for ${job.job_title}`,
      isRequired,
      status,
      priority,
      resumeEvidence,
      explanation,
      missingComponent,
      candidateEquivalentSkill,
    });
  }

  return matches;
}
