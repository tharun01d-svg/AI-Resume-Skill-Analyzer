export interface SamplePair {
  id: string;
  name: string;
  label?: string;
  company?: string;
  domain: string;
  candidateName: string;
  jobTitle: string;
  resumeFileName: string;
  targetGoal: string;
  resumeText: string;
  jobDescription: string;
}

export const SAMPLE_DATASETS: SamplePair[] = [
  {
    id: 'software-engineer',
    name: 'Software Developer (Full Stack)',
    label: 'Full Stack Engineer — Google',
    company: 'Google',
    domain: 'Software Engineering',
    candidateName: 'John Doe',
    jobTitle: 'Full Stack Software Engineer',
    resumeFileName: 'John_Doe_Software_Resume.pdf',
    targetGoal: 'Transition from backend developer to Full Stack Engineer',
    resumeText: `John Doe
Email: john.doe@example.com | Phone: (555) 234-5678 | San Francisco, CA
LinkedIn: linkedin.com/in/johndoe | GitHub: github.com/johndoe

PROFESSIONAL SUMMARY
Backend-leaning Software Developer with 2.5 years of professional experience building automated backend microservices and data pipelines using Python, SQL, and Git. Experienced in designing REST APIs, database schemas, and writing performant queries. Strong foundation in JavaScript for web applications.

WORK EXPERIENCE
Software Developer | DataStream Labs, San Francisco, CA
July 2024 – Present (1.5 years)
• Built and maintained 8 microservice endpoints using Python and Flask, processing over 120,000 daily API requests with 99.9% uptime.
• Automated nightly ETL database pipelines using Python scripts and SQL queries, reducing batch data processing time by 35%.
• Managed version control, code reviews, and Git branch workflows across an engineering team of 6 developers.
• Created internal dashboard scripts using JavaScript (ES6) and HTML/CSS to visualize data anomalies.

Junior Developer | CloudPeak Solutions, Oakland, CA
January 2023 – June 2024 (1.5 years)
• Developed automated data extraction scripts using Python and regular expressions for legacy document migration.
• Designed and optimized PostgreSQL relational database schemas, indexing queries to improve response times by 20%.
• Collaborated with team leads to maintain Git repositories and document REST API specifications.

PROJECTS
• API Analytics Engine: Built a modular Python REST API that analyzes web server access logs and outputs traffic trends into PostgreSQL. Utilized Git for version control and wrote unit tests achieving 85% coverage.
• Dynamic Task Manager: Created an interactive web app using vanilla JavaScript and HTML5 localStorage for tracking team deliverables.

EDUCATION
Bachelor of Science in Computer Science
University of California, Davis (Graduated 2022)
Relevant Coursework: Data Structures, Algorithms, Relational Database Systems, Operating Systems.

SKILLS
Programming Languages: Python, JavaScript, SQL, Bash
Databases: PostgreSQL, MySQL, SQLite
Tools & Practices: Git, GitHub, REST APIs, Linux, Unit Testing, Agile/Scrum`,

    jobDescription: `Full Stack Software Engineer
Company: Apex Cloud Technologies
Location: San Francisco, CA (Hybrid)
Experience Level: Mid-Level (2–4 years)

About the Role:
We are seeking a versatile Full Stack Software Engineer to build scalable web products and high-volume customer portals. You will collaborate with product managers and designers to design, develop, and deploy user-facing web applications.

Key Responsibilities:
• Build modern, responsive web user interfaces using React and modern frontend state management.
• Design, implement, and maintain scalable backend services and REST APIs in Python or Node.js.
• Design robust database schemas and write optimized SQL queries in PostgreSQL.
• Deploy and maintain cloud infrastructure and serverless workloads on Amazon Web Services (AWS).
• Champion engineering excellence through Git version control, peer reviews, automated CI/CD pipelines, and unit testing.

Required Qualifications:
• 2+ years of professional software engineering experience.
• Strong proficiency in Python or modern backend frameworks.
• Production experience with React for building responsive web applications.
• Strong practical knowledge of SQL and relational database systems (PostgreSQL/MySQL).
• Hands-on experience with Git version control and collaborative branching.
• Working knowledge of cloud deployment on Amazon Web Services (AWS) including S3, EC2, or Lambda.

Preferred / Nice to Have:
• Experience with Docker containerization and CI/CD pipelines.
• Familiarity with TypeScript and Next.js.
• Understanding of NoSQL databases like Redis or MongoDB.`
  },

  {
    id: 'data-scientist',
    name: 'Data Scientist & ML Specialist',
    label: 'Senior Data Scientist — Amazon',
    company: 'Amazon',
    domain: 'Data Science & AI',
    candidateName: 'Elena Vance',
    jobTitle: 'Senior Data Scientist',
    resumeFileName: 'Elena_Vance_Data_Science.pdf',
    targetGoal: 'Advance to Senior Data Scientist role in FinTech',
    resumeText: `Elena Vance
Email: elena.vance@example.com | Phone: (555) 876-5432 | New York, NY
LinkedIn: linkedin.com/in/elenavance | Portfolio: elenavance.ai

PROFESSIONAL SUMMARY
Data Scientist with 4 years of experience building predictive machine learning models, statistical analyses, and customer segmentation algorithms. Proficient in Python, Pandas, NumPy, Scikit-Learn, and SQL. Track record of translating complex datasets into actionable business insights.

EXPERIENCE
Data Scientist | FinMetric Analytics, New York, NY
August 2023 – Present (2 years)
• Developed and deployed a customer churn prediction model using Python and Scikit-Learn, identifying 18% at-risk enterprise accounts and improving retention by $420k ARR.
• Designed and executed statistical A/B test experiments for pricing model optimization across 50,000 monthly active users.
• Constructed automated data extraction queries in SQL and transformed multi-gigabyte transactional tables using Pandas and NumPy.

Data Analyst | Horizon Health Partners, Boston, MA
June 2021 – July 2023 (2 years)
• Built executive business intelligence dashboards in Tableau and conducted exploratory data analysis using Python and SQL.
• Created statistical regression models to forecast patient intake volumes, improving hospital bed allocation efficiency by 14%.

PROJECTS
• Fraud Detection Pipeline: Built an anomaly detection pipeline on 1M credit card transactions using Random Forest and XGBoost in Python, achieving 0.94 ROC-AUC score.
• Algorithmic Trading Backtester: Developed a quantitative analysis engine in Python calculating Sharpe ratios and drawdown risk metrics.

EDUCATION
Master of Science in Applied Statistics & Data Analytics
Columbia University, New York (2021)
Bachelor of Science in Mathematics, Boston University (2019)

SKILLS
Languages: Python, SQL, R
Libraries & ML: Pandas, NumPy, Scikit-Learn, XGBoost, Matplotlib, Seaborn, SciPy
Databases & BI: PostgreSQL, Snowflake, Tableau, Excel
Techniques: Supervised Learning, Unsupervised Clustering, Hypothesis Testing, A/B Testing`,

    jobDescription: `Senior Data Scientist (ML & Predictive Analytics)
Company: Vanguard Capital Markets
Location: New York, NY
Experience: 4–6 years

Role Overview:
Vanguard Capital Markets is looking for a Senior Data Scientist to architect predictive machine learning systems for quantitative risk modeling and credit scoring.

Requirements:
• 4+ years of data science and statistical modeling experience.
• Advanced proficiency in Python and statistical modeling libraries (Pandas, NumPy, Scikit-Learn).
• Strong mastery of SQL and relational databases for massive query execution.
• Hands-on experience building, validating, and explaining Machine Learning algorithms (ensemble trees, regression, classification).
• Proven background in A/B testing and rigorous statistical experimentation.

Required Infrastructure & Tools:
• Production MLOps experience deploying models using Docker and Kubernetes.
• Big data distributed processing experience with Apache Spark or PySpark.
• Cloud data platforms experience (AWS SageMaker or Google Cloud Vertex AI).

Preferred:
• Deep Learning foundations (PyTorch or TensorFlow).
• Experience with feature stores and automated data drift monitoring.`
  },

  {
    id: 'product-manager',
    name: 'Technical Product Manager',
    label: 'Product Manager — Microsoft',
    company: 'Microsoft',
    domain: 'Product & Business',
    candidateName: 'Marcus Chen',
    jobTitle: 'Product Manager, Platform & APIs',
    resumeFileName: 'Marcus_Chen_PM.pdf',
    targetGoal: 'Lead B2B SaaS platform strategy and developer products',
    resumeText: `Marcus Chen
Email: marcus.chen@example.com | Phone: (555) 432-1098 | Austin, TX
LinkedIn: linkedin.com/in/marcuschenpm

PROFESSIONAL SUMMARY
Strategic Product Manager with 3 years of experience driving B2B SaaS roadmap execution, cross-functional engineering alignment, and user research. Adept at turning complex customer needs into clear PRDs, epics, and measurable OKRs.

WORK EXPERIENCE
Product Manager | CloudSphere Technologies, Austin, TX
September 2023 – Present (2 years)
• Owned the product roadmap for developer onboarding, reducing time-to-first-API-call from 4 days to 45 minutes.
• Conducted 40+ user interviews with enterprise developers to inform requirement backlogs in Jira and Confluence.
• Partnered closely with engineering team of 8 developers in 2-week Agile/Scrum sprints to ship 6 core product releases on schedule.

Associate Product Manager | RetailPulse, Austin, TX
June 2022 – August 2023 (1.2 years)
• Authored comprehensive PRDs and user stories for merchant analytics reports, driving 22% increase in weekly active portal users.
• Monitored funnel performance and product KPIs using Google Analytics and basic SQL queries.

EDUCATION
Bachelor of Business Administration (BBA) in Management Information Systems
University of Texas at Austin (2022)

SKILLS & METHODOLOGIES
Methodologies: Agile, Scrum, Product Roadmapping, User Story Mapping, PRDs, Sprint Planning
Tools: Jira, Confluence, Figma, Miro, Google Analytics, SQL, Slack
Competencies: Stakeholder Management, Customer Discovery, Feature Prioritization, Wireframing`,

    jobDescription: `Product Manager, Developer Platform & APIs
Company: StripeForge Networks
Location: Austin, TX / Remote
Seniority: Mid to Senior (3–5 years experience)

About the Team:
StripeForge powers enterprise billing infrastructure. We are hiring a Product Manager to lead our developer experience, developer documentation, and public APIs.

Responsibilities:
• Define product strategy, write PRDs, and manage end-to-end delivery of public REST and GraphQL APIs.
• Drive user research, usability testing, and customer feedback loops with software developers and engineering leaders.
• Analyze product usage telemetry, developer funnels, and retention metrics using Amplitude or Mixpanel.
• Run continuous A/B experimentation to optimize onboarding and self-serve conversions.

Qualifications:
• 3+ years of product management experience, preferably on technical B2B or developer-facing products.
• Deep understanding of Agile/Scrum methodologies, backlog grooming, and sprint execution.
• Exceptional stakeholder management and written communication skills (PRDs, roadmaps).
• Data-driven mindset with experience defining and tracking product KPIs.

Preferred:
• Experience with Amplitude, Mixpanel, or PostHog for product analytics.
• Familiarity with developer tooling, Postman, API gateways, and webhooks.
• Technical background or ability to write SQL queries independently.`
  }
];
