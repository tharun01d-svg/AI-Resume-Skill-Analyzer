import { GoogleGenAI } from '@google/genai';

export const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export const MODEL_NAME = 'gemini-3.8-flash';

// Circuit breaker to avoid hammering API when 429 quota or 503 occurs
let circuitOpenUntil = 0;

export function isCircuitOpen(): boolean {
  return Date.now() < circuitOpenUntil;
}

export function tripCircuit(durationMs = 60000) {
  circuitOpenUntil = Date.now() + durationMs;
}

/**
 * Execute generateContent with circuit-breaker protection, fast timeout, and graceful failure
 */
export async function generateContentWithRetry(params: {
  contents: string;
  model?: string;
  retries?: number;
  timeoutMs?: number;
}): Promise<any> {
  if (isCircuitOpen()) {
    return null;
  }

  const model = params.model || MODEL_NAME;
  let attempt = 0;
  const maxAttempts = params.retries ?? 1; // 1 attempt to conserve quota
  const timeoutMs = params.timeoutMs ?? 10000;

  while (attempt < maxAttempts) {
    attempt++;
    try {
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Request timed out')), timeoutMs);
      });

      const callPromise = ai.models.generateContent({
        model,
        contents: params.contents,
      });

      const response = (await Promise.race([callPromise, timeoutPromise])) as any;
      return response;
    } catch (err: any) {
      const errMsg = String(err?.message || err);
      const isQuotaOrSpike =
        errMsg.includes('503') ||
        errMsg.includes('UNAVAILABLE') ||
        errMsg.includes('high demand') ||
        errMsg.includes('RESOURCE_EXHAUSTED') ||
        errMsg.includes('429') ||
        errMsg.includes('timed out');

      if (isQuotaOrSpike) {
        // Trip circuit breaker for 60 seconds to prevent error spam
        tripCircuit(60000);
        console.log('[AI Engine] External model busy or quota reached; seamlessly running local deterministic engine.');
        return null;
      }
      return null;
    }
  }

  return null;
}

/**
 * Clean and parse JSON text safely, handling markdown backticks or minor imperfections
 */
export function safeJsonParse<T>(rawText: string, fallback: T): T {
  if (!rawText) return fallback;

  let cleaned = rawText.trim();
  // Strip markdown code fences if present
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/i, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  cleaned = cleaned.trim();

  try {
    return JSON.parse(cleaned) as T;
  } catch {
    try {
      const relaxed = cleaned
        .replace(/,\s*([\]}])/g, '$1') // remove trailing commas
        .replace(/\n/g, ' ');
      return JSON.parse(relaxed) as T;
    } catch {
      return fallback;
    }
  }
}
