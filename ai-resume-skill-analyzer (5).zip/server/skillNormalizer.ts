/**
 * Skill Normalization and Relationship Taxonomy
 * Enforces strict semantic equivalence while recognizing legitimate partial relationships.
 */

// Canonical alias dictionary (case-insensitive keys)
const EQUIVALENCE_MAP: Record<string, string> = {
  'react.js': 'react',
  'reactjs': 'react',
  'react': 'react',
  'js': 'javascript',
  'es6': 'javascript',
  'es2020': 'javascript',
  'javascript': 'javascript',
  'ts': 'typescript',
  'typescript': 'typescript',
  'node.js': 'node.js',
  'nodejs': 'node.js',
  'node': 'node.js',
  'postgres': 'postgresql',
  'postgresql': 'postgresql',
  'mongo': 'mongodb',
  'mongodb': 'mongodb',
  'rest': 'restful apis',
  'rest api': 'restful apis',
  'rest apis': 'restful apis',
  'restful api': 'restful apis',
  'restful apis': 'restful apis',
  'github actions': 'ci/cd',
  'github action': 'ci/cd',
  'ci cd': 'ci/cd',
  'ci/cd': 'ci/cd',
  'continuous integration': 'ci/cd',
  'k8s': 'kubernetes',
  'kubernetes': 'kubernetes',
  'gcp': 'google cloud',
  'google cloud platform': 'google cloud',
  'google cloud': 'google cloud',
  'aws': 'amazon web services (aws)',
  'amazon web services': 'amazon web services (aws)',
  'vue.js': 'vue',
  'vuejs': 'vue',
  'vue': 'vue',
  'next.js': 'next.js',
  'nextjs': 'next.js',
  'next': 'next.js',
  'tailwindcss': 'tailwind css',
  'tailwind': 'tailwind css',
  'tailwind css': 'tailwind css',
  'golang': 'go',
  'go': 'go',
  'c++': 'c++',
  'cpp': 'c++',
  'c#': 'c#',
  'csharp': 'c#',
  'py': 'python',
  'python': 'python',
  'ml': 'machine learning',
  'machine learning': 'machine learning',
  'ai': 'artificial intelligence',
  'artificial intelligence': 'artificial intelligence',
  'ui/ux': 'ui/ux design',
  'ui ux': 'ui/ux design',
  'ux/ui': 'ui/ux design',
  'ux': 'ux design',
  'ui': 'ui design',
  'scrum': 'agile / scrum',
  'agile': 'agile / scrum',
  'jira': 'jira',
  'confluence': 'confluence',
  'powerbi': 'power bi',
  'power bi': 'power bi',
  'tf': 'tensorflow',
  'tensorflow': 'tensorflow',
  'torch': 'pytorch',
  'pytorch': 'pytorch',
  'sklearn': 'scikit-learn',
  'scikit-learn': 'scikit-learn',
  'prompt engineering': 'prompt engineering',
  'llm': 'large language models (llm)',
  'llms': 'large language models (llm)',
  'large language models': 'large language models (llm)',
  'rag': 'retrieval-augmented generation (rag)',
};

// Known relationships (Foundation / Tooling / Ecosystem)
// If requirement is key, having any of values confers PARTIAL status
const RELATIONSHIPS: Record<string, { relatedSkills: string[]; relationType: string }> = {
  'react': {
    relatedSkills: ['javascript', 'typescript', 'frontend development', 'html5', 'vue', 'angular'],
    relationType: 'Core web & frontend foundation',
  },
  'angular': {
    relatedSkills: ['typescript', 'javascript', 'frontend development', 'react', 'vue'],
    relationType: 'Frontend framework ecosystem',
  },
  'vue': {
    relatedSkills: ['javascript', 'typescript', 'frontend development', 'react'],
    relationType: 'Frontend framework ecosystem',
  },
  'next.js': {
    relatedSkills: ['react', 'javascript', 'typescript', 'node.js'],
    relationType: 'React framework foundation',
  },
  'django': {
    relatedSkills: ['python', 'backend development', 'flask', 'fastapi'],
    relationType: 'Python backend ecosystem',
  },
  'flask': {
    relatedSkills: ['python', 'backend development', 'django', 'fastapi'],
    relationType: 'Python microframework foundation',
  },
  'fastapi': {
    relatedSkills: ['python', 'backend development', 'restful apis', 'flask'],
    relationType: 'Python API framework foundation',
  },
  'spring boot': {
    relatedSkills: ['java', 'backend development', 'microservices', 'spring'],
    relationType: 'Java backend ecosystem',
  },
  'postgresql': {
    relatedSkills: ['sql', 'relational databases', 'mysql', 'database design'],
    relationType: 'Relational database foundation',
  },
  'mysql': {
    relatedSkills: ['sql', 'relational databases', 'postgresql'],
    relationType: 'Relational database foundation',
  },
  'mongodb': {
    relatedSkills: ['nosql', 'databases', 'document databases', 'mongoose'],
    relationType: 'NoSQL database paradigm',
  },
  'amazon web services (aws)': {
    relatedSkills: ['cloud computing', 'google cloud', 'azure', 'docker', 'devops'],
    relationType: 'Cloud infrastructure paradigm',
  },
  'google cloud': {
    relatedSkills: ['cloud computing', 'amazon web services (aws)', 'azure', 'devops'],
    relationType: 'Cloud infrastructure paradigm',
  },
  'azure': {
    relatedSkills: ['cloud computing', 'amazon web services (aws)', 'google cloud', 'devops'],
    relationType: 'Cloud infrastructure paradigm',
  },
  'kubernetes': {
    relatedSkills: ['docker', 'containerization', 'devops', 'ci/cd', 'cloud computing'],
    relationType: 'Container orchestration ecosystem',
  },
  'docker': {
    relatedSkills: ['containerization', 'devops', 'linux', 'ci/cd'],
    relationType: 'Containerization foundation',
  },
  'ci/cd': {
    relatedSkills: ['git', 'github actions', 'jenkins', 'gitlab', 'devops'],
    relationType: 'Automation & deployment lifecycle',
  },
  'machine learning': {
    relatedSkills: ['python', 'data analysis', 'statistics', 'deep learning', 'pandas', 'numpy'],
    relationType: 'Mathematical & algorithmic foundation',
  },
  'deep learning': {
    relatedSkills: ['machine learning', 'python', 'pytorch', 'tensorflow', 'neural networks'],
    relationType: 'Advanced machine learning paradigm',
  },
  'large language models (llm)': {
    relatedSkills: ['machine learning', 'deep learning', 'nlp', 'python', 'prompt engineering'],
    relationType: 'GenAI & NLP foundation',
  },
  'retrieval-augmented generation (rag)': {
    relatedSkills: ['vector databases', 'embeddings', 'large language models (llm)', 'python', 'langchain'],
    relationType: 'LLM application architecture',
  },
  'product management': {
    relatedSkills: ['agile / scrum', 'user research', 'roadmapping', 'kpis', 'stakeholder management', 'jira'],
    relationType: 'Product lifecycle methodology',
  },
  'data analysis': {
    relatedSkills: ['sql', 'excel', 'python', 'statistics', 'tableau', 'power bi'],
    relationType: 'Quantitative analysis foundation',
  },
};

/**
 * Normalizes a skill string to its canonical lower-case representation
 */
export function normalizeSkill(skillName: string): string {
  if (!skillName) return '';
  const cleaned = skillName.trim().toLowerCase();
  return EQUIVALENCE_MAP[cleaned] || cleaned;
}

/**
 * Checks if candidate has an exact or canonical match for a requirement
 */
export function isExactMatch(candidateSkill: string, requiredSkill: string): boolean {
  const normCand = normalizeSkill(candidateSkill);
  const normReq = normalizeSkill(requiredSkill);
  
  if (normCand === normReq) return true;
  
  // Safe sub-string matching only if word boundaries match
  if (normCand.length > 3 && normReq.length > 3) {
    if (normCand === normReq || normCand.includes(normReq) || normReq.includes(normCand)) {
      // Disallow dangerous matches
      if (
        (normCand.includes('java') && !normCand.includes('script') && normReq.includes('javascript')) ||
        (normReq.includes('java') && !normReq.includes('script') && normCand.includes('javascript'))
      ) {
        return false;
      }
      return true;
    }
  }
  return false;
}

/**
 * Checks if a candidate skill is related to a required skill (partial match)
 */
export function getPartialRelation(candidateSkill: string, requiredSkill: string): string | null {
  const normCand = normalizeSkill(candidateSkill);
  const normReq = normalizeSkill(requiredSkill);

  // Check defined relationships
  const rel = RELATIONSHIPS[normReq];
  if (rel) {
    for (const s of rel.relatedSkills) {
      if (normCand === normalizeSkill(s) || normCand.includes(normalizeSkill(s))) {
        return `${rel.relationType} (${candidateSkill} provides related foundation)`;
      }
    }
  }

  // Cross check reverse relationship
  const candRel = RELATIONSHIPS[normCand];
  if (candRel) {
    for (const s of candRel.relatedSkills) {
      if (normReq === normalizeSkill(s) || normReq.includes(normalizeSkill(s))) {
        return `${candRel.relationType} (${candidateSkill} provides foundational context)`;
      }
    }
  }

  return null;
}
