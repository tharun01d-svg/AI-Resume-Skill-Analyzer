import mammoth from 'mammoth';
import * as pdfModule from 'pdf-parse';

export interface ExtractedResumePayload {
  text: string;
  pages?: number;
  fileType: string;
}

export async function extractResumeDetailsFromBuffer(
  buffer: Buffer,
  mimeType: string,
  filename: string
): Promise<ExtractedResumePayload> {
  const lowerName = filename.toLowerCase();

  // 1. PDF Handling
  if (
    mimeType === 'application/pdf' ||
    lowerName.endsWith('.pdf')
  ) {
    try {
      let text = '';
      let pages = 1;
      const anyModule = pdfModule as any;

      // Check for pdf-parse v2 PDFParse class
      if (anyModule.PDFParse) {
        const parser = new anyModule.PDFParse({ data: buffer });
        try {
          const res = await parser.getText();
          text = (res?.text || '').trim();
          if (res?.total && typeof res.total === 'number') {
            pages = res.total;
          } else if (Array.isArray(res?.pages)) {
            pages = res.pages.length;
          }
        } finally {
          if (typeof parser.destroy === 'function') {
            await parser.destroy();
          }
        }
      }
      // Check for default function or direct function export (pdf-parse v1)
      else if (typeof anyModule.default === 'function') {
        const parsed = await anyModule.default(buffer);
        text = (parsed?.text || '').trim();
        if (parsed?.numpages) pages = parsed.numpages;
      } else if (typeof anyModule === 'function') {
        const parsed = await anyModule(buffer);
        text = (parsed?.text || '').trim();
        if (parsed?.numpages) pages = parsed.numpages;
      } else {
        throw new Error('No compatible PDF parser engine found.');
      }

      if (!text) {
        throw new Error('PDF file appears to contain no extractable text. It may be an image-only scan.');
      }

      // If pages calculation was not available, estimate based on character/line density
      if (!pages || pages < 1) {
        pages = Math.max(1, Math.ceil(text.length / 2800));
      }

      return {
        text,
        pages,
        fileType: 'PDF',
      };
    } catch (err: any) {
      throw new Error(`PDF Parsing failed: ${err.message || 'Corrupted or unreadable PDF'}`);
    }
  }

  // 2. Microsoft Word (.docx) Handling
  if (
    mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    lowerName.endsWith('.docx')
  ) {
    try {
      const result = await mammoth.extractRawText({ buffer });
      const text = result?.value?.trim() || '';
      if (!text) {
        throw new Error('DOCX file appears to contain no extractable text.');
      }
      const estimatedPages = Math.max(1, Math.ceil(text.length / 3000));
      return {
        text,
        pages: estimatedPages,
        fileType: 'DOCX',
      };
    } catch (err: any) {
      throw new Error(`DOCX Parsing failed: ${err.message || 'Corrupted or unreadable DOCX'}`);
    }
  }

  // 3. Plain text / Markdown Handling
  if (
    mimeType.startsWith('text/') ||
    lowerName.endsWith('.txt') ||
    lowerName.endsWith('.md')
  ) {
    const text = buffer.toString('utf-8').trim();
    if (!text) {
      throw new Error('Text file is empty.');
    }
    return {
      text,
      pages: Math.max(1, Math.ceil(text.length / 3200)),
      fileType: lowerName.endsWith('.md') ? 'MD' : 'TXT',
    };
  }

  throw new Error('Unsupported file format. Please upload a PDF (.pdf), Word document (.docx), or plain text file (.txt).');
}

export async function extractTextFromBuffer(
  buffer: Buffer,
  mimeType: string,
  filename: string
): Promise<string> {
  const res = await extractResumeDetailsFromBuffer(buffer, mimeType, filename);
  return res.text;
}
