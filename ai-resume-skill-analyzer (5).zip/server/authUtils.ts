import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export const JWT_SECRET =
  process.env.JWT_SECRET ||
  process.env.SESSION_SECRET ||
  'ai-studio-auth-vault-secret-key-prod-2026';

export interface TokenPayload {
  uid: string;
  email: string;
  name?: string | null;
  picture?: string | null;
  sub: string;
  iat?: number;
  exp?: number;
}

export function generateAuthToken(user: {
  uid: string;
  email: string;
  displayName?: string | null;
  photoUrl?: string | null;
}): string {
  const payload: TokenPayload = {
    uid: user.uid,
    email: user.email,
    name: user.displayName || null,
    picture: user.photoUrl || null,
    sub: user.uid,
  };

  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: '30d', // 30-day session
  });
}

export function verifyAuthToken(token: string): TokenPayload {
  return jwt.verify(token, JWT_SECRET) as TokenPayload;
}

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function comparePassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}
