import type { IncomingMessage, ServerResponse } from 'http';
import { analyzeResumeWithAI, analyzeJobWithAI, generateRecommendationsWithAI } from '../server/aiModules';
import { runSkillMatching } from '../server/matchingEngine';
import { calculateExplainableScore } from '../server/scoringEngine';
import {
  AnalysisReport,
  ApplicationReadiness,
  ReadinessLevel,
  ResumeData,
  JobData,
  ScoreResult,
} from '../src/types/analyzer';

function computeApplicationReadiness(
  scoreResult: ScoreResult,
  resumeData: ResumeData,
  jobData: JobData
): ApplicationReadiness {
  const reqCat = scoreResult.categories.required_skills;
  const reqPct = reqCat.is_applicable && reqCat.max > 0 ? (reqCat.earned / reqCat.max) * 100 : 75;
  const skillsLevel: ReadinessLevel = reqPct >= 75 ? 'Strong' : reqPct >= 50 ? 'Moderate' : 'Needs Improvement';

  const candidateYears = resumeData.total_experience_years || 0;
  const reqYears = jobData.experience_requirements.min_years || 2;
  let expLevel: ReadinessLevel = 'Moderate';
  if (candidateYears >= reqYears) {
    expLevel = 'Strong';
  } else if (candidateYears < Math.max(0, reqYears - 1.5)) {
    expLevel = 'Needs Improvement';
  }

  const projCat = scoreResult.categories.projects;
  const projPct = projCat.is_applicable && projCat.max > 0 ? (projCat.earned / projCat.max) * 100 : 70;
  const projLevel: ReadinessLevel = projPct >= 70 ? 'Strong' : projPct >= 40 ? 'Moderate' : 'Needs Improvement';

  const rqCat = scoreResult.categories.resume_quality;
  const rqPct = rqCat.max > 0 ? (rqCat.earned / rqCat.max) * 100 : 75;
  const rqLevel: ReadinessLevel = rqPct >= 70 ? 'Strong' : rqPct >= 45 ? 'Moderate' : 'Needs Improvement';

  const roleLevel: ReadinessLevel = scoreResult.totalScore >= 75 ? 'Strong' : scoreResult.totalScore >= 55 ? 'Moderate' : 'Needs Improvement';

  return {
    skills: skillsLevel,
    experience: expLevel,
    projects: projLevel,
    resumeQuality: rqLevel,
    roleAlignment: roleLevel,
    summary: `Candidate profile indicates ${skillsLevel.toLowerCase()} technical skill alignment, ${expLevel.toLowerCase()} experience alignment, and ${roleLevel.toLowerCase()} overall readiness for ${jobData.job_title} at ${jobData.company_inferred}.`,
  };
}

export default async function handler(req: any, res: any) {
  // Enable CORS for Vercel deployment
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const {
      resumeText,
      jobDescription,
      resumeFileName,
      resumeFileType,
      resumeFileSize,
      resumePageCount,
      targetCompany: rawCompany,
      targetRole: rawRole,
      experienceLevel: rawLevel,
      targetGoal,
      jobMeta,
    } = body;

    if (!resumeText || resumeText.trim().length < 20) {
      return res.status(400).json({ error: 'Please upload or provide valid resume content.' });
    }

    const targetCompany = rawCompany || jobMeta?.company || 'Target Organization';
    const targetRole = rawRole || jobMeta?.title || 'Software Engineer';
    const experienceLevel = rawLevel || jobMeta?.level || '2–4 Years';

    const isJobDescriptionSupplied = Boolean(jobDescription && jobDescription.trim().length >= 20);

    let effectiveJobText = jobDescription?.trim() || '';
    if (!isJobDescriptionSupplied) {
      effectiveJobText = `Target Role: ${targetRole}
Target Company: ${targetCompany}
Seniority Level: ${experienceLevel}

Role Context:
This analysis evaluates competencies commonly associated with the role of ${targetRole} at leading organizations comparable to ${targetCompany} at the ${experienceLevel} experience tier. Key technical standards, engineering foundations, collaboration, and ownership capabilities commonly expected for this level are evaluated.`;
    }

    const effectiveMeta = {
      title: targetRole,
      company: targetCompany,
      level: experienceLevel,
      isJobDescriptionSupplied,
    };

    // Step 1: Deep Resume Analysis
    const resumeData = await analyzeResumeWithAI(resumeText);

    // Step 2: Deep Job / Role Analysis
    const jobData = await analyzeJobWithAI(effectiveJobText, effectiveMeta);

    // Step 3: Deterministic Requirement & Skill Matching
    const skillMatches = runSkillMatching(resumeData, jobData);

    // Step 4: Mathematical 100-Point Scoring Engine
    const scoreResult = calculateExplainableScore(resumeData, jobData, skillMatches);

    // Step 5: Strategic Recommendations & Personalized Roadmap
    const recommendations = await generateRecommendationsWithAI(
      resumeData,
      jobData,
      skillMatches,
      scoreResult,
      targetGoal
    );

    // Step 6: Application Readiness
    const applicationReadiness = computeApplicationReadiness(scoreResult, resumeData, jobData);

    const report: AnalysisReport = {
      id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      resumeFileName: resumeFileName || 'Uploaded_Resume.pdf',
      resumeFileType: resumeFileType || (resumeFileName?.toLowerCase().endsWith('.docx') ? 'DOCX' : 'PDF'),
      resumeFileSize: resumeFileSize,
      resumePageCount: resumePageCount,
      targetCompany,
      targetRole,
      experienceLevel,
      isJobDescriptionSupplied,
      applicationReadiness,
      targetGoal,
      resumeData,
      jobData,
      skillMatches,
      scoreResult,
      recommendations,
    };

    res.status(200).json(report);
  } catch (err: any) {
    console.error('Vercel API Pipeline error:', err?.message || err);
    res.status(500).json({ error: err?.message || 'Pipeline execution failed.' });
  }
}
