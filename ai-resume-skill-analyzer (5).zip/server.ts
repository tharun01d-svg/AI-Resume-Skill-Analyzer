import express from 'express';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';

import { extractTextFromBuffer, extractResumeDetailsFromBuffer } from './server/resumeParser';
import { analyzeResumeWithAI, analyzeJobWithAI, generateRecommendationsWithAI } from './server/aiModules';
import { runSkillMatching } from './server/matchingEngine';
import { calculateExplainableScore } from './server/scoringEngine';
import { SAMPLE_DATASETS } from './server/sampleData';
import {
  AnalysisReport,
  ApplicationReadiness,
  ReadinessLevel,
  ResumeData,
  JobData,
  ScoreResult,
} from './src/types/analyzer';
import { requireAuth, optionalAuth, AuthRequest } from './src/middleware/auth.ts';
import {
  getOrCreateUser,
  getUserByUid,
  getUserByEmail,
  createUserWithCredentials,
  setUserPassword,
  getUserCredentials,
  upsertUserCredentials,
  getUserSavedAnalyses,
  saveAnalysisReport,
  deleteSavedAnalysis,
} from './src/db/users.ts';
import {
  generateAuthToken,
  hashPassword,
  comparePassword,
} from './server/authUtils.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// In-memory or buffer upload setup
const upload = multer({
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB limit
});

async function startServer() {
  const app = express();
  let port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  for (const arg of process.argv) {
    if (arg.startsWith('--port=')) {
      const parsed = parseInt(arg.split('=')[1], 10);
      if (!isNaN(parsed)) port = parsed;
    }
  }

  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  // API Routes
  
  // 1. Health & Config check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasApiKey: !!process.env.GEMINI_API_KEY,
      timestamp: new Date().toISOString(),
    });
  });

  // 2. Sample Datasets
  app.get('/api/samples', (req, res) => {
    res.json(SAMPLE_DATASETS);
  });

  // Auth & Database (Cloud SQL) Endpoints

  // 1. Register with Email and Password
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { email, password, displayName } = req.body || {};

      if (!email || typeof email !== 'string') {
        return res.status(400).json({ error: 'Valid email address is required.' });
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const normalizedEmail = email.trim().toLowerCase();
      if (!emailRegex.test(normalizedEmail)) {
        return res.status(400).json({ error: 'Please provide a valid email format (e.g. user@example.com).' });
      }

      if (!password || typeof password !== 'string' || password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      }

      // Check if user already exists
      const existingUser = await getUserByEmail(normalizedEmail);
      if (existingUser) {
        if (existingUser.passwordHash) {
          return res.status(400).json({
            error: 'An account with this email already exists. Please sign in with your credentials.',
          });
        }

        // User previously logged in without password (e.g. social or sync) -> set password
        const hashedPassword = await hashPassword(password);
        const updated = await setUserPassword(existingUser.id, hashedPassword);
        const token = generateAuthToken(updated);
        const credentials = await getUserCredentials(updated.id);

        return res.status(200).json({
          user: {
            uid: updated.uid,
            email: updated.email,
            displayName: updated.displayName || displayName || null,
            photoUrl: updated.photoUrl,
          },
          token,
          credentials,
          message: 'Password created and account verified successfully.',
        });
      }

      // Create new user with hashed password
      const hashedPassword = await hashPassword(password);
      const cleanName = typeof displayName === 'string' && displayName.trim() ? displayName.trim() : null;
      const newUser = await createUserWithCredentials(normalizedEmail, hashedPassword, cleanName || undefined);
      const token = generateAuthToken(newUser);

      res.status(201).json({
        user: {
          uid: newUser.uid,
          email: newUser.email,
          displayName: newUser.displayName,
          photoUrl: newUser.photoUrl,
        },
        token,
        credentials: null,
        message: 'Account registered and logged in successfully.',
      });
    } catch (error: any) {
      console.error('Registration failed:', error);
      res.status(500).json({ error: error.message || 'Server error during registration.' });
    }
  });

  // 2. Sign In with Email and Password
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password } = req.body || {};

      if (!email || typeof email !== 'string' || !password || typeof password !== 'string') {
        return res.status(400).json({ error: 'Email and password are required.' });
      }

      const normalizedEmail = email.trim().toLowerCase();
      const user = await getUserByEmail(normalizedEmail);

      if (!user) {
        return res.status(404).json({
          error: 'No account found with this email. Please register first or verify your email.',
        });
      }

      if (!user.passwordHash) {
        return res.status(400).json({
          error: 'This account was created without a password. Please use the Register tab to configure a password.',
        });
      }

      const isMatch = await comparePassword(password, user.passwordHash);
      if (!isMatch) {
        return res.status(401).json({
          error: 'Incorrect password. Please verify your credentials and try again.',
        });
      }

      const token = generateAuthToken(user);
      const credentials = await getUserCredentials(user.id);

      res.json({
        user: {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoUrl: user.photoUrl,
        },
        token,
        credentials,
        message: 'Signed in successfully.',
      });
    } catch (error: any) {
      console.error('Login error:', error);
      res.status(500).json({ error: error.message || 'Server error during authentication.' });
    }
  });

  // 3. Sign Out
  app.post('/api/auth/logout', (req, res) => {
    res.json({ success: true, message: 'Logged out successfully.' });
  });

  // 4. Synchronize authenticated user profile to Cloud SQL
  app.post('/api/auth/sync', requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!req.user || !req.user.uid) {
        return res.status(401).json({ error: 'Unauthorized: User identity not found' });
      }
      const email = req.user.email || req.body.email || `${req.user.uid}@auth.local`;
      const displayName = req.body.displayName || req.user.name || null;
      const photoUrl = req.body.photoUrl || req.user.picture || null;

      const user = await getOrCreateUser(req.user.uid, email, displayName, photoUrl);
      const credentials = await getUserCredentials(user.id);
      res.json({ user, credentials });
    } catch (error: any) {
      console.error('Failed to sync user with database:', error);
      res.status(500).json({ error: error.message || 'Database synchronization error.' });
    }
  });

  // 5. Get current user profile and credentials
  app.get('/api/auth/me', requireAuth, async (req: AuthRequest, res) => {
    try {
      if (!req.user || !req.user.uid) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      let user = await getUserByUid(req.user.uid);
      if (!user && req.user.email) {
        user = await getUserByEmail(req.user.email);
      }
      if (!user) {
        user = await getOrCreateUser(
          req.user.uid,
          req.user.email || `${req.user.uid}@auth.local`,
          req.user.name || undefined,
          req.user.picture || undefined
        );
      }
      const credentials = await getUserCredentials(user.id);
      res.json({
        user: {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoUrl: user.photoUrl,
        },
        credentials,
      });
    } catch (error: any) {
      console.error('Failed to fetch user:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch user profile' });
    }
  });

  // Get candidate career credentials
  app.get('/api/credentials', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserByUid(req.user!.uid);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const credentials = await getUserCredentials(user.id);
      res.json(credentials || {});
    } catch (error: any) {
      console.error('Failed to get credentials:', error);
      res.status(500).json({ error: error.message || 'Failed to get credentials' });
    }
  });

  // Save / Update candidate career credentials
  app.post('/api/credentials', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserByUid(req.user!.uid);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const updated = await upsertUserCredentials(user.id, req.body);
      res.json(updated);
    } catch (error: any) {
      console.error('Failed to update credentials:', error);
      res.status(500).json({ error: error.message || 'Failed to update credentials' });
    }
  });

  // Get saved analyses
  app.get('/api/analyses', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserByUid(req.user!.uid);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const records = await getUserSavedAnalyses(user.id);
      // Parse serialized report data for client convenience
      const parsed = records.map((r) => {
        let parsedReport = null;
        try {
          parsedReport = JSON.parse(r.reportData);
        } catch {
          parsedReport = null;
        }
        return {
          id: r.id,
          candidateName: r.candidateName,
          targetRole: r.targetRole,
          targetCompany: r.targetCompany,
          totalScore: r.totalScore,
          alignmentLevel: r.alignmentLevel,
          createdAt: r.createdAt,
          report: parsedReport,
        };
      });
      res.json(parsed);
    } catch (error: any) {
      console.error('Failed to get analyses:', error);
      res.status(500).json({ error: error.message || 'Failed to get saved analyses' });
    }
  });

  // Save analysis report
  app.post('/api/analyses', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserByUid(req.user!.uid);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const { candidateName, targetRole, targetCompany, totalScore, alignmentLevel, reportData } = req.body;
      if (!targetRole || totalScore === undefined) {
        return res.status(400).json({ error: 'Missing required report fields' });
      }
      const saved = await saveAnalysisReport(user.id, {
        candidateName,
        targetRole,
        targetCompany,
        totalScore,
        alignmentLevel: alignmentLevel || 'Moderate Match',
        reportData,
      });
      res.json(saved);
    } catch (error: any) {
      console.error('Failed to save analysis report:', error);
      res.status(500).json({ error: error.message || 'Failed to save analysis' });
    }
  });

  // Delete saved analysis
  app.delete('/api/analyses/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = await getUserByUid(req.user!.uid);
      if (!user) return res.status(404).json({ error: 'User not found' });
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) return res.status(400).json({ error: 'Invalid analysis ID' });
      const success = await deleteSavedAnalysis(user.id, id);
      res.json({ success });
    } catch (error: any) {
      console.error('Failed to delete analysis:', error);
      res.status(500).json({ error: error.message || 'Failed to delete analysis' });
    }
  });

  // 3. Upload and extract resume text from PDF / DOCX / TXT
  // Accepts either multipart form-data (resumeFile or file) or base64 JSON payload
  const handleUploadMiddleware = (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (req.is('application/json')) {
      return next();
    }
    upload.fields([{ name: 'resumeFile', maxCount: 1 }, { name: 'file', maxCount: 1 }])(req, res, (err) => {
      if (err) {
        console.error('Multer upload error:', err);
        return res.status(400).json({ error: err.message || 'File upload error.' });
      }
      next();
    });
  };

  app.post('/api/upload-resume', handleUploadMiddleware, async (req, res) => {
    try {
      let fileBuffer: Buffer | null = null;
      let filename = 'Uploaded_Resume.pdf';
      let mimetype = 'application/pdf';
      let filesize = 0;

      // Case A: Multipart uploaded file
      const files = req.files as { [fieldname: string]: Express.Multer.File[] } | undefined;
      const uploadedFile = req.file || files?.resumeFile?.[0] || files?.file?.[0];

      if (uploadedFile) {
        fileBuffer = uploadedFile.buffer;
        filename = uploadedFile.originalname;
        mimetype = uploadedFile.mimetype;
        filesize = uploadedFile.size;
      }
      // Case B: Base64 JSON payload
      else if (req.body?.base64 || req.body?.fileBase64) {
        const base64Str = req.body.base64 || req.body.fileBase64;
        fileBuffer = Buffer.from(base64Str, 'base64');
        filename = req.body.filename || 'Uploaded_Resume.pdf';
        mimetype = req.body.mimeType || req.body.mimetype || 'application/pdf';
        filesize = fileBuffer.length;
      }

      if (!fileBuffer || fileBuffer.length === 0) {
        return res.status(400).json({ error: 'No resume file uploaded or empty file received.' });
      }

      const extracted = await extractResumeDetailsFromBuffer(
        fileBuffer,
        mimetype,
        filename
      );

      res.json({
        filename,
        filesize,
        mimetype,
        extractedText: extracted.text,
        pages: extracted.pages,
        fileType: extracted.fileType,
        charCount: extracted.text.length,
      });
    } catch (err: any) {
      console.error('File parsing error:', err);
      res.status(400).json({ error: err.message || 'Unable to parse uploaded file.' });
    }
  });

  // Dedicated base64 extraction endpoint for maximum proxy compatibility
  app.post('/api/extract-resume-base64', async (req, res) => {
    try {
      const { base64, filename, mimeType } = req.body;
      if (!base64 || typeof base64 !== 'string') {
        return res.status(400).json({ error: 'Missing base64 file data.' });
      }

      const fileBuffer = Buffer.from(base64, 'base64');
      if (fileBuffer.length === 0) {
        return res.status(400).json({ error: 'File data is empty.' });
      }

      const targetFilename = filename || 'Uploaded_Resume.pdf';
      const targetMime = mimeType || 'application/pdf';

      const extracted = await extractResumeDetailsFromBuffer(
        fileBuffer,
        targetMime,
        targetFilename
      );

      res.json({
        filename: targetFilename,
        filesize: fileBuffer.length,
        mimetype: targetMime,
        extractedText: extracted.text,
        pages: extracted.pages,
        fileType: extracted.fileType,
        charCount: extracted.text.length,
      });
    } catch (err: any) {
      console.error('Base64 extraction error:', err);
      res.status(400).json({ error: err.message || 'Unable to parse uploaded file.' });
    }
  });

  // 4. Step 1: Analyze Resume
  app.post('/api/analyze-resume', async (req, res) => {
    try {
      const { resumeText } = req.body;
      if (!resumeText || typeof resumeText !== 'string' || resumeText.trim().length < 20) {
        return res.status(400).json({ error: 'Please provide a valid resume text (at least 20 characters).' });
      }

      const resumeData = await analyzeResumeWithAI(resumeText);
      res.json(resumeData);
    } catch (err: any) {
      console.error('Analyze resume error:', err);
      res.status(500).json({ error: err.message || 'Resume analysis failed.' });
    }
  });

  // 5. Step 2: Analyze Job Description
  app.post('/api/analyze-job', async (req, res) => {
    try {
      const { jobDescription, jobTitle, company, seniorityLevel } = req.body;
      if (!jobDescription || typeof jobDescription !== 'string' || jobDescription.trim().length < 20) {
        return res.status(400).json({ error: 'Please provide a valid job description (at least 20 characters).' });
      }

      const jobData = await analyzeJobWithAI(jobDescription, {
        title: jobTitle,
        company,
        level: seniorityLevel,
      });
      res.json(jobData);
    } catch (err: any) {
      console.error('Analyze job error:', err);
      res.status(500).json({ error: err.message || 'Job description analysis failed.' });
    }
  });

  // 6. Step 3: Deterministic Matching & Scoring
  app.post('/api/match-and-score', (req, res) => {
    try {
      const { resumeData, jobData } = req.body;
      if (!resumeData || !jobData) {
        return res.status(400).json({ error: 'Missing resumeData or jobData payload.' });
      }

      const skillMatches = runSkillMatching(resumeData, jobData);
      const scoreResult = calculateExplainableScore(resumeData, jobData, skillMatches);

      res.json({ skillMatches, scoreResult });
    } catch (err: any) {
      console.error('Matching & scoring error:', err);
      res.status(500).json({ error: err.message || 'Skill matching failed.' });
    }
  });

  // 7. Step 4: Generate Recommendations
  app.post('/api/generate-recommendations', async (req, res) => {
    try {
      const { resumeData, jobData, skillMatches, scoreResult, targetGoal } = req.body;
      if (!resumeData || !jobData || !skillMatches || !scoreResult) {
        return res.status(400).json({ error: 'Incomplete data for recommendation engine.' });
      }

      const recommendations = await generateRecommendationsWithAI(
        resumeData,
        jobData,
        skillMatches,
        scoreResult,
        targetGoal
      );
      res.json(recommendations);
    } catch (err: any) {
      console.error('Recommendation generation error:', err);
      res.status(500).json({ error: err.message || 'Recommendation generation failed.' });
    }
  });

  // Helper function to calculate Application Readiness
  function computeApplicationReadiness(
    scoreResult: ScoreResult,
    resumeData: ResumeData,
    jobData: JobData
  ): ApplicationReadiness {
    const reqCat = scoreResult.categories.required_skills;
    const reqPct = reqCat.is_applicable && reqCat.max > 0 ? (reqCat.earned / reqCat.max) * 100 : 75;
    const skillsLevel: ReadinessLevel = reqPct >= 75 ? 'Strong' : reqPct >= 50 ? 'Moderate' : 'Needs Improvement';

    const candidateYears = resumeData.total_experience_years || 0;
    const reqYears = jobData.experience_requirements.min_years || 2;
    let expLevel: ReadinessLevel = 'Moderate';
    if (candidateYears >= reqYears) {
      expLevel = 'Strong';
    } else if (candidateYears < Math.max(0, reqYears - 1.5)) {
      expLevel = 'Needs Improvement';
    }

    const projCat = scoreResult.categories.projects;
    const projPct = projCat.is_applicable && projCat.max > 0 ? (projCat.earned / projCat.max) * 100 : 70;
    const projLevel: ReadinessLevel = projPct >= 70 ? 'Strong' : projPct >= 40 ? 'Moderate' : 'Needs Improvement';

    const rqCat = scoreResult.categories.resume_quality;
    const rqPct = rqCat.max > 0 ? (rqCat.earned / rqCat.max) * 100 : 75;
    const rqLevel: ReadinessLevel = rqPct >= 70 ? 'Strong' : rqPct >= 45 ? 'Moderate' : 'Needs Improvement';

    const roleLevel: ReadinessLevel = scoreResult.totalScore >= 75 ? 'Strong' : scoreResult.totalScore >= 55 ? 'Moderate' : 'Needs Improvement';

    return {
      skills: skillsLevel,
      experience: expLevel,
      projects: projLevel,
      resumeQuality: rqLevel,
      roleAlignment: roleLevel,
      summary: `Candidate profile indicates ${skillsLevel.toLowerCase()} technical skill alignment, ${expLevel.toLowerCase()} experience alignment, and ${roleLevel.toLowerCase()} overall readiness for ${jobData.job_title} at ${jobData.company_inferred}.`,
    };
  }

  // 8. Complete Pipeline (Multi-step orchestrator)
  app.post('/api/run-pipeline', async (req, res) => {
    try {
      const {
        resumeText,
        jobDescription,
        resumeFileName,
        resumeFileType,
        resumeFileSize,
        resumePageCount,
        targetCompany: rawCompany,
        targetRole: rawRole,
        experienceLevel: rawLevel,
        targetGoal,
        jobMeta,
      } = req.body;

      if (!resumeText || resumeText.trim().length < 20) {
        return res.status(400).json({ error: 'Please upload or provide valid resume content.' });
      }

      const targetCompany = rawCompany || jobMeta?.company || 'Target Organization';
      const targetRole = rawRole || jobMeta?.title || 'Software Engineer';
      const experienceLevel = rawLevel || jobMeta?.level || '2–4 Years';

      const isJobDescriptionSupplied = Boolean(jobDescription && jobDescription.trim().length >= 20);

      let effectiveJobText = jobDescription?.trim() || '';
      if (!isJobDescriptionSupplied) {
        effectiveJobText = `Target Role: ${targetRole}
Target Company: ${targetCompany}
Seniority Level: ${experienceLevel}

Role Context:
This analysis evaluates competencies commonly associated with the role of ${targetRole} at leading organizations comparable to ${targetCompany} at the ${experienceLevel} experience tier. Key technical standards, engineering foundations, collaboration, and ownership capabilities commonly expected for this level are evaluated.`;
      }

      const effectiveMeta = {
        title: targetRole,
        company: targetCompany,
        level: experienceLevel,
        isJobDescriptionSupplied,
      };

      // Step 1: Deep Resume Analysis
      const resumeData = await analyzeResumeWithAI(resumeText);

      // Step 2: Deep Job / Role Analysis
      const jobData = await analyzeJobWithAI(effectiveJobText, effectiveMeta);

      // Step 3: Deterministic Requirement & Skill Matching
      const skillMatches = runSkillMatching(resumeData, jobData);

      // Step 4: Mathematical 100-Point Scoring Engine
      const scoreResult = calculateExplainableScore(resumeData, jobData, skillMatches);

      // Step 5: Strategic Recommendations & Personalized Roadmap
      const recommendations = await generateRecommendationsWithAI(
        resumeData,
        jobData,
        skillMatches,
        scoreResult,
        targetGoal
      );

      // Step 6: Application Readiness
      const applicationReadiness = computeApplicationReadiness(scoreResult, resumeData, jobData);

      const report: AnalysisReport = {
        id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        timestamp: new Date().toISOString(),
        resumeFileName: resumeFileName || 'Uploaded_Resume.pdf',
        resumeFileType: resumeFileType || (resumeFileName?.toLowerCase().endsWith('.docx') ? 'DOCX' : 'PDF'),
        resumeFileSize: resumeFileSize,
        resumePageCount: resumePageCount,
        targetCompany,
        targetRole,
        experienceLevel,
        isJobDescriptionSupplied,
        applicationReadiness,
        targetGoal,
        resumeData,
        jobData,
        skillMatches,
        scoreResult,
        recommendations,
      };

      res.json(report);
    } catch (err: any) {
      console.error('Pipeline error:', err?.message || err);
      res.status(500).json({ error: 'Pipeline execution failed. Please check inputs and retry.' });
    }
  });

  // Vite middleware in dev or static serving in prod
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`AI Resume Skill Analyzer server running on http://localhost:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
